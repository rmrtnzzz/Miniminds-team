function initComunidadFeed(FEED_URL){
(function(){
 const list = document.getElementById('feed-list');
 const empty = document.getElementById('feed-empty');
 let lastId = 0;
 const seen = new Set();

 function renderItem(item, prepend) {
 if (seen.has(item.id)) return;
 seen.add(item.id);
 const card = document.createElement('div');
 card.className = 'feed-card';
 card.innerHTML = `
 <h3><a href="${item.url}"></a></h3>
 <div class="feed-meta"></div>
 <p></p>
 `;
 card.querySelector('h3 a').textContent = item.titulo;
 card.querySelector('h3 a').href = item.url;
 card.querySelector('.feed-meta').textContent = 'Por ' + item.autor + ' · ' + item.fecha;
 card.querySelector('p').textContent = item.resumen;
 if (prepend) list.prepend(card); else list.appendChild(card);
 if (item.id > lastId) lastId = item.id;
 }

 async function loadInitial() {
 try {
 const res = await fetch(FEED_URL);
 const data = await res.json();
 if (!data.experiencias.length) { empty.style.display = 'block'; return; }
 data.experiencias.forEach(item => renderItem(item, false));
 } catch (e) { /* silencioso */ }
 }

 async function pollNew() {
 try {
 const res = await fetch('{{ route('experiencias.feed') }}?after_id=' + lastId);
 const data = await res.json();
 if (data.experiencias.length) {
 empty.style.display = 'none';
 [...data.experiencias].reverse().forEach(item => renderItem(item, true));
 }
 } catch (e) { /* silencioso */ }
 }

 loadInitial();
 setInterval(pollNew, 8000);
})();
}
