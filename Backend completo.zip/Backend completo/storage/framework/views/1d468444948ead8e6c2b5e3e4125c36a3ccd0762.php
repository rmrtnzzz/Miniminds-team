<?php
 // $height: alto del bloque. $showHeader: si muestra el título interno.
 $height = $height ?? '620px';
 $showHeader = $showHeader ?? true;
 $uid = 'cb-' . uniqid();
?>

<div id="<?php echo e($uid); ?>" class="cerebro-widget" style="--cb-h: <?php echo e($height); ?>;">

 <?php if($showHeader): ?>
 <div class="cb-header">
 <div>
 <h1>Mi Cerebro 3D</h1>
 <p>Arrastra para rotar · Rueda para zoom · Elegí una condición para ver qué zonas afecta</p>
 </div>
 </div>
 <?php endif; ?>

 <div class="cb-body">
 <div class="cb-canvas-wrap">
 <div class="cb-hover-tag"></div>
 <div class="cb-hint">Arrastra para explorar</div>
 </div>

 <div class="cb-info-panel">
 <div class="cb-idle">
 <span class="cb-big-emoji"><i class="fas fa-brain"></i></span>Elegí una condición de los botones de abajo para ver qué zonas del cerebro se relacionan con ella.
 </div>
 <div class="cb-info-content">
 <div class="cb-info-close"><i class="fas fa-xmark"></i></div>
 <span class="cb-info-badge"></span>
 <h3 class="cb-info-title"></h3>
 <p class="cb-info-text"></p>
 </div>
 </div>
 </div>

 <div class="cb-fact-pills">
 <div class="cb-fact-pill" data-key="tdah">TDAH</div>
 <div class="cb-fact-pill" data-key="autismo">Autismo</div>
 <div class="cb-fact-pill" data-key="dislexia">Dislexia</div>
 <div class="cb-fact-pill" data-key="ansiedad">Ansiedad</div>
 <div class="cb-fact-pill" data-key="sensorial">Sensibilidad Sensorial</div>
 <div class="cb-fact-pill" data-key="neuronas">Neuronas</div>
 </div>

</div>

<link href="<?php echo e(asset('css/cerebro/brain-widget.css')); ?>" rel="stylesheet">

<?php if (! $__env->hasRenderedOnce('ec109551-46bc-4684-961c-79f139ae0860')): $__env->markAsRenderedOnce('ec109551-46bc-4684-961c-79f139ae0860'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js"></script>
<?php endif; ?>

<?php if (! $__env->hasRenderedOnce('c8e81db6-8807-428e-b653-703fde667fc8')): $__env->markAsRenderedOnce('c8e81db6-8807-428e-b653-703fde667fc8'); ?>
<script src="<?php echo e(asset('js/cerebro/brain-widget.js')); ?>"></script>
<?php endif; ?>
<script>initCerebroBrain('<?php echo e($uid); ?>', '<?php echo e(asset('models/cerebro/cerebro.glb')); ?>');</script><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/partials/cerebro-brain.blade.php ENDPATH**/ ?>