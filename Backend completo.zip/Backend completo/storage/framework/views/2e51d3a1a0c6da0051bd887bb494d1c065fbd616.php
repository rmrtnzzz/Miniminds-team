<?php $__env->startSection('title', $paciente->nombre.' — Ficha del paciente'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="font-weight:800;margin:0"><?php echo e($paciente->nombre); ?> <?php echo e($paciente->apellido); ?></h2>
    <a href="<?php echo e(route('especialista.pacientes.edit', $paciente->id)); ?>" class="btn btn-acento btn-sm">Editar datos</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="pt-card p-4">
            <div style="font-size:12px;color:#4a7d6f;text-transform:uppercase;font-weight:700">Tutor</div>
            <div style="font-size:15px"><?php echo e($paciente->user->name ?? '—'); ?></div>
            <div style="font-size:12px;color:#4a7d6f"><?php echo e($paciente->user->email ?? ''); ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pt-card p-4">
            <div style="font-size:12px;color:#4a7d6f;text-transform:uppercase;font-weight:700">Edad / Género</div>
            <div style="font-size:15px"><?php echo e($paciente->edad ?? '—'); ?> años · <?php echo e(ucfirst($paciente->genero ?? '—')); ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pt-card p-4">
            <div style="font-size:12px;color:#4a7d6f;text-transform:uppercase;font-weight:700">Fecha de nacimiento</div>
            <div style="font-size:15px"><?php echo e(optional($paciente->fecha_nacimiento)->format('d/m/Y') ?? '—'); ?></div>
        </div>
    </div>
</div>

<h6 style="font-weight:700;margin-bottom:10px">Historial de citas</h6>
<div class="pt-card p-3 mb-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="color:#4a7d6f;font-size:12px;text-transform:uppercase">
                <th>Fecha</th><th>Hora</th><th>Estado</th><th>Notas</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $paciente->citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($c->fecha)->format('d/m/Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($c->hora)->format('H:i')); ?></td>
                    <td><?php echo e(ucfirst($c->estado)); ?></td>
                    <td style="color:#7c9d92"><?php echo e($c->notas ?? '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center py-3" style="color:#7c9d92">Sin citas registradas todavía.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<a href="<?php echo e(route('especialista.citas.index')); ?>" class="btn btn-acento btn-sm">+ Agendar una cita para este paciente</a>

<h6 style="font-weight:700;margin:26px 0 10px">Plan de terapias y juegos</h6>

<?php if(session('success')): ?>
    <div class="alert alert-success py-2" style="font-size:13px"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="pt-card p-3 mb-3">
    <?php $__empty_1 = true; $__currentLoopData = $paciente->asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="d-flex justify-content-between align-items-start py-2" style="border-bottom:1px solid rgba(0,0,0,0.06)">
            <div>
                <span style="font-size:11px;font-weight:700;text-transform:uppercase;color:<?php echo e($a->tipo === 'juego' ? '#6d5bd0' : '#4a7d6f'); ?>">
                    <?php echo e($a->tipo === 'juego' ? 'Juego' : 'Terapia'); ?>

                </span>
                <?php if($a->estado === 'completada'): ?>
                    <span style="font-size:11px;color:#2ba36b;font-weight:700">· Completada</span>
                <?php endif; ?>
                <div style="font-weight:700;font-size:14px"><?php echo e($a->titulo); ?></div>
                <?php if($a->descripcion): ?>
                    <div style="font-size:13px;color:#7c9d92"><?php echo e($a->descripcion); ?></div>
                <?php endif; ?>
                <?php if($a->tipo === 'juego' && $a->juego_ruta): ?>
                    <a href="<?php echo e(route($a->juego_ruta)); ?>" target="_blank" style="font-size:12px" class="text-decoration-none">Ver juego →</a>
                <?php endif; ?>
            </div>
            <div class="d-flex gap-2">
                <?php if($a->estado === 'activa'): ?>
                    <form method="POST" action="<?php echo e(route('especialista.pacientes.asignaciones.completar', [$paciente->id, $a->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-secondary btn-sm">Marcar completada</button>
                    </form>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('especialista.pacientes.asignaciones.destroy', [$paciente->id, $a->id])); ?>" onsubmit="return confirm('¿Eliminar esta asignación?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-outline-danger btn-sm">Eliminar</button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p style="color:#7c9d92;font-size:13px;margin:0">Todavía no le has asignado ninguna terapia o juego a este paciente.</p>
    <?php endif; ?>
</div>

<div class="pt-card p-3">
    <div style="font-weight:700;font-size:14px;margin-bottom:10px">Asignar algo nuevo</div>
    <form method="POST" action="<?php echo e(route('especialista.pacientes.asignaciones.store', $paciente->id)); ?>" id="form-asignacion">
        <?php echo csrf_field(); ?>
        <div class="d-flex gap-2 mb-2">
            <label class="btn btn-outline-secondary btn-sm active">
                <input type="radio" name="tipo" value="terapia" checked onchange="toggleAsignacionTipo()" style="margin-right:4px"> Terapia
            </label>
            <label class="btn btn-outline-secondary btn-sm">
                <input type="radio" name="tipo" value="juego" onchange="toggleAsignacionTipo()" style="margin-right:4px"> Juego
            </label>
        </div>

        <div id="campos-terapia">
            <input type="text" name="titulo" class="form-control form-control-sm mb-2" placeholder="Título de la terapia (ej: Ejercicios de respiración diaria)">
        </div>

        <div id="campos-juego" style="display:none">
            <select name="juego_ruta" class="form-control form-control-sm mb-2">
                <option value="">Selecciona un juego…</option>
                <?php $__currentLoopData = \App\Models\Asignacion::JUEGOS_DISPONIBLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ruta); ?>"><?php echo e($nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <textarea name="descripcion" class="form-control form-control-sm mb-2" rows="2" placeholder="Notas o instrucciones para el paciente/tutor (opcional)"></textarea>

        <button type="submit" class="btn btn-acento btn-sm">Asignar</button>
    </form>
</div>

<script src="<?php echo e(asset('js/especialista/paciente-show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.especialista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\tratando\neuropendejadas\resources\views/especialista/pacientes/show.blade.php ENDPATH**/ ?>