<?php $__env->startSection('title', 'Mis publicaciones — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
 <h2 style="font-weight:800; margin:0;">Mis publicaciones</h2>
 <a href="<?php echo e(route('experiencias.create')); ?>" class="btn btn-acento btn-sm">+ Publicar</a>
</div>

<?php if(session('success')): ?>
 <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
 <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<?php $__empty_1 = true; $__currentLoopData = $experiencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
 <div class="pt-card p-4 mb-3">
 <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
 <div>
 <h5 style="font-weight:700; margin-bottom:4px;">
 <a href="<?php echo e(route('experiencias.show', $experiencia)); ?>" style="text-decoration:none; color:inherit;">
 <?php echo e($experiencia->titulo); ?>

 </a>
 </h5>
 <p style="font-size:13px; color:#888; margin-bottom:8px;">
 <?php echo e($experiencia->created_at->diffForHumans()); ?>

 <?php if($experiencia->estado === 'bloqueada'): ?>
 · <span style="color:#dc3545; font-weight:700;">Bloqueada</span>
 <?php else: ?>
 · <span style="color:#2ba36b; font-weight:700;">Publicada</span>
 <?php endif; ?>
 </p>
 </div>
 <div style="display:flex; gap:8px; flex-shrink:0;">
 <a href="<?php echo e(route('experiencias.edit', $experiencia)); ?>" class="btn btn-outline-secondary btn-sm">Editar</a>
 <form method="POST" action="<?php echo e(route('experiencias.destroy', $experiencia)); ?>" onsubmit="return confirm('¿Eliminar esta publicación?');">
 <?php echo csrf_field(); ?>
 <?php echo method_field('DELETE'); ?>
 <button type="submit" class="btn btn-outline-danger btn-sm">Eliminar</button>
 </form>
 </div>
 </div>
 <?php if($experiencia->estado === 'bloqueada'): ?>
 <p style="font-size:12px; color:#dc3545; margin:6px 0 0;">Motivo: <?php echo e($experiencia->motivo_bloqueo); ?></p>
 <?php endif; ?>
 <p style="font-size:14px; margin:10px 0 0;"><?php echo e(\Illuminate\Support\Str::limit($experiencia->contenido, 220)); ?></p>
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
 <p style="color:#777;">Todavía no has publicado nada. ¡Comparte tu primera experiencia!</p>
<?php endif; ?>

<?php echo e($experiencias->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\tratando\neuropendejadas\resources\views/experiencias/mias.blade.php ENDPATH**/ ?>