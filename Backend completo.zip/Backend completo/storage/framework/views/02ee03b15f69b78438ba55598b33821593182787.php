<?php $__env->startSection('title', 'Moderación — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800; margin-bottom:20px;"> Moderación de experiencias</h2>

<h5 style="font-weight:700;">Bloqueadas por el filtro (<?php echo e($bloqueadas->count()); ?>)</h5>

<?php $__empty_1 = true; $__currentLoopData = $bloqueadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
 <div class="pt-card p-4 mb-3">
 <p style="font-size:12px; color:#cdc3e6;">
 <?php echo e($experiencia->user->name ?? 'Usuario #'.$experiencia->user_id); ?> ·
 <?php echo e($experiencia->created_at->format('d/m/Y H:i')); ?>

 </p>
 <strong><?php echo e($experiencia->titulo); ?></strong>
 <p style="font-size:13px; color:#cdc3e6;">Motivo: <?php echo e($experiencia->motivo_bloqueo); ?></p>
 <div style="background:rgba(0,0,0,0.2); border-radius:8px; padding:10px 14px; margin:8px 0; white-space:pre-wrap;">
 <?php echo e($experiencia->contenido); ?>

 </div>
 <div>
 <form method="POST" action="<?php echo e(route('admin.experiencias.aprobar', $experiencia)); ?>" style="display:inline;">
 <?php echo csrf_field(); ?>
 <button type="submit" class="btn btn-acento btn-sm">Aprobar y publicar</button>
 </form>
 <form method="POST" action="<?php echo e(route('admin.experiencias.destroy', $experiencia)); ?>" style="display:inline;" onsubmit="return confirm('¿Eliminar definitivamente?');">
 <?php echo csrf_field(); ?>
 <?php echo method_field('DELETE'); ?>
 <button type="submit" class="btn btn-outline-danger btn-sm">Eliminar</button>
 </form>
 </div>
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
 <p style="color:#cdc3e6;">No hay experiencias pendientes de revisión. </p>
<?php endif; ?>

<h5 style="font-weight:700; margin-top:32px;">Últimas publicadas</h5>
<?php $__empty_1 = true; $__currentLoopData = $publicadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
 <div class="pt-card p-3 mb-2">
 <strong><?php echo e($experiencia->titulo); ?></strong>
 <span style="font-size:12px; color:#cdc3e6;">— <?php echo e($experiencia->user->name ?? ''); ?></span>
 </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
 <p style="color:#cdc3e6;">Todavía no hay experiencias publicadas.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/admin/experiencias/index.blade.php ENDPATH**/ ?>