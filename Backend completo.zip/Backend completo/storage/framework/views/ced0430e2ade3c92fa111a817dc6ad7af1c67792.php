<?php $__env->startSection('title', 'Editar paciente — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800;margin-bottom:20px">Editar datos de <?php echo e($paciente->nombre); ?></h2>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div>• <?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div class="pt-card p-4" style="max-width:600px">
    <form action="<?php echo e(route('especialista.pacientes.update', $paciente->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="row g-3">
            <div class="col-md-6">
                <label style="font-size:12px;font-weight:700;color:#4a7d6f;text-transform:uppercase">Nombre</label>
                <input type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre', $paciente->nombre)); ?>" required>
            </div>
            <div class="col-md-6">
                <label style="font-size:12px;font-weight:700;color:#4a7d6f;text-transform:uppercase">Apellido</label>
                <input type="text" name="apellido" class="form-control" value="<?php echo e(old('apellido', $paciente->apellido)); ?>" required>
            </div>
            <div class="col-md-6">
                <label style="font-size:12px;font-weight:700;color:#4a7d6f;text-transform:uppercase">Fecha de nacimiento</label>
                <input type="date" name="fecha_nacimiento" class="form-control" value="<?php echo e(old('fecha_nacimiento', optional($paciente->fecha_nacimiento)->format('Y-m-d'))); ?>">
            </div>
            <div class="col-md-6">
                <label style="font-size:12px;font-weight:700;color:#4a7d6f;text-transform:uppercase">Edad</label>
                <input type="number" name="edad" class="form-control" min="0" max="120" value="<?php echo e(old('edad', $paciente->edad)); ?>">
            </div>
            <div class="col-md-6">
                <label style="font-size:12px;font-weight:700;color:#4a7d6f;text-transform:uppercase">Género</label>
                <select name="genero" class="form-control">
                    <option value="masculino" <?php echo e($paciente->genero=='masculino'?'selected':''); ?>>Masculino</option>
                    <option value="femenino" <?php echo e($paciente->genero=='femenino'?'selected':''); ?>>Femenino</option>
                    <option value="otro" <?php echo e($paciente->genero=='otro'?'selected':''); ?>>Otro</option>
                </select>
            </div>
            <div class="col-md-6">
                <label style="font-size:12px;font-weight:700;color:#4a7d6f;text-transform:uppercase">Foto</label>
                <input type="file" name="foto" accept="image/*" class="form-control">
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <a href="<?php echo e(route('especialista.pacientes.show', $paciente->id)); ?>" class="btn btn-outline-secondary">Cancelar</a>
            <button type="submit" class="btn btn-acento">Guardar cambios</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.especialista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\tratando\neuropendejadas\resources\views/especialista/pacientes/editar.blade.php ENDPATH**/ ?>