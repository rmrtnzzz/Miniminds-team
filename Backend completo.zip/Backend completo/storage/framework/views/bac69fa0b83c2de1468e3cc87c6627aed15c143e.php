<?php $__env->startSection('title', 'Especialistas — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800;margin-bottom:20px">Especialistas</h2>

<div class="pt-card p-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="font-size:11px;text-transform:uppercase;opacity:.6">
                <th>Nombre</th><th>Correo</th><th>Especialidad</th><th>Teléfono</th><th>Pacientes</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $profesionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($p->nombre); ?> <?php echo e($p->apellido); ?></td>
                    <td><?php echo e($p->user->email ?? '—'); ?></td>
                    <td><?php echo e($p->especialidad ?? '—'); ?></td>
                    <td><?php echo e($p->telefono ?? '—'); ?></td>
                    <td><?php echo e($p->pacientes()->count()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center py-3" style="opacity:.6">No hay especialistas registrados.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/admin/profesionales/index.blade.php ENDPATH**/ ?>