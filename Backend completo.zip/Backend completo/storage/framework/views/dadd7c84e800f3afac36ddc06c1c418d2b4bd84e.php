<?php $__env->startSection('title', 'Usuarios — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800;margin-bottom:20px">Usuarios</h2>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="pt-card p-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="font-size:11px;text-transform:uppercase;opacity:.6">
                <th>Nombre</th><th>Correo</th><th>Rol actual</th><th>Cambiar rol</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($u->name); ?> <?php echo e($u->apellido); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><span style="text-transform:capitalize"><?php echo e($u->role); ?></span></td>
                    <td>
                        <form action="<?php echo e(route('admin.usuarios.rol', $u->id)); ?>" method="POST" class="d-flex gap-2">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <select name="role" class="form-select form-select-sm" style="width:auto">
                                <option value="usuario" <?php echo e($u->role=='usuario'?'selected':''); ?>>Usuario</option>
                                <option value="especialista" <?php echo e($u->role=='especialista'?'selected':''); ?>>Especialista</option>
                                <option value="admin" <?php echo e($u->role=='admin'?'selected':''); ?>>Admin</option>
                            </select>
                            <button type="submit" class="btn btn-sm btn-acento">Guardar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>