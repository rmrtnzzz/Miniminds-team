<?php $__env->startSection('title', 'Pacientes — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800;margin-bottom:20px">Pacientes registrados</h2>

<div class="pt-card p-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="font-size:11px;text-transform:uppercase;opacity:.6">
                <th>Paciente</th><th>Tutor</th><th>Especialista asignado</th><th>Edad</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($p->nombre); ?> <?php echo e($p->apellido); ?></td>
                    <td><?php echo e($p->user->name ?? '—'); ?></td>
                    <td><?php echo e($p->profesional->nombre ?? 'Sin asignar'); ?> <?php echo e($p->profesional->apellido ?? ''); ?></td>
                    <td><?php echo e($p->edad ?? '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center py-3" style="opacity:.6">No hay pacientes registrados.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/admin/pacientes/index.blade.php ENDPATH**/ ?>