<?php $__env->startSection('title', 'Solicitudes — Miniminds'); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800;margin-bottom:20px">Solicitudes de registro de pacientes</h2>

<div class="pt-card p-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="font-size:11px;text-transform:uppercase;opacity:.6">
                <th>Paciente propuesto</th><th>Solicitado por</th><th>Estado</th><th>Revisado por</th><th>Fecha</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($s->nombre); ?> <?php echo e($s->apellido); ?></td>
                    <td><?php echo e($s->user->name ?? '—'); ?></td>
                    <td style="text-transform:capitalize"><?php echo e($s->estado); ?></td>
                    <td><?php echo e($s->profesional->nombre ?? '—'); ?></td>
                    <td><?php echo e($s->created_at->format('d/m/Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center py-3" style="opacity:.6">No hay solicitudes registradas.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/admin/solicitudes/index.blade.php ENDPATH**/ ?>