<?php $__env->startSection('title', 'Agenda — Miniminds'); ?>

<?php $__env->startSection('extra_styles'); ?>
<link href="<?php echo e(asset('css/paciente/agenda.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2 style="font-weight:800; margin-bottom:24px;">Agenda</h2>

<div class="pt-card p-2">
    <?php $__empty_1 = true; $__currentLoopData = $proximasCitas ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="agenda-item">
            <div class="agenda-fecha">
                <span class="dia"><?php echo e($cita->fecha->format('d')); ?></span>
                <span class="mes"><?php echo e($cita->fecha->locale('es')->isoFormat('MMM')); ?></span>
            </div>
            <div class="agenda-info">
                <div class="titulo"><?php echo e($cita->paciente->nombre ?? '—'); ?> con <?php echo e($cita->profesional->nombre ?? 'profesional por asignar'); ?></div>
                <div class="sub"><?php echo e(\Carbon\Carbon::parse($cita->hora)->format('H:i')); ?> hrs · <?php echo e(ucfirst($cita->estado)); ?></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="text-align:center; color:#9a8fb8; padding:40px;">
            No tienes próximas citas en tu agenda.
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.paciente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\resources\views/paciente/agenda.blade.php ENDPATH**/ ?>