<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>