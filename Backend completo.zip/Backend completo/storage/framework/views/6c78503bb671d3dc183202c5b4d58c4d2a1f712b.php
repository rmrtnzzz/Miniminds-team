<?php echo e($slot); ?>

<?php /**PATH C:\Users\abc\Desktop\asix\neuropendejadas\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>