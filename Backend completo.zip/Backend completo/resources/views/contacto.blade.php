<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Contáctanos — Miniminds</title>
 <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
 <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
 <link href="{{ asset('css/shared/contacto.css') }}" rel="stylesheet">
</head>
<body>

<nav>
 <a class="brand" href="{{ route('home') }}">Miniminds!</a>
 <div class="nav-actions">
 @auth
 <a href="{{ auth()->user()->panelUrl() }}" class="btn-solid">Mi Panel</a>
 @else
 <a href="{{ route('login') }}" class="btn-ghost">Iniciar sesión</a>
 <a href="{{ route('register') }}" class="btn-solid">Registrarse</a>
 @endauth
 </div>
</nav>

<div class="wrap">
 <div class="header-block">
 <h1>Contáctanos</h1>
 <p>¿Tienes dudas o quieres saber más sobre Miniminds? Escríbenos, te responderemos pronto.</p>
 </div>

 <div class="grid">
 <div class="card">
 <h3>Envíanos un mensaje</h3>

 @if(session('success'))
 <div class="alert alert-success"> {{ session('success') }}</div>
 @endif

 @if($errors->any())
 <div class="alert alert-error">
 @foreach($errors->all() as $e)<div>• {{ $e }}</div>@endforeach
 </div>
 @endif

 <form action="{{ route('contacto.enviar') }}" method="POST">
 @csrf

 <div style="display:flex;gap:14px">
 <div style="flex:1">
 <label>Nombre</label>
 <input type="text" name="nombre" value="{{ old('nombre') }}" required>
 </div>
 <div style="flex:1">
 <label>Apellido</label>
 <input type="text" name="apellido" value="{{ old('apellido') }}" required>
 </div>
 </div>

 <label>Correo electrónico</label>
 <input type="email" name="correo" value="{{ old('correo') }}" required>

 <label>Teléfono (opcional)</label>
 <input type="text" name="telefono" value="{{ old('telefono') }}">

 <label>Mensaje</label>
 <textarea name="mensaje" required>{{ old('mensaje') }}</textarea>

 <button type="submit" class="btn-acento">Enviar mensaje</button>
 </form>
 </div>

 <div class="card">
 <h3>Información de contacto</h3>

 <div class="info-item">
 <i class="fas fa-envelope"></i>
 <div>
 <span>Correo</span>
 <p>minimindssv@gmail.com</p>
 </div>
 </div>

 <div class="info-item">
 <i class="fas fa-map-marker-alt"></i>
 <div>
 <span>Ubicación</span>
 <p>San Salvador, El Salvador</p>
 </div>
 </div>

 <div class="info-item">
 <i class="fas fa-clock"></i>
 <div>
 <span>Horario de atención</span>
 <p>Lunes a viernes, 8:00 a.m. — 5:00 p.m.</p>
 </div>
 </div>

 <div class="info-item">
 <i class="fas fa-gamepad"></i>
 <div>
 <span>¿Sabías que...?</span>
 <p>También puedes explorar nuestros <a href="{{ route('juegos.index') }}" style="color:#7C5CBF;font-weight:700">juegos gratuitos</a> sin necesidad de crear una cuenta.</p>
 </div>
 </div>
 </div>
 </div>
</div>

<footer>Miniminds — Apoyo a infancias adaptativas · <a href="{{ route('home') }}">Volver al inicio</a>
</footer>

</body>
</html>
