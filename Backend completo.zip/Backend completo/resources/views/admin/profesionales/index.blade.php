@extends('layouts.admin')
@section('title', 'Especialistas — Miniminds')

@section('content')
<h2 style="font-weight:800;margin-bottom:20px">Especialistas</h2>

<div class="pt-card p-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="font-size:11px;text-transform:uppercase;opacity:.6">
                <th>Nombre</th><th>Correo</th><th>Especialidad</th><th>Teléfono</th><th>Pacientes</th>
            </tr>
        </thead>
        <tbody>
            @forelse($profesionales as $p)
                <tr>
                    <td>{{ $p->nombre }} {{ $p->apellido }}</td>
                    <td>{{ $p->user->email ?? '—' }}</td>
                    <td>{{ $p->especialidad ?? '—' }}</td>
                    <td>{{ $p->telefono ?? '—' }}</td>
                    <td>{{ $p->pacientes()->count() }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-center py-3" style="opacity:.6">No hay especialistas registrados.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
