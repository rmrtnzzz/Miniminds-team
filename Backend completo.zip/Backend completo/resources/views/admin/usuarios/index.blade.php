@extends('layouts.admin')
@section('title', 'Usuarios — Miniminds')

@section('content')
<h2 style="font-weight:800;margin-bottom:20px">Usuarios</h2>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="pt-card p-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="font-size:11px;text-transform:uppercase;opacity:.6">
                <th>Nombre</th><th>Correo</th><th>Rol actual</th><th>Cambiar rol</th>
            </tr>
        </thead>
        <tbody>
            @foreach($usuarios as $u)
                <tr>
                    <td>{{ $u->name }} {{ $u->apellido }}</td>
                    <td>{{ $u->email }}</td>
                    <td><span style="text-transform:capitalize">{{ $u->role }}</span></td>
                    <td>
                        <form action="{{ route('admin.usuarios.rol', $u->id) }}" method="POST" class="d-flex gap-2">
                            @csrf @method('PUT')
                            <select name="role" class="form-select form-select-sm" style="width:auto">
                                <option value="usuario" {{ $u->role=='usuario'?'selected':'' }}>Usuario</option>
                                <option value="especialista" {{ $u->role=='especialista'?'selected':'' }}>Especialista</option>
                                <option value="admin" {{ $u->role=='admin'?'selected':'' }}>Admin</option>
                            </select>
                            <button type="submit" class="btn btn-sm btn-acento">Guardar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
