<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Cita;
use App\Models\Paciente;
use App\Models\Profesional;
use App\Models\SolicitudPaciente;
use App\Models\User;

class AdminController extends Controller
{
    
    public function inicio()
    {
        $metrica = [
            'usuarios'      => User::where('role', User::ROLE_USUARIO)->count(),
            'especialistas' => User::where('role', User::ROLE_ESPECIALISTA)->count(),
            'admins'        => User::where('role', User::ROLE_ADMIN)->count(),
            'pacientes'     => Paciente::count(),
            'citas'         => Cita::count(),
            'solicitudes_pendientes' => SolicitudPaciente::pendientes()->count(),
        ];

        $ultimasCitas = Cita::with(['paciente', 'profesional'])
            ->latest()
            ->limit(8)
            ->get();

        return view('admin.inicio', compact('metrica', 'ultimasCitas'));
    }

    
    public function usuarios()
    {
        $usuarios = User::orderBy('role')->orderBy('name')->get();
        return view('admin.usuarios.index', compact('usuarios'));
    }

    
    public function cambiarRol(\Illuminate\Http\Request $request, User $usuario)
    {
        $request->validate([
            'role' => 'required|in:usuario,especialista,admin',
        ]);

        $usuario->update(['role' => $request->role]);

        
        if ($request->role === User::ROLE_ESPECIALISTA && !Profesional::where('user_id', $usuario->id)->exists()) {
            Profesional::create([
                'user_id'   => $usuario->id,
                'nombre'    => $usuario->name,
                'apellido'  => $usuario->apellido ?? '',
                'telefono'  => $usuario->telefono,
            ]);
        }

        return back()->with('success', 'Rol actualizado correctamente.');
    }

    public function pacientes()
    {
        $pacientes = Paciente::with(['user', 'profesional'])->orderBy('nombre')->get();
        return view('admin.pacientes.index', compact('pacientes'));
    }

    public function profesionales()
    {
        $profesionales = Profesional::with('user')->orderBy('nombre')->get();
        return view('admin.profesionales.index', compact('profesionales'));
    }

    public function citas()
    {
        $citas = Cita::with(['paciente', 'profesional'])
            ->orderBy('fecha', 'desc')
            ->orderBy('hora', 'desc')
            ->get();
        return view('admin.citas.index', compact('citas'));
    }

    public function solicitudes()
    {
        $solicitudes = SolicitudPaciente::with(['user', 'profesional', 'paciente'])
            ->latest()
            ->get();
        return view('admin.solicitudes.index', compact('solicitudes'));
    }
}
