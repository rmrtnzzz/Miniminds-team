
document.addEventListener('DOMContentLoaded', () => {

    // EFECTO DE BARRA DE NAVEGACIÓN AL BAJAR
    const barraNavegacion = document.querySelector('.navbarcontenido');
    if (barraNavegacion) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 40) {
                barraNavegacion.classList.add('scrolled');
            } else {
                barraNavegacion.classList.remove('scrolled');
            }
        });
    }

    // GESTIÓN DE BOTONES ACTIVOS EN EL MENÚ 
    const botonesNavegacion = document.querySelectorAll('.nav-btn');
    botonesNavegacion.forEach((boton) => {
        boton.addEventListener('click', () => {
            botonesNavegacion.forEach(b => b.classList.remove('active'));
            boton.classList.add('active');
        });
    });

    // MENÚS DESPLEGABLES 
    const elementosNavegacion = document.querySelectorAll('.nav-item');
    elementosNavegacion.forEach((elemento) => {
        const menuDesplegable = elemento.querySelector('.dropdown');
        const flechaChevron = elemento.querySelector('.chevron');

        if (menuDesplegable) {
            elemento.addEventListener('mouseenter', () => {
                menuDesplegable.classList.add('show');
                if (flechaChevron) flechaChevron.classList.add('open');
            });

            elemento.addEventListener('mouseleave', () => {
                menuDesplegable.classList.remove('show');
                if (flechaChevron) flechaChevron.classList.remove('open');
            });
        }
    });

    // CONTROL DE VENTANA EMERGENTE DE AJUSTES
    const botonAbrirAjustes = document.getElementById('gear-icon');
    const contenedorVentana = document.querySelector('.ventana-contenedor');
    const botonCerrarAjustes = document.querySelector('.equis');

    if (botonAbrirAjustes && contenedorVentana && botonCerrarAjustes) {
        botonAbrirAjustes.addEventListener('click', () => {
            contenedorVentana.classList.add('show');
        });

        botonCerrarAjustes.addEventListener('click', () => {
            contenedorVentana.classList.remove('show');
        });

        // CERRAR LA VENTANA EMERGENTE AL HACER CLIC FUERA DEL CUADRO
        contenedorVentana.addEventListener('click', (evento) => {
            if (evento.target === contenedorVentana) {
                contenedorVentana.classList.remove('show');
            }
        });
    }

    // CONTROL DEL ACORDEÓN DE NIVELES DE APOYO
    const botonesAcordeon = document.querySelectorAll(".toggle");

    botonesAcordeon.forEach(boton => {
        boton.addEventListener("click", () => {
            const tarjetaPadre = boton.closest(".tarjeta");

            if (tarjetaPadre) {
                tarjetaPadre.classList.toggle("active");

                const textoBoton = boton.querySelector("span");
                if (textoBoton) {
                    if (tarjetaPadre.classList.contains("active")) {
                        textoBoton.textContent = "Ver menos detalles";
                    } else {
                        textoBoton.textContent = "Ver más detalles";
                    }
                }
            }
        });
    });

    // CONTROL DEL CARRUSEL 
    const diapositivas = document.querySelectorAll(".slide");
    const contenedorIndicadores = document.querySelector(".indicadores");
    const botonSiguiente = document.querySelector(".next");
    const botonAnterior = document.querySelector(".prev");

    let indiceActual = 0;

    if (diapositivas.length > 0 && contenedorIndicadores) {
        contenedorIndicadores.innerHTML = "";

        diapositivas.forEach((_, indice) => {
            const barraIndicadora = document.createElement("div");
            barraIndicadora.classList.add("indicador");

            if (indice === 0) {
                barraIndicadora.classList.add("activo");
            }

            barraIndicadora.addEventListener("click", () => {
                mostrarDiapositiva(indice);
            });

            contenedorIndicadores.appendChild(barraIndicadora);
        });

        const listaIndicadores = document.querySelectorAll(".indicador");

        function mostrarDiapositiva(indice) {
            diapositivas.forEach(slide => slide.classList.remove("activo"));
            listaIndicadores.forEach(barra => barra.classList.remove("activo"));

            diapositivas[indice].classList.add("activo");
            if (listaIndicadores[indice]) {
                listaIndicadores[indice].classList.add("activo");
            }

            indiceActual = indice;
        }

        if (botonSiguiente) {
            botonSiguiente.addEventListener("click", () => {
                indiceActual++;
                if (indiceActual >= diapositivas.length) {
                    indiceActual = 0;
                }
                mostrarDiapositiva(indiceActual);
            });
        }

        if (botonAnterior) {
            botonAnterior.addEventListener("click", () => {
                indiceActual--;
                if (indiceActual < 0) {
                    indiceActual = diapositivas.length - 1;
                }
                mostrarDiapositiva(indiceActual);
            });
        }
    }

});