@extends('layouts.maestroslayout')

@section('titulo', 'Guía para Maestros - MiniMinds')

@section('tema')

<header>
    <img src="{{ asset('/IMG/maestrosbanner.jpg') }}" alt="" class="imagenHero">

    <div class="hero-contenido">
        <p class="subtitulo-hero">Estrategias para un aula inclusiva</p>
        <h1 class="titulo-hero">GUÍA PARA MAESTROS</h1>
        <p class="desliza">↓ Desliza hacia abajo ↓</p>
    </div>
</header>

<main class="contenedorinfo">

    <section class="seccionEspecificaMaestros">
        <div class="cuadroIntroAula">
            <div class="textoIntroAula">
                <h1>El aula como espacio de aprendizaje inclusivo</h1>
                <p>
                    Adaptar el entorno educativo beneficia a todo el grupo escolar. Las adaptaciones no significan reducir exigencias, sino proporcionar vías diversas para que cada estudiante comprenda, participe y demuestre lo aprendido según sus fortalezas.
                </p>
            </div>
            <div class="imagenIntroAula">
                <img src="{{ asset('/IMG/aulaInclusiva.jpg') }}" alt="" class="imagenAulaEscolar">
            </div>
        </div>
    </section>

    <section class="seccionEspecificaMaestros">
        <span class="badgeSubtituloSeccion">Metodología en el aula</span>
        <h1 class="tituloSeccionCentral">Adaptaciones Pedagógicas Principales</h1>

        <div class="filasAdaptacionesMaestros">
            <div class="bloqueFilaMetodologia">
                <div class="cabeceraFila">
                    <span class="iconoFila">01</span>
                    <h3>Organización del Espacio y Estímulos</h3>
                </div>
                <p>Ubicación estratégica cerca del docente o lejos de distracciones visuales/auditivas intensas. Uso de rincones tranquilos para pausas breves de autorregulación.</p>
            </div>

            <div class="bloqueFilaMetodologia">
                <div class="cabeceraFila">
                    <span class="iconoFila">02</span>
                    <h3>Presentación de las Actividades</h3>
                </div>
                <p>Segmentar tareas largas en instrucciones cortas y numeradas. Incorporar apoyos visuales, esquemas gráficos y materiales manipulativos prácticos.</p>
            </div>

            <div class="bloqueFilaMetodologia">
                <div class="cabeceraFila">
                    <span class="iconoFila">03</span>
                    <h3>Evaluación Diversificada</h3>
                </div>
                <p>Ofrecer opciones para responder de forma oral, mediante proyectos prácticos o respuestas cortas, respetando los tiempos de procesamiento del estudiante.</p>
            </div>
        </div>
    </section>

    <section class="seccionEspecificaMaestros">
        <h1 class="tituloSeccionCentral">Estrategias Específicas por Necesidad</h1>

        <div class="contenedorDesplegableMaestros">
            <div class="tarjetaDesplegableAula">
                <button type="button" class="botonToggleMaestros">
                    <span>Atención y Funciones Ejecutivas</span>
                    <span class="signoDesplegable">+</span>
                </button>
                <div class="contenidoDesplegableAula">
                    <ul>
                        <li>Uso de temporizadores visuales para marcar tiempos de trabajo.</li>
                        <li>Pausas activas cortas entre clases extensas.</li>
                        <li>Verificación individual del inicio de la tarea.</li>
                    </ul>
                </div>
            </div>

            <div class="tarjetaDesplegableAula">
                <button type="button" class="botonToggleMaestros">
                    <span>Procesamiento Sensorial en el Colegio</span>
                    <span class="signoDesplegable">+</span>
                </button>
                <div class="contenidoDesplegableAula">
                    <ul>
                        <li>Anticipación previa de timbres o simulacros ruidosos.</li>
                        <li>Permiso para usar auriculares con cancelación en momentos de trabajo individual.</li>
                        <li>Flexibilidad postural durante lecturas prolongadas.</li>
                    </ul>
                </div>
            </div>

            <div class="tarjetaDesplegableAula">
                <button type="button" class="botonToggleMaestros">
                    <span>Interacción Social y Trabajo en Equipo</span>
                    <span class="signoDesplegable">+</span>
                </button>
                <div class="contenidoDesplegableAula">
                    <ul>
                        <li>Asignación clara de roles concretos dentro de los grupos.</li>
                        <li>Sensibilización empática hacia la diversidad en la clase.</li>
                        <li>Mediación serena en situaciones de conflicto o desacuerdo.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionEspecificaMaestros">
        <h1 class="tituloSeccionCentral">Protocolo de Actuación ante Sobrecarga</h1>

        <div class="cuadroProtocoloPasos">
            <div class="tarjetaPasoProtocolo">
                <div class="numeroProtocolo">1</div>
                <h4>Detectar Señales</h4>
                <p>Identificar inquietud motora o aislamiento antes de que ocurra el malestar.</p>
            </div>

            <div class="tarjetaPasoProtocolo">
                <div class="numeroProtocolo">2</div>
                <h4>Ofrecer Espacio</h4>
                <p>Invitar de forma discreta al rincón tranquilo sin exponerlo ante sus compañeros.</p>
            </div>

            <div class="tarjetaPasoProtocolo">
                <div class="numeroProtocolo">3</div>
                <h4>Validar Emoción</h4>
                <p>Mantener un tono bajo y dar tiempo para restablecer la calma sin presionar.</p>
            </div>
        </div>
    </section>

</main>

@endsection