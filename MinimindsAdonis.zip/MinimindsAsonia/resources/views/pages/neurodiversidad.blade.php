@extends('layouts.neurodivlayout')

@section('titulo', 'Neurodiversidad y Desarrollo Infantil - MiniMinds')

@section('tema')

<!-- BANNER PRINCIPAL DE LA PÁGINA -->
<header>
    <img src="{{ asset('/IMG/neurobanner.jpg') }}" alt="" class="imagenHero">

    <div class="hero-contenido">
        <p class="subtitulo-hero">Neurodivergencias y desarrollo infantil</p>
        <h1 class="titulo-hero">NEURODIVERSIDAD EN LA INFANCIA</h1>
        <p class="desliza">↓ Desliza hacia abajo ↓</p>
    </div>
</header>


<main class="contenedorinfo">

    <!-- RECTÁNGULO DE QUÉ ES LA NEURODIVERSIDAD -->
    <section class="seccion-bloque" id="neurodiversidades">
        <div class="cuadroinfo">
            <img src="{{ asset('/IMG/neurodiversidad.jpg') }}" alt="" class="imagenPrincipal">
            <div class="textoinfo">
                <h1>¿Qué es la Neurodiversidad?</h1>
                <p>
                    La neurodiversidad es el concepto que reconoce que el cerebro humano funciona de manera diversa y única en cada individuo. Fue acuñado por la socióloga Judy Singer para destacar que variaciones en el desarrollo neurológico, como el espectro autista, el TDAH o la dislexia, no son enfermedades ni defectos que deban ser corregidos, sino formas distintas e igualmente válidas de percibir, aprender y desenvolverse en el entorno.
                </p>
            </div>
        </div>
    </section>

    <!-- RECTÁNGULO DE POR QUÉ HABLAMOS DE NEURODIVERSIDAD -->
    <section class="seccion-bloque">
        <div class="pq-destacado">
            <div class="tarjeta-blanca-destacada">
                <div class="pq-contenido-grid">
                    <div class="columnatexto">
                        <h1>¿Por qué hablamos de "Neurodiversidad"?</h1>
                        <p>
                            Hablar de neurodiversidad promueve un cambio de paradigma: nos permite alejar la mirada de los estigmas o las etiquetas para enfocarnos en comprender las necesidades particulares de cada niña y niño durante sus primeras etapas de crecimiento.
                        </p>
                        <p>
                            En el desarrollo infantil temprano, este enfoque garantiza que los entornos escolares y familiares ofrezcan adaptaciones adecuadas, asegurando el respeto a la dignidad humana, la equidad en el aprendizaje y una convivencia armónica.
                        </p>
                    </div>
                    <div class="imagenDesarrolloInfantil">
                        <img src="{{ asset('/IMG/desarrolloinfantil.jpg') }}" alt="" class="imagenPresentacion">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- TARJETITAS CON HOVER DE CÓMO SE MANIFIESTA LA NEURODIVERSIDAD -->
    <section class="seccion-bloque">
        <div class="funciona">
            <span class="badge-subtitulo">Manifestaciones en la infancia</span>
            <h1>¿Cómo se manifiesta la neurodiversidad?</h1>
            <p class="descripcion-intro">
                Cada niña y niño neurodivergente presenta un perfil único de fortalezas y desafíos. Estas variaciones se manifiestan principalmente en cuatro áreas del desarrollo infantil:
            </p>

            <div class="cuadrofunciona">
                <div class="columnaizquierda">
                    <div class="tarjetafuncion">
                        <h3>Procesamiento Cognitivo</h3>
                        <p>Formas distintas de razonar, aprender conceptos nuevos y organizar la información aprendida.</p>
                    </div>
                    <div class="tarjetafuncion">
                        <h3>Comunicación e Interacción</h3>
                        <p>Estilos diversos para expresar pensamientos, comprender lenguaje corporal y socializar.</p>
                    </div>
                </div>

                <div class="centro">
                    <div class="circulocerebro">
                        <img src="{{ asset('/IMG/cerebromorado.jpg') }}" alt="" class="cerebroImagen">
                    </div>
                </div>

                <div class="columnaderecha">
                    <div class="tarjetafuncion">
                        <h3>Funciones Ejecutivas</h3>
                        <p>Variaciones en la regulación de la atención, la memoria de trabajo y la planificación diaria.</p>
                    </div>
                    <div class="tarjetafuncion">
                        <h3>Regulación Emocional</h3>
                        <p>Diferencias en la intensidad con la que se perciben y gestionan las emociones y los estímulos del entorno.</p>
                    </div>
                </div>
            </div>
            <p class="indicador-interaccion">Representación del desarrollo neurológico integral</p>
        </div>
    </section>

    <!-- TARJETITAS CON HOVER DE PROCESAMIENTO SENSORIAL EN LA INFANCIA -->
    <section class="seccion-bloque" id="sensorialidad">
        <div class="cuadrosensorial">
            <div class="encabezado-centrado">
                <h1>El Procesamiento Sensorial en la Infancia</h1>
                <p class="texto-ancho">
                    El sistema sensorial recibe estímulos del entorno a través de la vista, el oído, el tacto, el gusto, el olfato, la propiocepción y el sistema vestibular.
                </p>
            </div>

            <div class="cuadrotarjetassentido">
                <div class="tarjetasentido">
                    <h3>Hipersensibilidad</h3>
                    <p>Reacción intensa o malestar ante luces fuertes, ruidos altos o ciertas texturas de ropa y alimentos.</p>
                </div>
                <div class="tarjetasentido">
                    <h3>Hiposensibilidad</h3>
                    <p>Búsqueda activa de estímulos profundos, como movimiento continuo, abrazos fuertes o sonidos para autorregularse.</p>
                </div>
                <div class="tarjetasentido">
                    <h3>Integración Sensorial</h3>
                    <p>Capacidad del cerebro para organizar la información sensorial y responder adecuadamente a las exigencias diarias.</p>
                </div>
                <div class="tarjetasentido">
                    <h3>Soportes Sensoriales</h3>
                    <p>Uso de auriculares con cancelación de ruido, espacios tranquilos y elementos de autorregulación en casa o aula.</p>
                </div>
            </div>
        </div>
    </section>

    <<!-- ACORDEONES DE NIVELES DE APOYO -->
    <section class="seccion-bloque" id="nivelesApoyo">
        <div class="niveles-seccion">
            <h1>Niveles de Apoyo para Neurodivergencias</h1>
            <div class="random">
                <p>
                    Los niveles de apoyo describen la intensidad del acompañamiento que un niño o niña necesita para desenvolverse en sus actividades diarias. <span>Estos apoyos no son fijos, cambian según el entorno y la etapa de desarrollo.</span>
                </p>
            </div>

            <div class="cuadrotarjetas">

                <!-- APOYO UNIVERSAL -->
                <div class="tarjeta rosa">
                    <div class="icono">
                        <h1>1</h1>
                    </div>
                    <h3>Apoyo Universal</h3>
                    <p class="short">
                        Ajustes sencillos e inclusivos accesibles para todos los niños en la escuela y el hogar.
                    </p>

                    <button type="button" class="toggle">
                        <span>Ver más detalles</span>
                    </button>

                    <div class="extra">
                        <ul>
                            <li>Uso de agendas visuales y horarios con pictogramas.</li>
                            <li>Instrucciones claras, breves y segmentadas por pasos.</li>
                            <li>Espacios iluminados y ventilados sin exceso de ruido.</li>
                            <li>Anticipación previa de cambios en la rutina diaria.</li>
                        </ul>
                        <p>
                            Este nivel fortalece la autonomía inicial y permite que los niños se sientan seguros en entornos estructurados.
                        </p>
                    </div>
                </div>

                <!-- APOYO FOCALIZADO -->
                <div class="tarjeta naranja">
                    <div class="icono">
                        <h1>2</h1>
                    </div>
                    <h3>Apoyo Focalizado</h3>
                    <p class="short">
                        Estrategias dirigidas a niños que requieren refuerzo en áreas específicas de aprendizaje o conducta.
                    </p>

                    <button type="button" class="toggle">
                        <span>Ver más detalles</span>
                    </button>

                    <div class="extra">
                        <ul>
                            <li>Acompañamiento pedagógico individualizado o en pequeños grupos.</li>
                            <li>Uso de material didáctico táctil y herramientas adaptadas.</li>
                            <li>Técnicas de mediación para el desarrollo de habilidades sociales.</li>
                            <li>Pausas activas periódicas durante actividades extensas.</li>
                        </ul>
                        <p>
                            Ofrece herramientas puntuales que facilitan la concentración, la comunicación y el trabajo colaborativo.
                        </p>
                    </div>
                </div>

                <!-- APOYO INTENSIVO -->
                <div class="tarjeta azul">
                    <div class="icono">
                        <h1>3</h1>
                    </div>
                    <h3>Apoyo Intensivo</h3>
                    <p class="short">
                        Acompañamiento especializado y continuo para necesidades significativas en el día a día.
                    </p>

                    <button type="button" class="toggle">
                        <span>Ver más detalles</span>
                    </button>

                    <div class="extra">
                        <ul>
                            <li>Intervención de equipo multidisciplinario (psicología, terapia ocupacional, lenguaje).</li>
                            <li>Sistemas alternativos y aumentativos de comunicación (SAAC).</li>
                            <li>Planes de apoyo individualizados en el aula (PAI).</li>
                            <li>Acompañamiento constante para la autorregulación sensorial y emocional.</li>
                        </ul>
                        <p>
                            Proporciona atención experta constante para impulsar la comunicación, el bienestar integral y el aprendizaje.
                        </p>
                    </div>
                </div>

            </div>

            <div class="nota-aclaratoria">
                <p>
                    <span>Nota:</span> La asignación de apoyos siempre debe ser evaluada por profesionales de la salud y educación en estrecha comunicación con la familia.
                </p>
            </div>
        </div>
    </section>

    <!-- CARRUSEL DE NEURODIVERGENCIAS -->
    <section class="seccion-bloque">
        <h1>Condiciones Neurodivergentes Frecuentes</h1>

        <div class="carrusel">
            <button type="button" class="flecha prev">&lt;</button>

            <div class="slider">

                <!-- AUTISMO -->
                <div class="slide activo">
                    <div class="slide-texto">
                        <h2>Trastorno del Espectro Autista (TEA)</h2>
                        <p>
                            Se caracteriza por variaciones en el procesamiento sensorial, patrones de comunicación propios e intereses profundos en temas específicos. El acompañamiento fortalece la interacción social y la comprensión del entorno.
                        </p>
                        <button type="button" class="btn-slide">Saber más</button>
                    </div>
                    <div class="slide-imagen">
                        <img src="{{ asset('/IMG/autismo.png') }}" alt="">
                    </div>
                </div>

                <!-- TDAH -->
                <div class="slide">
                    <div class="slide-texto">
                        <h2>Trastorno por Déficit de Atención e Hiperactividad (TDAH)</h2>
                        <p>
                            Se manifiesta en altos niveles de energía, curiosidad constante, impulsividad o variaciones en el mantenimiento de la atención. Estrategias como actividades dinámicas y pausas frecuentes optimizan su rendimiento.
                        </p>
                        <button type="button" class="btn-slide">Saber más</button>
                    </div>
                    <div class="slide-imagen">
                        <img src="{{ asset('/IMG/tdah.png') }}" alt="">
                    </div>
                </div>

                <!--DISLEXIA -->
                <div class="slide">
                    <div class="slide-texto">
                        <h2>Dislexia y Dificultades de Aprendizaje</h2>
                        <p>
                            Forma particular de procesar el lenguaje escrito que afecta la fluidez lectora y la escritura, sin comprometer la capacidad intelectual. La enseñanza multisensorial facilita la lectoescritura.
                        </p>
                        <button type="button" class="btn-slide">Saber más</button>
                    </div>
                    <div class="slide-imagen">
                        <img src="{{ asset('/IMG/dislexia.png') }}" alt="">
                    </div>
                </div>

            </div>

            <button type="button" class="flecha next">&gt;</button>

            <!-- INDICADORES DINÁMICOS DEL CARRUSEL -->
            <div class="indicadores"></div>
        </div>
    </section>

    <!-- CUADRITOS DE HERRAMIENTAS DE ACOMPAÑAMIENTO CON HOVER -->
    <section class="seccion-bloque" id="acompanamiento">
        <div class="adaptacion-seccion">
            <h1 class="titulo-seccion">Herramientas de Acompañamiento</h1>

            <div class="cuadrotarjetasadapt">
                <div class="tarjetaadapt">
                    <img src="{{ asset('/IMG/padres.png') }}" alt="">
                    <div class="contenido">
                        <h3>Guía para Padres</h3>
                        <p>Orientaciones sencillas para fomentar un hogar seguro, estructurado y afectuoso.</p>
                    </div>
                </div>

                <div class="tarjetaadapt">
                    <img src="{{ asset('/IMG/maestros.png') }}" alt="">
                    <div class="contenido">
                        <h3>Guía para Maestros</h3>
                        <p>Estrategias pedagógicas y adaptaciones metodológicas en el aula escolar.</p>
                    </div>
                </div>

                <div class="tarjetaadapt">
                    <img src="{{ asset('/IMG/test.png') }}" alt="">
                    <div class="contenido">
                        <h3>Test Orientador</h3>
                        <p>Cuestionario guía para identificar señales tempranas de apoyo conductual o cognitivo.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- AVISO Y REDIRECCIONAMIENTO A LA SECCIÓN DE ADAPTACIÓN -->
    <section class="seccion-bloque" id="testOrientador">
        <div class="test-footer-info">
            <div class="cuadroaviso">
                <p class="test-nota-importante">
                    <strong>Aviso importante:</strong> La información disponible en 
                    NEUROMINIMINDS! tiene un propósito netamente educativo e informativo. No sustituye la evaluación clínica realizada por psicólogos infantiles o neuropediatras.
                </p>
                <a href="adaptacion" class="boton-test-wrapper">
                    <button type="button" class="boton-iniciar-test-bonito">
                        Estrategias de Adaptación <span class="flecha-btn">→</span>
                    </button>
                </a>
            </div>
        </div>
    </section>

</main>

@endsection