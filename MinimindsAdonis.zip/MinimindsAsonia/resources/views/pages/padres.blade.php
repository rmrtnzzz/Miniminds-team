@extends('layouts.padreslayout')

@section('titulo', 'Guía para Padres - MiniMinds')

@section('tema')

<header>
    <img src="{{ asset('/IMG/padresbanner.jpg') }}" alt="" class="imagenHero">

    <div class="hero-contenido">
        <p class="subtitulo-hero">Acompañamiento familiar consciente</p>
        <h1 class="titulo-hero">GUÍA PARA PADRES</h1>
        <p class="desliza">↓ Desliza hacia abajo ↓</p>
    </div>
</header>

<main class="contenedorinfo">

    <section class="seccionEspecíficaPadres">
        <div class="cuadroIntroHogar">
            <div class="textoIntroHogar">
                <h1>Crear un entorno seguro en el hogar</h1>
                <p>
                    El hogar es el primer espacio de desarrollo y aprendizaje. Brindar un ambiente predecible, afectuoso y estructurado permite a las niñas y niños sentirse seguros, facilitando su autorregulación emocional y el fortalecimiento de su autonomía diaria.
                </p>
            </div>
            <div class="imagenIntroHogar">
                <img src="{{ asset('/IMG/hogarSeguro.jpg') }}" alt="" class="imagenFamiliaHogar">
            </div>
        </div>
    </section>

    <section class="seccionEspecíficaPadres">
        <span class="badgeSubtituloSeccion">Herramientas prácticas</span>
        <h1 class="tituloSeccionCentral">Estrategias Clave para la Rutina Diaria</h1>

        <div class="tableroCuadrosPadres">
            <div class="tarjetaEstrategiaHogar">
                <div class="iconoEstrategia">
                    <img src="{{ asset('/IMG/rutinas.png') }}" alt="" class="imagenIconoEstrategia">
                </div>
                <h3>Estructura Visual</h3>
                <p>Implementa pictogramas y horarios ilustrados en lugares visibles para anticipar las actividades del día.</p>
            </div>

            <div class="tarjetaEstrategiaHogar">
                <div class="iconoEstrategia">
                    <img src="{{ asset('/IMG/emociones.png') }}" alt="" class="imagenIconoEstrategia">
                </div>
                <h3>Regulación Emocional</h3>
                <p>Ofrece un rincón de calma con cojines, texturas suaves o música relajante para momentos de sobrecarga.</p>
            </div>

            <div class="tarjetaEstrategiaHogar">
                <div class="iconoEstrategia">
                    <img src="{{ asset('/IMG/comunicacion.png') }}" alt="" class="imagenIconoEstrategia">
                </div>
                <h3>Lenguaje Claro</h3>
                <p>Da instrucciones simples, directas y paso a paso, manteniendo un tono de voz sereno y empático.</p>
            </div>

            <div class="tarjetaEstrategiaHogar">
                <div class="iconoEstrategia">
                    <img src="{{ asset('/IMG/tiempoLibre.png') }}" alt="" class="imagenIconoEstrategia">
                </div>
                <h3>Juego Libre</h3>
                <p>Respeta los intereses espontáneos del niño y acompáñalo en sus juegos sin imponer reglas complejas.</p>
            </div>
        </div>
    </section>

    <section class="seccionEspecíficaPadres">
        <h1 class="tituloSeccionCentral">Secuencia Diaria en Casa</h1>
        <p class="descripcionCentral">Organizar los momentos principales del día reduce la ansiedad y mejora la convivencia familiar.</p>

        <div class="lineaTiempoPasos">
            <div class="pasoMomentoDia">
                <div class="cabeceraPaso">
                    <span class="etiquetaPaso">Momento 1</span>
                    <h3>Mañanas y Salida a la Escuela</h3>
                </div>
                <p>Dejar la ropa y la mochila preparadas la noche anterior evita prisas y reduce el estrés matutino.</p>
            </div>

            <div class="pasoMomentoDia">
                <div class="cabeceraPaso">
                    <span class="etiquetaPaso">Momento 2</span>
                    <h3>Regreso a Casa y Descanso</h3>
                </div>
                <p>Permitir un tiempo de desconexión o merienda tranquila antes de iniciar tareas o actividades estructuradas.</p>
            </div>

            <div class="pasoMomentoDia">
                <div class="cabeceraPaso">
                    <span class="etiquetaPaso">Momento 3</span>
                    <h3>Rutina Nocturna y Sueño</h3>
                </div>
                <p>Mantener horarios fijos para el baño, cena y lectura de cuentos favorece un descanso reparador.</p>
            </div>
        </div>
    </section>

    <section class="seccionEspecíficaPadres">
        <h1 class="tituloSeccionCentral">Mitos y Realidades sobre el Acompañamiento</h1>

        <div class="carruselMitos">
            <button type="button" class="flechaCarruselPadres anteriorMito">&lt;</button>

            <div class="contenedorMitoDiapositiva">

                <div class="diapositivaMito activa">
                    <div class="tarjetaMitoBloque">
                        <span class="etiquetaMito">Mito</span>
                        <h3>"Las rutinas estrictas limitan la creatividad del niño."</h3>
                    </div>
                    <div class="tarjetaRealidadBloque">
                        <span class="etiquetaRealidad">Realidad</span>
                        <p>Las rutinas estructuradas le brindan previsibilidad, lo que reduce la ansiedad y le da tranquilidad para explorar su creatividad de forma segura.</p>
                    </div>
                </div>

                <div class="diapositivaMito">
                    <div class="tarjetaMitoBloque">
                        <span class="etiquetaMito">Mito</span>
                        <h3>"Si no habla a la misma edad que otros, no se está esforzando."</h3>
                    </div>
                    <div class="tarjetaRealidadBloque">
                        <span class="etiquetaRealidad">Realidad</span>
                        <p>Cada niño tiene ritmos de desarrollo particulares. Existen múltiples formas válidas de comunicación que deben ser respetadas y apoyadas.</p>
                    </div>
                </div>

            </div>

            <button type="button" class="flechaCarruselPadres siguienteMito">&gt;</button>
        </div>
    </section>

</main>

@endsection