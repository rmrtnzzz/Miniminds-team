@extends('layouts.tdalayout')

@section('titulo', 'Trastorno por Déficit de Atención (TDA) - MiniMinds')

@section('tema')

<header>
    <img src="{{ asset('/IMG/neurobanner.jpg') }}" alt="" class="imagenHero">

    <div class="hero-contenido">
        <p class="subtitulo-hero">Predominio inatento en la infancia</p>
        <h1 class="titulo-hero">TRASTORNO POR DÉFICIT DE ATENCIÓN (TDA)</h1>
        <p class="desliza">↓ Desliza hacia abajo ↓</p>
    </div>
</header>

<main class="contenedorinfo">

    <section class="seccionbloque" id="conceptotda">
        <div class="cuadroconceptotda">
            <div class="bloquepremisa">
                <span class="badgetda">Perfil Inatento</span>
                <h1>¿Qué es el Trastorno por Déficit de Atención?</h1>
                <p>
                    El Trastorno por Déficit de Atención con predominio inatento es una variante neurobiológica caracterizada por dificultades persistentes para mantener la concentración, organizar tareas cotidianas y procesar estímulos auditivos o escritos con la misma velocidad que otros niños.
                </p>
                <p>
                    A diferencia de otras manifestaciones, en el TDA no predomina la inquietud motora ni la hiperactividad visible. Por esta razón, suele pasar desapercibido en las primeras etapas escolares, siendo confundido frecuentemente con desinterés o falta de esfuerzo.
                </p>
            </div>
            <div class="imagencontenidotda">
                <img src="{{ asset('/IMG/desarrolloinfantil.jpg') }}" alt="" class="imagendestacadatda">
            </div>
        </div>
    </section>

    <section class="seccionbloque">
        <div class="cuadropilaresinatencion">
            <div class="encabezadosecciontda">
                <span class="badgetda">Manifestaciones Clave</span>
                <h1>Características Principales del TDA</h1>
                <p class="textocentradotda">
                    El perfil inatento afecta principalmente las funciones ejecutivas del cerebro infantil, manifestándose de formas específicas durante las actividades diarias.
                </p>
            </div>

            <div class="filatarjetascaracteristicas">
                <div class="tarjetacaracteristicatda">
                    <div class="circulonumerotda">1</div>
                    <h3>Atención Sostenida</h3>
                    <p>Dificultad para mantener el foco en actividades extensas o rutinarias que carecen de estímulos novedosos o interactivos.</p>
                </div>

                <div class="tarjetacaracteristicatda">
                    <div class="circulonumerotda">2</div>
                    <h3>Memoria de Trabajo</h3>
                    <p>Tendencia a olvidar instrucciones complejas con múltiples pasos o perder la secuencia de las tareas indicadas en el aula.</p>
                </div>

                <div class="tarjetacaracteristicatda">
                    <div class="circulonumerotda">3</div>
                    <h3>Organización y Materiales</h3>
                    <p>Desafíos frecuentes para planificar tiempos de estudio, mantener cuadernos ordenados y conservar pertenencias escolares.</p>
                </div>

                <div class="tarjetacaracteristicatda">
                    <div class="circulonumerotda">4</div>
                    <h3>Procesamiento Lento</h3>
                    <p>Necesidad de mayor tiempo para asimilar información verbal o escrita y estructurar sus respuestas de forma clara.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionbloque">
        <div class="cuadrocomparativotda">
            <div class="encabezadosecciontda">
                <h1>Mitos y Realidades del TDA Inatento</h1>
                <p class="textocentradotda">Aclarar las ideas equivocadas ayuda a brindar una mejor comprensión y un apoyo afectivo libre de etiquetas.</p>
            </div>

            <div class="contenedortabs">
                <div class="panelmitorealidad">
                    <div class="columnamito">
                        <span class="etiquetamito">MITO</span>
                        <h3>"El niño es perezoso o no presta atención porque no quiere"</h3>
                    </div>
                    <div class="columnarealidad">
                        <span class="etiquetarealidad">REALIDAD</span>
                        <p>El TDA implica un esfuerzo cognitivo mayor para filtrar distracciones. La falta de atención no es una decisión del niño, sino una diferencia en la autorregulación cerebral.</p>
                    </div>
                </div>

                <div class="panelmitorealidad">
                    <div class="columnamito">
                        <span class="etiquetamito">MITO</span>
                        <h3>"Si no se mueve constantemente, no puede tener déficit de atención"</h3>
                    </div>
                    <div class="columnarealidad">
                        <span class="etiquetarealidad">REALIDAD</span>
                        <p>El TDA inatento no presenta hiperactividad física. La inquietud en estos niños suele ser interna, manifestándose como ensueño excesivo o desconexión del entorno.</p>
                    </div>
                </div>

                <div class="panelmitorealidad">
                    <div class="columnamito">
                        <span class="etiquetamito">MITO</span>
                        <h3>"No necesita adecuaciones porque aprueba las materias"</h3>
                    </div>
                    <div class="columnarealidad">
                        <span class="etiquetarealidad">REALIDAD</span>
                        <p>Muchos niños compensan las dificultades con un alto nivel de esfuerzo emocional, lo que genera fatiga mental, ansiedad y baja autoestima a mediano plazo.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionbloque">
        <div class="cuadroguiatda">
            <div class="encabezadosecciontda">
                <span class="badgetda">Estrategias de Acompañamiento</span>
                <h1>Estrategias Prácticas para el Desarrollo</h1>
                <p class="textocentradotda">Pequeños ajustes en la rutina escolar y familiar facilitan la autonomía y la concentración del niño.</p>
            </div>

            <div class="gridestrategiastda">
                <div class="tarjetaestrategiatda">
                    <div class="cabeceraestrategia">
                        <img src="{{ asset('/IMG/padres.png') }}" alt="" class="iconoestrategiatda">
                        <h3>Estructura Visual</h3>
                    </div>
                    <p>Implementar listas de cotejo con imágenes o palabras clave para organizar los deberes y mochilas de forma autónoma.</p>
                </div>

                <div class="tarjetaestrategiatda">
                    <div class="cabeceraestrategia">
                        <img src="{{ asset('/IMG/maestros.png') }}" alt="" class="iconoestrategiatda">
                        <h3>Pasos Segmentados</h3>
                    </div>
                    <p>Dividir asignaciones extensas en pequeñas metas cortas para evitar la saturación mental y mantener la motivación.</p>
                </div>

                <div class="tarjetaestrategiatda">
                    <div class="cabeceraestrategia">
                        <img src="{{ asset('/IMG/test.png') }}" alt="" class="iconoestrategiatda">
                        <h3>Entornos Reducidos</h3>
                    </div>
                    <p>Ubicar el área de estudio lejos de ventanas, pantallas o ruidos intensos que compitan por su foco de atención.</p>
                </div>

                <div class="tarjetaestrategiatda">
                    <div class="cabeceraestrategia">
                        <img src="{{ asset('/IMG/cerebromorado.jpg') }}" alt="" class="iconoestrategiatda">
                        <h3>Pausas Breves</h3>
                    </div>
                    <p>Programar descansos de dos a tres minutos entre tareas para refrescar la memoria de trabajo y la energía cognitiva.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionbloque">
        <div class="acordeontdafrecuente">
            <h1>Preguntas Frecuentes sobre el TDA</h1>
            <p class="textocentradotda">Respuestas orientativas para familias y educadores.</p>

            <div class="contenedoracordeontda">
                <div class="itemacordeontda">
                    <button type="button" class="botonacordeontda">
                        <span>¿A qué edad se suele identificar el TDA inatento?</span>
                        <span class="simboloacordeon">+</span>
                    </button>
                    <div class="contenidoacordeontda">
                        <p>Se suele identificar con mayor claridad entre los 7 y 9 años, cuando las exigencias académicas requieren mayor organización independiente y lectura comprensiva prolongada.</p>
                    </div>
                </div>

                <div class="itemacordeontda">
                    <button type="button" class="botonacordeontda">
                        <span>¿Cómo diferenciar la distracción común del TDA?</span>
                        <span class="simboloacordeon">+</span>
                    </button>
                    <div class="contenidoacordeontda">
                        <p>La distracción ocasional ocurre en situaciones específicas de cansancio. En el TDA, la inatención es frecuente, persistente en múltiples entornos y afecta la vida diaria del niño.</p>
                    </div>
                </div>

                <div class="itemacordeontda">
                    <button type="button" class="botonacordeontda">
                        <span>¿Qué papel juegan los docentes en el acompañamiento?</span>
                        <span class="simboloacordeon">+</span>
                    </button>
                    <div class="contenidoacordeontda">
                        <p>Los docentes son fundamentales al brindar instrucciones directas, permitir tiempos adicionales en evaluaciones y mantener una comunicación fluida con la familia.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionbloque">
        <div class="cuadroredirecciontda">
            <p class="textoredirecciontda">
                ¿Buscas información sobre hiperactividad o combinaciones conductuales? Conoce más en la sección especializada.
            </p>
            <a href="tdah" class="enlacebotonredireccion">
                <button type="button" class="botonredirecciontdah">
                    Ver Sección TDAH <span class="flecha-btn">→</span>
                </button>
            </a>
        </div>
    </section>

</main>

@endsection