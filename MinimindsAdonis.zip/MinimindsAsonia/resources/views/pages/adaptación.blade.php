@extends('layouts.adaplayout')

@section('titulo', 'Estrategias de Adaptación Infantil - MiniMinds')

@section('tema')

<header>
    <img src="{{ asset('/IMG/adaptacionbanner.jpg') }}" alt="" class="imagenHero">

    <div class="hero-contenido">
        <p class="subtitulo-hero">Acompañamiento e inclusión efectiva</p>
        <h1 class="titulo-hero">ESTRATEGIAS DE ADAPTACIÓN</h1>
        <p class="desliza">↓ Desliza hacia abajo ↓</p>
    </div>
</header>

<main class="contenedorinfo">

    <section class="seccionBloqueAdaptacion">
        <div class="encabezadoSeccionAdaptacion">
            <span class="etiquetaSeccionAdaptacion">Fundamentos prácticos</span>
            <h1 class="tituloPrincipalAdaptacion">Los Tres Pilares de la Adaptación</h1>
            <p class="textoIntroduccionAdaptacion">
                Adaptar los entornos no significa cambiar las exigencias del aprendizaje, sino ajustar los medios y el acompañamiento para que cada niña y niño neurodivergente pueda desenvolverse con confianza, seguridad y autonomía.
            </p>
        </div>

        <div class="gridPilaresAdaptacion">
            <div class="tarjetaPilarAdaptacion">
                <div class="numeroPilarAdaptacion">01</div>
                <h3 class="tituloPilarAdaptacion">Observación Activa</h3>
                <p class="textoPilarAdaptacion">
                    Identificar de forma anticipada las variables que generan sobrecarga sensorial, cansancio o frustración en las actividades cotidianas.
                </p>
            </div>

            <div class="tarjetaPilarAdaptacion">
                <div class="numeroPilarAdaptacion">02</div>
                <h3 class="tituloPilarAdaptacion">Ajuste del Entorno</h3>
                <p class="textoPilarAdaptacion">
                    Modificar la estructura física, los tiempos de trabajo y las formas de presentación de tareas para facilitar la comprensión.
                </p>
            </div>

            <div class="tarjetaPilarAdaptacion">
                <div class="numeroPilarAdaptacion">03</div>
                <h3 class="tituloPilarAdaptacion">Co-regulación Afectiva</h3>
                <p class="textoPilarAdaptacion">
                    Brindar un espacio de calma y orientación clara cuando se presentan momentos de desorganización emocional o conductual.
                </p>
            </div>
        </div>
    </section>

    <section class="seccionBloqueAdaptacion">
        <div class="cuadroEstrategiasEspeciales">
            <div class="encabezadoPestanasAdaptacion">
                <h1 class="tituloPrincipalAdaptacion">Adaptación según el Contexto</h1>
                <p class="textoIntroduccionAdaptacion">
                    Selecciona el área donde deseas implementar estrategias para conocer las pautas de apoyo recomendadas:
                </p>

                <div class="botonesPestanasAdaptacion">
                    <button type="button" class="botonPestanaAdaptacion activa" data-pestana="aula">En el Aula</button>
                    <button type="button" class="botonPestanaAdaptacion" data-pestana="hogar">En el Hogar</button>
                    <button type="button" class="botonPestanaAdaptacion" data-pestana="social">Entornos Sociales</button>
                </div>
            </div>

            <div class="contenedorPanelesAdaptacion">
                <div class="panelEstrategiaAdaptacion activo" id="panelAula">
                    <div class="contenidoPanelAdaptacion">
                        <div class="columnaTextoPanelAdaptacion">
                            <h2 class="subtituloPanelAdaptacion">Estrategias en el Aula de Clases</h2>
                            <p class="textoPanelAdaptacion">
                                En el ámbito escolar, pequeños cambios en la dinámica diaria reducen significativamente la ansiedad y mejoran el rendimiento escolar.
                            </p>
                            <ul class="listaEstrategiasAdaptacion">
                                <li><strong>Ubicación estratégica:</strong> Asignar asientos alejados de fuentes directas de distracción visual o ruidos intensos.</li>
                                <li><strong>Instrucciones escalonadas:</strong> Dividir las consignas largas en pasos individuales presentados en apoyos visuales.</li>
                                <li><strong>Tiempos de pausa:</strong> Incorporar pausas activas breves para permitir el movimiento regulado entre asignaturas.</li>
                                <li><strong>Evaluación flexible:</strong> Permitir respuestas orales o uso de formatos digitales según la fortaleza de la niña o niño.</li>
                            </ul>
                        </div>
                        <div class="columnaImagenPanelAdaptacion">
                            <img src="{{ asset('/IMG/salondeclases.png') }}" alt="" class="imagenContextoAdaptacion">
                        </div>
                    </div>
                </div>

                <div class="panelEstrategiaAdaptacion" id="panelHogar">
                    <div class="contenidoPanelAdaptacion">
                        <div class="columnaTextoPanelAdaptacion">
                            <h2 class="subtituloPanelAdaptacion">Estrategias en el Entorno Familiar</h2>
                            <p class="textoPanelAdaptacion">
                                El hogar representa el espacio principal para brindar predictibilidad, contención emocional y hábitos estructurados.
                            </p>
                            <ul class="listaEstrategiasAdaptacion">
                                <li><strong>Rutinas visuales:</strong> Organizar horarios mediante imágenes o paneles con las actividades fijas del día.</li>
                                <li><strong>Anticipación de cambios:</strong> Avisar con minutos de antelación el fin de una actividad gustosa o el inicio de una tarea.</li>
                                <li><strong>Zona de calma:</strong> Diseñar un rincón tranquilo con cojines, texturas agradables o juguetes sensoriales.</li>
                                <li><strong>Refuerzo positivo:</strong> Valorar el esfuerzo realizado en lugar de concentrarse únicamente en el resultado.</li>
                            </ul>
                        </div>
                        <div class="columnaImagenPanelAdaptacion">
                            <img src="{{ asset('/IMG/hogar.png') }}" alt="" class="imagenContextoAdaptacion">
                        </div>
                    </div>
                </div>

                <div class="panelEstrategiaAdaptacion" id="panelSocial">
                    <div class="contenidoPanelAdaptacion">
                        <div class="columnaTextoPanelAdaptacion">
                            <h2 class="subtituloPanelAdaptacion">Estrategias en Actividades Comunitarias</h2>
                            <p class="textoPanelAdaptacion">
                                Acompañar la participación social facilita la integración paulatina en parques, reuniones o eventos recreativos.
                            </p>
                            <ul class="listaEstrategiasAdaptacion">
                                <li><strong>Guiones sociales:</strong> Explicar previamente qué sucederá, quiénes asistirán y la duración del evento.</li>
                                <li><strong>Protección sensorial:</strong> Utilizar audífonos de cancelación o lentes según la sensibilidad individual.</li>
                                <li><strong>Salidas pactadas:</strong> Acordar una señal discreta si la niña o niño necesita tomar un descanso fuera del grupo.</li>
                                <li><strong>Empatía de pares:</strong> Fomentar dinámicas grupales centradas en la colaboración e intereses compartidos.</li>
                            </ul>
                        </div>
                        <div class="columnaImagenPanelAdaptacion">
                            <img src="{{ asset('/IMG/socializando.png') }}" alt="" class="imagenContextoAdaptacion">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionBloqueAdaptacion">
        <div class="encabezadoSeccionAdaptacion">
            <span class="etiquetaSeccionAdaptacion">Herramientas pedagógicas</span>
            <h1 class="tituloPrincipalAdaptacion">Metodologías Prácticas de Apoyo</h1>
            <p class="textoIntroduccionAdaptacion">
                Explora las técnicas que facilitan la organización del pensamiento y el desarrollo de habilidades clave:
            </p>
        </div>

        <div class="gridHerramientasAdaptacion">
            <div class="tarjetaHerramientaAdaptacion">
                <div class="cabeceraHerramientaAdaptacion">
                    <div class="iconoHerramientaAdaptacion">📋</div>
                    <h3 class="tituloHerramientaAdaptacion">Agendas y Pictogramas</h3>
                </div>
                <p class="resumenHerramientaAdaptacion">
                    Herramientas gráficas que secuencian las actividades diarias para brindar orden temporal y reducir la incertidumbre.
                </p>
                <button type="button" class="botonExpandirAdaptacion">
                    <span>Ver aplicación</span>
                </button>
                <div class="detalleHerramientaAdaptacion">
                    <p class="textoDetalleAdaptacion">
                        Se colocan a la altura de la niña o niño con imágenes claras de cada momento del día (desayuno, escuela, juego, descanso). Al completar cada acción, se desliza o retira el gráfico correspondiente.
                    </p>
                </div>
            </div>

            <div class="tarjetaHerramientaAdaptacion">
                <div class="cabeceraHerramientaAdaptacion">
                    <div class="iconoHerramientaAdaptacion">⏳</div>
                    <h3 class="tituloHerramientaAdaptacion">Relojes Visuales</h3>
                </div>
                <p class="resumenHerramientaAdaptacion">
                    Temporizadores con disco de color que muestran físicamente cuánto tiempo resta para finalizar una tarea.
                </p>
                <button type="button" class="botonExpandirAdaptacion">
                    <span>Ver aplicación</span>
                </button>
                <div class="detalleHerramientaAdaptacion">
                    <p class="textoDetalleAdaptacion">
                        Ayudan a comprender la noción del tiempo sin depender del reloj digital o de agujas tradicional, facilitando transiciones fluidas entre el trabajo escolar y los momentos de recreación.
                    </p>
                </div>
            </div>

            <div class="tarjetaHerramientaAdaptacion">
                <div class="cabeceraHerramientaAdaptacion">
                    <div class="iconoHerramientaAdaptacion">🎧</div>
                    <h3 class="tituloHerramientaAdaptacion">Kits de Regulación</h3>
                </div>
                <p class="resumenHerramientaAdaptacion">
                    Maletines con elementos táctiles y auditivos orientados a bajar niveles elevados de estimulación o ansiedad.
                </p>
                <button type="button" class="botonExpandirAdaptacion">
                    <span>Ver aplicación</span>
                </button>
                <div class="detalleHerramientaAdaptacion">
                    <p class="textoDetalleAdaptacion">
                        Incluyen mordedores seguros, pelotas antiestrés, plastilina terapéutica y audífonos. Su uso permite autorregularse en minutos sin necesidad de abandonar del todo el entorno escolar.
                    </p>
                </div>
            </div>

            <div class="tarjetaHerramientaAdaptacion">
                <div class="cabeceraHerramientaAdaptacion">
                    <div class="iconoHerramientaAdaptacion">🧩</div>
                    <h3 class="tituloHerramientaAdaptacion">Historias Sociales</h3>
                </div>
                <p class="resumenHerramientaAdaptacion">
                    Relatos breves ilustrados que explican situaciones sociales nuevas, normas o soluciones a conflictos cotidianos.
                </p>
                <button type="button" class="botonExpandirAdaptacion">
                    <span>Ver aplicación</span>
                </button>
                <div class="detalleHerramientaAdaptacion">
                    <p class="textoDetalleAdaptacion">
                        Describen qué se espera en determinado lugar (como una visita médica o un cumpleaños), validando las emociones asociadas y ofreciendo alternativas de respuesta comprensibles.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionBloqueAdaptacion">
        <div class="contenedorPreguntasAdaptacion">
            <h1 class="tituloPrincipalAdaptacion">Preguntas Frecuentes sobre la Adaptación</h1>
            <p class="textoIntroduccionAdaptacion">
                Resuelve dudas habituales sobre la implementación de apoyos y ajustes razonables:
            </p>

            <div class="listaPreguntasAdaptacion">
                <div class="tarjetaPreguntaAdaptacion">
                    <div class="cabeceraPreguntaAdaptacion">
                        <h3 class="tituloPreguntaAdaptacion">¿Dar adaptaciones no crea una ventaja injusta frente a otros niños?</h3>
                        <span class="simboloDespliegueAdaptacion">+</span>
                    </div>
                    <div class="respuestaPreguntaAdaptacion">
                        <p>
                            No. La equidad no consiste en dar a todos exactamente lo mismo, sino en ofrecer a cada niña o niño lo que necesita para estar en igualdad de condiciones para aprender y participar.
                        </p>
                    </div>
                </div>

                <div class="tarjetaPreguntaAdaptacion">
                    <div class="cabeceraPreguntaAdaptacion">
                        <h3 class="tituloPreguntaAdaptacion">¿Las adaptaciones deben mantenerse para siempre?</h3>
                        <span class="simboloDespliegueAdaptacion">+</span>
                    </div>
                    <div class="respuestaPreguntaAdaptacion">
                        <p>
                            Los apoyos se evalúan periódicamente. A medida que el niño desarrolla mayores estrategias de autorregulación y autonomía, algunos apoyos se retiran gradualmente mientras otros evolucionan según sus necesidades.
                        </p>
                    </div>
                </div>

                <div class="tarjetaPreguntaAdaptacion">
                    <div class="cabeceraPreguntaAdaptacion">
                        <h3 class="tituloPreguntaAdaptacion">¿Quiénes deben participar en el diseño del plan de adaptación?</h3>
                        <span class="simboloDespliegueAdaptacion">+</span>
                    </div>
                    <div class="respuestaPreguntaAdaptacion">
                        <p>
                            Es un trabajo colaborativo entre el equipo docente, profesionales de apoyo (psicología, psicopedagogía), la familia y, en la medida de lo posible, la propia niña o niño expresando sus gustos y comodidades.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="seccionBloqueAdaptacion">
        <div class="cuadroRegresoAdaptacion">
            <div class="contenidoRegresoAdaptacion">
                <h2 class="subtituloRegresoAdaptacion">¿Deseas repasar los conceptos fundamentales?</h2>
                <p class="textoRegresoAdaptacion">
                    Puedes regresar a la sección de Neurodiversidad para profundizar en el desarrollo neurológico, los tipos de procesamiento sensorial y los niveles de apoyo.
                </p>
                <a href="neurodiversidad" class="enlaceBotonRegresoAdaptacion">
                    <button type="button" class="botonRegresoAdaptacion">
                        ← Volver a Neurodiversidad
                    </button>
                </a>
            </div>
        </div>
    </section>

</main>

@endsection