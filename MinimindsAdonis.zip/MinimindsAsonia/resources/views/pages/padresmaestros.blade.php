@extends('layouts.padresmaestroslayout')

@section('titulo', 'Padres y Maestros - MiniMinds')

@section('tema')

<header>
    <img src="{{ asset('/IMG/padresmaestrosbanner.jpg') }}" alt="" class="imagenHero">

    <div class="hero-contenido">
        <p class="subtitulo-hero">Acompañamiento en el hogar y la escuela</p>
        <h1 class="titulo-hero">PORTAL PADRES Y MAESTROS</h1>
        <p class="desliza">↓ Desliza hacia abajo ↓</p>
    </div>
</header>

<main class="contenedorinfo">

    <section class="seccionGeneralHub">
        <div class="bloqueBannerIntro">
            <div class="textoBannerIntro">
                <h1>Trabajo en equipo para el desarrollo infantil</h1>
                <p>
                    El bienestar de los niños neurodivergentes se fortalece cuando la familia y los educadores caminan en la misma dirección. Este espacio conecta las pautas del hogar con las estrategias del aula para ofrecer un apoyo coherente y constante.
                </p>
            </div>
            <div class="imagenBannerIntro">
                <img src="{{ asset('/IMG/alianzaeducativa.jpg') }}" alt="" class="imagenAlianzaEducativa">
            </div>
        </div>
    </section>

    <section class="seccionGeneralHub">
        <span class="badgeSubtituloSeccion">Selecciona tu guía</span>
        <h1 class="tituloSeccionCentral">¿Qué guía deseas consultar?</h1>
        <p class="descripcionCentral">
            Hemos preparado dos guías completas adaptadas a las necesidades específicas de la familia y del entorno escolar.
        </p>

        <div class="contenedorTarjetasAcceso">
            <div class="tarjetaAccesoDirecto tarjetaColorPadres">
                <div class="iconoTarjetaAcceso">
                    <img src="{{ asset('/IMG/padres.png') }}" alt="" class="imagenTarjetaAcceso">
                </div>
                <h2>Guía para Padres</h2>
                <p>
                    Encuentra pautas para organizar rutinas en casa, acompañar la regulación emocional y crear un ambiente seguro e inclusivo para tus hijos.
                </p>
                <a href="padres" class="enlaceBotonGuias">
                    <button type="button" class="botonNavegarGuia">
                        Ver Guía para Padres <span class="flechaBoton">→</span>
                    </button>
                </a>
            </div>

            <div class="tarjetaAccesoDirecto tarjetaColorMaestros">
                <div class="iconoTarjetaAcceso">
                    <img src="{{ asset('/IMG/maestros.png') }}" alt="" class="imagenTarjetaAcceso">
                </div>
                <h2>Guía para Maestros</h2>
                <p>
                    Descubre metodologías adaptadas, organización del espacio de clases y técnicas pedagógicas para potenciar el aprendizaje inclusivo.
                </p>
                <a href="maestros" class="enlaceBotonGuias">
                    <button type="button" class="botonNavegarGuia">
                        Ver Guía para Maestros <span class="flechaBoton">→</span>
                    </button>
                </a>
            </div>
        </div>
    </section>

    <section class="seccionGeneralHub">
        <h1 class="tituloSeccionCentral">Pilares del Acompañamiento Conjunto</h1>

        <div class="cuadroPilaresGrid">
            <div class="tarjetaPilarTrabajo">
                <div class="numeroPilar">1</div>
                <h3>Comunicación Fluida</h3>
                <p>Mantener un intercambio continuo de observaciones entre el hogar y la escuela ayuda a anticipar dificultades y celebrar logros.</p>
            </div>

            <div class="tarjetaPilarTrabajo">
                <div class="numeroPilar">2</div>
                <h3>Acuerdos en Rutinas</h3>
                <p>Sincronizar normas y expectativas simplifica la adaptación del niño y le brinda mayor seguridad emocional.</p>
            </div>

            <div class="tarjetaPilarTrabajo">
                <div class="numeroPilar">3</div>
                <h3>Estrategias Compartidas</h3>
                <p>Utilizar apoyos visuales y herramientas de autorregulación similares tanto en casa como en el aula genera consistencia.</p>
            </div>

            <div class="tarjetaPilarTrabajo">
                <div class="numeroPilar">4</div>
                <h3>Respeto a los Tiempos</h3>
                <p>Cada infancia evoluciona a su propio ritmo. Reconocer y valorar cada avance fortalece la autoestima del estudiante.</p>
            </div>
        </div>
    </section>

    <section class="seccionGeneralHub">
        <h1 class="tituloSeccionCentral">Preguntas Frecuentes de la Comunidad</h1>

        <div class="contenedorAcordeonHub">
            <div class="bloqueAcordeonItem">
                <button type="button" class="botonAcordeonPregunta">
                    <span>¿Cómo iniciar una reunión entre padres y maestros?</span>
                    <span class="simboloAcordeon">+</span>
                </button>
                <div class="contenidoAcordeonRespuesta">
                    <p>
                        Se recomienda preparar una lista corta con fortalezas, intereses del niño y puntos específicos donde se necesite apoyo. Mantener un tono colaborativo facilita la creación de metas comunes.
                    </p>
                </div>
            </div>

            <div class="bloqueAcordeonItem">
                <button type="button" class="botonAcordeonPregunta">
                    <span>¿Qué hacer si una estrategia funciona en casa pero no en la escuela?</span>
                    <span class="simboloAcordeon">+</span>
                </button>
                <div class="contenidoAcordeonRespuesta">
                    <p>
                        El entorno del aula presenta dinámicas distintas al hogar. Es útil analizar qué elementos varían (cantidad de estímulos, tiempos) y hacer pequeñas adaptaciones progresivas en el colegio.
                    </p>
                </div>
            </div>

            <div class="bloqueAcordeonItem">
                <button type="button" class="botonAcordeonPregunta">
                    <span>¿Cuándo es necesario acudir a un profesional externo?</span>
                    <span class="simboloAcordeon">+</span>
                </button>
                <div class="contenidoAcordeonRespuesta">
                    <p>
                        Si se observan dificultades continuas en el aprendizaje, la comunicación o la regulación de emociones que sobrepasan las herramientas habituales, la valoración experta aportará orientaciones precisas.
                    </p>
                </div>
            </div>
        </div>
    </section>

</main>

@endsection