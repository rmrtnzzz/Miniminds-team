<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('titulo', 'MiniMinds - Trastorno por Déficit de Atención e Hiperactividad (TDAH)')</title>
    
    <link rel="stylesheet" href="{{ asset('css/tdah.css') }}">
    
    @vite(['resources/css/tdah.css', 'resources/js/tdah.js'])
    
    <script src="{{ asset('js/tdah.js') }}" defer></script>
</head>
<body>

    <div class="navbarcontenido">
        <div class="navbar-wrapper">
            <div class="navbar-container">
                <div class="navbar-content">
                    <nav class="navbar">

                        <a href="{{ route('inicio') }}"><button class="nav-btn">Inicio</button></a>

                        <div class="nav-item">
                            <button class="nav-btn dropdown-toggle">
                                Información
                                <svg class="chevron" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                    <path d="M2 4L6 8L10 4" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                            <div class="dropdown">
                                <a class="dropdown-item" href="#neurodiversidades">Neurodiversidades</a>
                                <a class="dropdown-item" href="#sensorialidad">Procesamiento Sensorial</a>
                                <a class="dropdown-item" href="#diagnostico">Diagnóstico</a>
                            </div>
                        </div>

                        <div class="nav-item">
                            <button class="nav-btn dropdown-toggle">
                                Apoyo
                                <svg class="chevron" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                    <path d="M2 4L6 8L10 4" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                            <div class="dropdown">
                                <a class="dropdown-item" href="#nivelesApoyo">Niveles de Apoyo</a>
                                <a class="dropdown-item" href="#acompanamiento">Guía para Padres</a>
                                <a class="dropdown-item" href="#acompanamiento">Guía para Maestros</a>
                                <a class="dropdown-item" href="#testOrientador">Test Orientador</a>
                            </div>
                        </div>

                        <div class="nav-item">
                            <button class="nav-btn dropdown-toggle">
                                Servicios
                                <svg class="chevron" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                    <path d="M2 4L6 8L10 4" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </button>
                            <div class="dropdown">
                                <button class="dropdown-item">Profesionales</button>
                                <button class="dropdown-item">Consultas</button>
                                <button class="dropdown-item">Desarrolladores</button>
                            </div>
                        </div>

                        <a href="{{ route('contacto') }}"><button class="nav-btn">Contacto</button></a>
                        <a href="#"><button class="nav-btn">Ayuda</button></a>

                    </nav>
                </div>
            </div>

            <svg id="gear-icon" class="gear-icon" width="30" height="30" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 15.5A3.5 3.5 0 0 1 8.5 12 3.5 3.5 0 0 1 12 8.5a3.5 3.5 0 0 1 3.5 3.5 3.5 3.5 0 0 1-3.5 3.5m7.43-2.92c.04-.3.07-.61.07-.93s-.03-.64-.07-1l2.19-1.68c.2-.15.25-.42.12-.64l-2.07-3.58c-.13-.22-.39-.3-.61-.22l-2.57 1.03c-.54-.41-1.11-.75-1.75-.99l-.39-2.73C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.39 2.73c-.64.24-1.21.58-1.75.99L4.8 5.11c-.22-.08-.48 0-.61.22L2.12 8.91c-.13.22-.07.49.12.64l2.19 1.68c-.04.36-.07.67-.07 1s.03.63.07.93l-2.19 1.68c-.19.15-.25.42-.12.64l2.07 3.58c.13.22.39.3.61.22l2.57-1.03c.54.41 1.11.75 1.75.99l.39 2.73c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.39-2.73c.64-.24 1.21-.58 1.75-.99l2.57 1.03c.22.08.48 0 .61-.22l2.07-3.58c.13-.22.07-.49-.12-.64z"/>
            </svg>

            <div class="log-reg">
                <a href="#"><button class="iniciar">Iniciar sesión</button></a>
                <a href="#"><button class="iniciar2">Registrarse</button></a>
            </div>
        </div>
    </div>

    <div class="ventana-contenedor">
        <div class="ventana">
            <h1 id="titulos">Ajustes</h1>
            <svg class="equis" width="45" height="45" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6 6L18 18M18 6L6 18" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            
            <div class="darkmode-ventana">
                <span>Modo oscuro</span>
                <div class="modebtn">
                    <svg class="luna" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" fill="currentColor"/>
                        <path d="M18 4 L18.6 5.4 L20 6 L18.6 6.6 L18 8 L17.4 6.6 L16 6 L17.4 5.4 Z" fill="currentColor"/>
                        <path d="M21 2 L21.4 3 L22.4 3.4 L21.4 3.8 L21 4.8 L20.6 3.8 L19.6 3.4 L20.6 3 Z" fill="currentColor"/>
                    </svg>
                </div>
            </div>

            <h3>Idioma</h3>
            <div class="idiomasbtn">
                <button class="idioma" type="button">ESPAÑOL</button>
                <button class="idioma2" type="button">ENGLISH</button>
            </div>
        </div>
    </div>

    @yield('tema')

    <footer>
        <div class="footer-contenido">
            <div class="footer-columna">
                <h1>Acerca de</h1>
                <a href="#">Nuestro equipo</a>
                <a href="#">Nuestra misión</a>
                <a href="#">Sobre nosotros</a>
            </div>
            <div class="linea-vertical"></div>
            <div class="footer-columna">
                <h1>Recursos</h1>
                <a href="#">Guía para padres</a>
                <a href="#">Guía para maestros</a>
                <a href="#">Juegos interactivos</a>
            </div>
            <div class="linea-vertical"></div>
            <div class="footer-columna">
                <h1>Contacto</h1>
                <a href="#">Correo electrónico</a>
                <a href="#">Teléfono de atención</a>
                <a href="#">Horarios de atención</a>
            </div>
        </div>

        <div class="footer-logo">
            <h1>NeuroMiniMinds!</h1>
            <p>Apoyo al desarrollo de infancias sanas, adaptativas e inclusivas</p>
        </div>

        <div class="redes">
            <a href="#"><img src="{{ asset('/IMG/insta.png') }}" alt="" class="sociales"></a>
            <a href="#"><img src="{{ asset('/IMG/tiktok.png') }}" alt="" class="sociales"></a>
            <a href="#"><img src="{{ asset('/IMG/youtube.png') }}" alt="" class="sociales"></a>
        </div>
    </footer>

</body>
</html>