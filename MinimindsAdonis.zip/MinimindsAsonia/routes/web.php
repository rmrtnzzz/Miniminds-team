<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/neurodiversidad', function () {
    return view('pages.neurodiversidad');
});

Route::get('/adaptacion', function () {
    return view('pages.adaptación');
});

Route::get('/', function () {
    return view('welcome');
})->name('inicio');

Route::get('/contacto', function () {
    return view('pages.contacto');
})->name('contacto');

Route::get('/divergencia', [DivergenciaController::class, 'index'])->name('divergencia');

Route::get('/tda', function () {
    return view('pages.tda');
});

Route::get('/tdah', function () {
    return view('pages.tdah');
});

Route::get('/padres', function () {
    return view('pages.padres');
});

Route::get('/maestros', function () {
    return view('pages.maestros');
});

Route::get('/padresymaestros', function () {
    return view('pages.padresmaestros');
});
