<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Miniminds')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #C4B5E8 0%, #D8D0F0 50%, #E8D5F0 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            color: #4A4063;
            margin: 0;
        }

        
        .pt-topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 28px;
            background: rgba(255,255,255,0.35);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .pt-topbar .brand { font-weight: 800; font-size: 19px; color: #4A4063; text-decoration: none; }
        .pt-topbar .greeting { font-size: 14px; color: #6b6280; }
        .pt-topbar .icons { display: flex; align-items: center; gap: 16px; font-size: 16px; color: #6b6280; }
        .pt-topbar .icons a { color: #6b6280; text-decoration: none; }
        .pt-topbar .icons img.avatar {
            width: 30px; height: 30px; border-radius: 50%; object-fit: cover;
            border: 2px solid #fff;
        }

        .notif-dot {
            position: absolute; top: -4px; right: -6px; background: #E0576B; color: #fff;
            font-size: 10px; font-weight: 700; border-radius: 50%; width: 16px; height: 16px;
            display: flex; align-items: center; justify-content: center;
        }
        .notif-dropdown {
            display: none; position: absolute; right: 0; top: 34px; width: 320px;
            background: #fff; border-radius: 14px; box-shadow: 0 8px 30px rgba(0,0,0,.15);
            z-index: 200; max-height: 360px; overflow-y: auto;
        }
        .notif-dropdown.open { display: block; }
        .notif-item { display: block; padding: 12px 16px; border-bottom: 1px solid #f0f0f0; text-decoration: none; color: #4A4063; }
        .notif-item:hover { background: #f7f3fd; }
        .notif-item .titulo { font-weight: 700; font-size: 13px; }
        .notif-item .msg { font-size: 12px; color: #6b6280; }
        .notif-empty { padding: 18px; text-align: center; color: #9a8fb8; font-size: 13px; }

        
        .pt-shell {
            display: flex;
            min-height: calc(100vh - 60px);
        }

        
        .pt-sidebar {
            width: 210px;
            flex-shrink: 0;
            background: rgba(255,255,255,0.28);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255,255,255,0.4);
            padding: 22px 0;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .pt-sidebar a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 24px;
            color: #6b6280;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
            border-left: 3px solid transparent;
            transition: background 0.15s, color 0.15s;
        }
        .pt-sidebar a i { width: 18px; text-align: center; }
        .pt-sidebar a:hover { background: rgba(255,255,255,0.4); color: #4A4063; }
        .pt-sidebar a.active {
            background: rgba(255,255,255,0.55);
            color: #4A4063;
            border-left-color: #F5A623;
            font-weight: 700;
        }
        .pt-sidebar .pt-sidebar-section {
            margin-top: 18px;
            padding: 0 24px 6px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #9a8fb8;
        }
        .pt-sidebar .badge-pill {
            background: #E0576B; color: #fff; font-size: 10px; font-weight: 700;
            border-radius: 10px; padding: 1px 7px; margin-left: auto;
        }

        
        .pt-main {
            flex: 1;
            padding: 32px 36px;
        }

        
        .pt-card {
            background: rgba(255,255,255,0.65);
            backdrop-filter: blur(10px);
            border: none;
            border-radius: 18px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        .btn-acento {
            background-color: #F5A623;
            color: white;
            border: none;
            border-radius: 20px;
            padding: 8px 22px;
            font-weight: 600;
        }
        .btn-acento:hover { background-color: #e09520; color: white; }

        @media (max-width: 768px) {
            .pt-sidebar { display: none; }
        }
    </style>
    @yield('extra_styles')
</head>
<body>

    <div class="pt-topbar">
        <a class="brand" href="{{ route('paciente.inicio') }}">Miniminds!</a>
        <span class="greeting">¡Bienvenido/a, {{ auth()->check() ? auth()->user()->name : 'invitado' }}!</span>
        <div class="icons">
            <div style="position:relative">
                <a href="#" onclick="event.preventDefault(); document.getElementById('notif-dropdown').classList.toggle('open')">
                    <i class="fas fa-bell"></i>
                    @if(auth()->check() && auth()->user()->unreadNotifications->count())
                        <span class="notif-dot">{{ auth()->user()->unreadNotifications->count() }}</span>
                    @endif
                </a>
                <div class="notif-dropdown" id="notif-dropdown">
                    @forelse(auth()->user()->notifications()->latest()->limit(10)->get() as $n)
                        <a href="{{ route('paciente.avisos.index') }}" class="notif-item" style="{{ $n->read_at ? 'opacity:.55' : '' }}">
                            <div class="titulo">{{ $n->data['titulo'] ?? 'Notificación' }}</div>
                            <div class="msg">{{ $n->data['mensaje'] ?? '' }}</div>
                        </a>
                    @empty
                        <div class="notif-empty">No tienes notificaciones.</div>
                    @endforelse
                </div>
            </div>
            <a href="#"><i class="fas fa-cog"></i></a>
            <a href="{{ route('paciente.perfil') }}">
                @if(auth()->check() && auth()->user()->foto)
                    <img class="avatar" src="{{ asset('storage/' . auth()->user()->foto) }}" alt="Foto de perfil">
                @else
                    <i class="fas fa-user-circle fa-lg"></i>
                @endif
            </a>
            <form method="POST" action="{{ route('logout') }}" style="margin:0">
                @csrf
                <button type="submit" style="background:none;border:none;color:#6b6280;font-size:16px;cursor:pointer" title="Cerrar sesión"><i class="fas fa-right-from-bracket"></i></button>
            </form>
        </div>
    </div>

    <div class="pt-shell">
        <div class="pt-sidebar">
            <a href="{{ route('paciente.inicio') }}" class="{{ request()->routeIs('paciente.inicio') ? 'active' : '' }}">
                <i class="fas fa-house"></i> Inicio
            </a>
            <a href="{{ route('paciente.citas') }}" class="{{ request()->routeIs('paciente.citas') ? 'active' : '' }}">
                <i class="fas fa-calendar-check"></i> Citas
            </a>
            <a href="{{ route('paciente.calendario') }}" class="{{ request()->routeIs('paciente.calendario') ? 'active' : '' }}">
                <i class="fas fa-calendar-days"></i> Calendario
            </a>
            <a href="{{ route('paciente.agenda') }}" class="{{ request()->routeIs('paciente.agenda') ? 'active' : '' }}">
                <i class="fas fa-list-check"></i> Agenda
            </a>

            <div class="pt-sidebar-section">Comunidad</div>
            <a href="{{ route('experiencias.index') }}" class="{{ request()->routeIs('experiencias.*') ? 'active' : '' }}">
                <i class="fas fa-comments"></i> Experiencias
            </a>
            <a href="{{ route('paciente.avisos.index') }}" class="{{ request()->routeIs('paciente.avisos.*') ? 'active' : '' }}">
                <i class="fas fa-envelope"></i> Mis avisos
                @if(auth()->check() && auth()->user()->unreadNotifications->count())
                    <span class="badge-pill">{{ auth()->user()->unreadNotifications->count() }}</span>
                @endif
            </a>

            <div class="pt-sidebar-section">Recursos</div>
            <a href="{{ route('juegos.index') }}" class="{{ request()->routeIs('juegos.*') ? 'active' : '' }}">
                <i class="fas fa-gamepad"></i> Juegos
            </a>
            <a href="{{ route('paciente.cerebro') }}" class="{{ request()->routeIs('paciente.cerebro') ? 'active' : '' }}">
                <i class="fas fa-brain"></i> Mi Cerebro 3D
            </a>
            <a href="{{ route('paciente.recursos') }}" class="{{ request()->routeIs('paciente.recursos') ? 'active' : '' }}">
                <i class="fas fa-book-open"></i> Recursos
            </a>

            <div class="pt-sidebar-section">Mi cuenta</div>
            <a href="{{ route('paciente.solicitudes.index') }}" class="{{ request()->routeIs('paciente.solicitudes.*') ? 'active' : '' }}">
                <i class="fas fa-file-medical"></i> Mis solicitudes
            </a>
            <a href="{{ route('paciente.solicitud_especialista.index') }}" class="{{ request()->routeIs('paciente.solicitud_especialista.*') ? 'active' : '' }}">
                <i class="fas fa-user-graduate"></i> Ser especialista
            </a>
        </div>

        <div class="pt-main">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            @yield('content')
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    @yield('extra_scripts')
</body>
</html>