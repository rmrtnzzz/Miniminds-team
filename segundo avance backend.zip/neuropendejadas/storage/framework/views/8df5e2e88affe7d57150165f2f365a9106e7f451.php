<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Miniminds — Administración'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #2D2040 0%, #3A2C55 50%, #4A3665 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            color: #ECE7FA;
            margin: 0;
        }
        .pt-topbar {
            display: flex; align-items: center; justify-content: space-between;
            padding: 14px 28px; background: rgba(0,0,0,0.25); backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .pt-topbar .brand { font-weight: 800; font-size: 19px; color: #fff; text-decoration: none; }
        .pt-topbar .badge-rol { font-size: 11px; font-weight: 700; background: #F5A623; color: #2D2040; padding: 2px 10px; border-radius: 10px; margin-left: 8px; }
        .pt-topbar .icons a { color: #cdc3e6; text-decoration: none; margin-left: 16px; }

        .notif-dot {
            position: absolute; top: -4px; right: -6px; background: #E0576B; color: #fff;
            font-size: 10px; font-weight: 700; border-radius: 50%; width: 16px; height: 16px;
            display: flex; align-items: center; justify-content: center;
        }
        .notif-dropdown {
            display: none; position: absolute; right: 0; top: 34px; width: 320px;
            background: #2D2040; border-radius: 14px; box-shadow: 0 8px 30px rgba(0,0,0,.4);
            z-index: 200; max-height: 360px; overflow-y: auto; border: 1px solid rgba(255,255,255,0.1);
        }
        .notif-dropdown.open { display: block; }
        .notif-item { display: block; padding: 12px 16px; border-bottom: 1px solid rgba(255,255,255,0.08); text-decoration: none; color: #ECE7FA; }
        .notif-item:hover { background: rgba(255,255,255,0.05); }
        .notif-item .titulo { font-weight: 700; font-size: 13px; }
        .notif-item .msg { font-size: 12px; color: #cdc3e6; }
        .notif-empty { padding: 18px; text-align: center; color: #9a8fb8; font-size: 13px; }

        .pt-shell { display: flex; min-height: calc(100vh - 60px); }
        .pt-sidebar {
            width: 220px; flex-shrink: 0; background: rgba(0,0,0,0.2);
            border-right: 1px solid rgba(255,255,255,0.08); padding: 22px 0; display: flex; flex-direction: column; gap: 4px;
        }
        .pt-sidebar a {
            display: flex; align-items: center; gap: 12px; padding: 12px 24px; color: #cdc3e6;
            text-decoration: none; font-weight: 500; font-size: 14px; border-left: 3px solid transparent;
        }
        .pt-sidebar a i { width: 18px; text-align: center; }
        .pt-sidebar a:hover { background: rgba(255,255,255,0.06); color: #fff; }
        .pt-sidebar a.active { background: rgba(255,255,255,0.1); color: #fff; border-left-color: #F5A623; font-weight: 700; }

        .pt-main { flex: 1; padding: 32px 36px; }
        .pt-card { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08); border-radius: 18px; }
        .pt-card, .pt-card * { color: #ECE7FA; }
        table.table { color: #ECE7FA; }
        .btn-acento { background-color: #F5A623; color: #2D2040; border: none; border-radius: 20px; padding: 8px 22px; font-weight: 700; }
        .btn-acento:hover { background-color: #e09520; }

        @media (max-width: 768px) { .pt-sidebar { display: none; } }
    </style>
    <?php echo $__env->yieldContent('extra_styles'); ?>
</head>
<body>

    <div class="pt-topbar">
        <a class="brand" href="<?php echo e(route('admin.inicio')); ?>">Miniminds! <span class="badge-rol">Admin</span></a>
        <div class="icons">
            <div style="position:relative; display:inline-block;">
                <a href="#" onclick="event.preventDefault(); document.getElementById('notif-dropdown').classList.toggle('open')">
                    <i class="fas fa-bell"></i>
                    <?php if(auth()->check() && auth()->user()->unreadNotifications->count()): ?>
                        <span class="notif-dot"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                    <?php endif; ?>
                </a>
                <div class="notif-dropdown" id="notif-dropdown">
                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications()->latest()->limit(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('admin.notificaciones.leer', $n->id)); ?>" class="notif-item" style="<?php echo e($n->read_at ? 'opacity:.55' : ''); ?>">
                            <div class="titulo"><?php echo e($n->data['titulo'] ?? 'Notificación'); ?></div>
                            <div class="msg"><?php echo e($n->data['mensaje'] ?? ''); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="notif-empty">No tienes notificaciones.</div>
                    <?php endif; ?>
                </div>
            </div>
            <span style="color:#cdc3e6"><?php echo e(auth()->user()->name ?? ''); ?></span>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background:none;border:none;color:#cdc3e6"><i class="fas fa-right-from-bracket"></i> Salir</button>
            </form>
        </div>
    </div>

    <div class="pt-shell">
        <div class="pt-sidebar">
            <a href="<?php echo e(route('admin.inicio')); ?>" class="<?php echo e(request()->routeIs('admin.inicio') ? 'active' : ''); ?>"><i class="fas fa-gauge"></i> Panel general</a>
            <a href="<?php echo e(route('admin.usuarios')); ?>" class="<?php echo e(request()->routeIs('admin.usuarios') ? 'active' : ''); ?>"><i class="fas fa-users"></i> Usuarios</a>
            <a href="<?php echo e(route('admin.profesionales')); ?>" class="<?php echo e(request()->routeIs('admin.profesionales') ? 'active' : ''); ?>"><i class="fas fa-user-doctor"></i> Especialistas</a>
            <a href="<?php echo e(route('admin.pacientes')); ?>" class="<?php echo e(request()->routeIs('admin.pacientes') ? 'active' : ''); ?>"><i class="fas fa-user-injured"></i> Pacientes</a>
            <a href="<?php echo e(route('admin.citas')); ?>" class="<?php echo e(request()->routeIs('admin.citas') ? 'active' : ''); ?>"><i class="fas fa-calendar-days"></i> Citas</a>
            <a href="<?php echo e(route('admin.solicitudes')); ?>" class="<?php echo e(request()->routeIs('admin.solicitudes') ? 'active' : ''); ?>"><i class="fas fa-inbox"></i> Solicitudes</a>
            <a href="<?php echo e(route('admin.inbox')); ?>" class="<?php echo e(request()->routeIs('admin.inbox') ? 'active' : ''); ?>"><i class="fas fa-envelope-open-text"></i> Inbox</a>
            <a href="<?php echo e(route('admin.experiencias.index')); ?>" class="<?php echo e(request()->routeIs('admin.experiencias.*') ? 'active' : ''); ?>"><i class="fas fa-shield-halved"></i> Moderación</a>
            <a href="<?php echo e(route('experiencias.index')); ?>" class="<?php echo e(request()->routeIs('experiencias.*') ? 'active' : ''); ?>"><i class="fas fa-comments"></i> Experiencias</a>
        </div>

        <div class="pt-main">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/layouts/admin.blade.php ENDPATH**/ ?>