<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Miniminds — Apoyo al desarrollo de mentes adaptativas</title>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

[data-theme="light"]{
  --bg:#DDD4F5;
  --bg2:#C8BAE8;
  --surface:rgba(255,255,255,0.82);
  --surface-solid:#fff;
  --text:#2D2040;
  --text-light:#6B5A8A;
  --nav-bg:rgba(255,255,255,0.88);
  --card-border:rgba(155,127,212,0.18);
  --lila:#9B7FD4;
  --lila-dark:#6B4FA0;
  --lila-pale:#EDE8F8;
  --peach:#F0A070;
  --footer-bg:#2D2040;
  --footer-text:rgba(255,255,255,0.7);
  --cloud-opacity:0.55;
}
[data-theme="dark"]{
  --bg:#1A1228;
  --bg2:#120D1E;
  --surface:rgba(35,25,55,0.88);
  --surface-solid:#231937;
  --text:#F0ECF8;
  --text-light:#B8A8D8;
  --nav-bg:rgba(20,14,35,0.92);
  --card-border:rgba(155,127,212,0.25);
  --lila:#B09FE0;
  --lila-dark:#9B7FD4;
  --lila-pale:#2A1F48;
  --peach:#F5B07A;
  --footer-bg:#0D0A16;
  --footer-text:rgba(255,255,255,0.6);
  --cloud-opacity:0.07;
}

html{scroll-behavior:smooth}
body{
  font-family:'Nunito',sans-serif;
  color:var(--text);
  background:var(--bg);
  overflow-x:hidden;
  transition:background .4s,color .4s;
}

.clouds-layer{
  position:fixed;inset:0;z-index:0;
  pointer-events:none;overflow:hidden;
}
.cloud{
  position:absolute;
  opacity:var(--cloud-opacity);
  transition:opacity .4s;
}
.cloud svg path{fill:white}

nav{
  position:fixed;top:0;left:0;right:0;z-index:100;
  display:flex;align-items:center;justify-content:space-between;
  padding:10px 40px;
  background:var(--nav-bg);
  backdrop-filter:blur(14px);
  border-bottom:1px solid var(--card-border);
  transition:box-shadow .3s,background .4s;
}
nav.scrolled{box-shadow:0 2px 24px rgba(107,79,160,0.13)}
.nav-logo img{height:48px;width:auto;display:block}
.nav-links{display:flex;gap:28px;list-style:none}
.nav-links a{
  text-decoration:none;color:var(--text-light);
  font-weight:700;font-size:0.88rem;
  transition:color .2s;
}
.nav-links a:hover{color:var(--lila-dark)}
.nav-right{display:flex;align-items:center;gap:10px}

.lang-wrap{position:relative}
.lang-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--lila-pale);border:1.5px solid var(--card-border);
  color:var(--lila-dark);font-size:0.8rem;font-weight:800;
  cursor:pointer;display:flex;align-items:center;justify-content:center;
  transition:background .2s;font-family:'Nunito',sans-serif;
}
.lang-btn:hover{background:var(--lila)}
.lang-dropdown{
  position:absolute;top:44px;right:0;
  background:var(--surface-solid);
  border:1.5px solid var(--card-border);
  border-radius:14px;
  padding:8px;min-width:100px;
  display:none;flex-direction:column;gap:4px;
  box-shadow:0 8px 24px rgba(107,79,160,0.15);
}
.lang-dropdown.open{display:flex}
.lang-opt{
  padding:8px 14px;border-radius:10px;
  font-size:0.85rem;font-weight:700;color:var(--text);
  cursor:pointer;transition:background .15s;
  border:none;background:transparent;
  font-family:'Nunito',sans-serif;text-align:left;
}
.lang-opt:hover{background:var(--lila-pale)}
.lang-opt.active{color:var(--lila-dark)}

.dark-btn{
  width:36px;height:36px;border-radius:50%;
  background:var(--lila-pale);border:1.5px solid var(--card-border);
  cursor:pointer;display:flex;align-items:center;justify-content:center;
  font-size:1rem;transition:background .2s,transform .3s;
}
.dark-btn:hover{background:var(--lila);transform:rotate(20deg)}

.btn-ghost{
  padding:8px 18px;border-radius:50px;
  border:2px solid var(--lila);color:var(--lila-dark);
  font-weight:700;font-size:0.85rem;cursor:pointer;
  background:transparent;transition:all .2s;
  font-family:'Nunito',sans-serif;
}
.btn-ghost:hover{background:var(--lila-pale)}
.btn-solid{
  padding:8px 18px;border-radius:50px;border:none;
  background:var(--lila-dark);color:white;
  font-weight:700;font-size:0.85rem;cursor:pointer;
  transition:all .2s;font-family:'Nunito',sans-serif;
}
.btn-solid:hover{background:var(--lila);transform:translateY(-1px)}

.hero{
  min-height:100vh;
  display:flex;flex-direction:column;
  align-items:center;justify-content:center;
  text-align:center;
  padding:120px 40px 200px;
  position:relative;z-index:1;
}
.hero-logo{
  width:min(380px,80vw);margin:0 auto 32px;
  filter:drop-shadow(0 8px 24px rgba(107,79,160,0.25));
  animation:float 4s ease-in-out infinite;
}
@keyframes  float{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
.hero-badge{
  display:inline-block;padding:6px 18px;
  background:rgba(107,79,160,0.12);
  border:1.5px solid rgba(107,79,160,0.25);
  border-radius:50px;font-size:0.78rem;font-weight:700;
  color:var(--lila-dark);margin-bottom:24px;
}
.hero h1{
  font-size:clamp(2.2rem,5vw,3.8rem);font-weight:900;
  line-height:1.1;margin-bottom:16px;color:var(--text);
}
.hero h1 .accent{color:var(--lila-dark)}
.hero-sub{
  font-size:1.05rem;color:var(--text-light);
  max-width:500px;line-height:1.75;
  margin:0 auto 36px;
}
.hero-ctas{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.btn-hero{
  padding:14px 32px;border-radius:50px;border:none;
  background:var(--lila-dark);color:white;
  font-weight:800;font-size:1rem;cursor:pointer;
  font-family:'Nunito',sans-serif;transition:transform .2s,background .2s;
}
.btn-hero:hover{transform:translateY(-2px);background:var(--lila)}
.btn-hero-out{
  padding:14px 32px;border-radius:50px;
  border:2px solid rgba(107,79,160,0.35);
  background:var(--surface);color:var(--lila-dark);
  font-weight:800;font-size:1rem;cursor:pointer;
  font-family:'Nunito',sans-serif;transition:all .2s;
}
.btn-hero-out:hover{background:var(--lila-pale)}

.checker{
  height:36px;position:relative;z-index:2;
  background-image:repeating-conic-gradient(rgba(155,127,212,0.2) 0% 25%,transparent 0% 50%);
  background-size:36px 36px;
}

.scroll-stack{position:relative;z-index:2}
.stack-item{
  position:sticky;top:0;
  min-height:100vh;
  display:flex;align-items:center;justify-content:center;
  padding:80px 40px;
}
.stack-item:nth-child(1){z-index:10;background:linear-gradient(180deg,rgba(221,212,245,0.97) 0%,rgba(210,200,238,0.97) 100%)}
.stack-item:nth-child(2){z-index:11;background:linear-gradient(180deg,rgba(210,200,238,0.98) 0%,rgba(198,186,232,0.98) 100%)}
.stack-item:nth-child(3){z-index:12;background:linear-gradient(180deg,rgba(198,186,232,0.98) 0%,rgba(185,172,226,0.99) 100%)}
[data-theme="dark"] .stack-item:nth-child(1){background:linear-gradient(180deg,rgba(26,18,40,0.97) 0%,rgba(22,15,35,0.97) 100%)}
[data-theme="dark"] .stack-item:nth-child(2){background:linear-gradient(180deg,rgba(22,15,35,0.98) 0%,rgba(18,12,30,0.98) 100%)}
[data-theme="dark"] .stack-item:nth-child(3){background:linear-gradient(180deg,rgba(18,12,30,0.98) 0%,rgba(15,10,26,0.99) 100%)}

.stack-card{
  background:var(--surface);
  backdrop-filter:blur(12px);
  border-radius:32px;
  border:1.5px solid var(--card-border);
  padding:64px;
  max-width:780px;width:100%;
  text-align:center;
  transition:box-shadow .3s,border-color .3s;
}
.stack-card:hover{
  box-shadow:0 0 0 3px rgba(232,93,160,0.35),0 20px 60px rgba(107,79,160,0.18);
  border-color:rgba(232,93,160,0.4);
}
.stack-icon{font-size:2.8rem;margin-bottom:18px;display:block}
.stack-card h2{
  font-size:clamp(1.8rem,3vw,2.8rem);font-weight:900;
  color:var(--text);margin-bottom:20px;line-height:1.2;
}
.stack-card h2 em{font-style:normal;color:var(--lila-dark)}
.stack-card p{
  font-size:1.05rem;color:var(--text-light);
  line-height:1.8;max-width:580px;margin:0 auto;
}

.mascotas-section{
  position:relative;z-index:2;
  padding:100px 40px;
  background:var(--bg);
  text-align:center;
  transition:background .4s;
}
.section-title{
  font-size:clamp(1.8rem,3vw,2.6rem);font-weight:900;
  color:var(--text);margin-bottom:12px;
}
.section-intro{
  font-size:1.05rem;color:var(--text-light);
  max-width:500px;margin:0 auto 60px;line-height:1.7;
}
.mascotas-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
  gap:24px;max-width:1100px;margin:0 auto;
}
.mascota-card{
  background:var(--surface);
  border-radius:24px;
  border:2px solid var(--card-border);
  padding:40px 28px;
  transition:transform .25s,box-shadow .25s,border-color .25s;
  cursor:default;
}
.mascota-card:hover{
  transform:translateY(-8px);
  box-shadow:0 0 0 3px rgba(232,93,160,0.4),0 20px 48px rgba(107,79,160,0.18);
  border-color:rgba(232,93,160,0.5);
}
.mascota-emoji{font-size:3.2rem;margin-bottom:14px;display:block}
.mascota-card h3{font-size:1.35rem;font-weight:900;color:var(--text);margin-bottom:8px}
.mascota-role{
  font-size:0.78rem;font-weight:700;letter-spacing:0.5px;
  text-transform:uppercase;margin-bottom:12px;
  padding:4px 12px;border-radius:50px;display:inline-block;
}
.role-nilo{background:#EBF4FF;color:#2B6CB0}
.role-kairo{background:#F3EEFF;color:#553C9A}
.role-pipo{background:#FFF8EB;color:#975A16}
.role-luma{background:#FFEEF6;color:#97266D}
[data-theme="dark"] .role-nilo{background:#0C2A4A;color:#90CDF4}
[data-theme="dark"] .role-kairo{background:#2D1B4E;color:#D6BCFA}
[data-theme="dark"] .role-pipo{background:#3D2800;color:#FBD38D}
[data-theme="dark"] .role-luma{background:#3D0A28;color:#FBB6CE}
.mascota-card p{font-size:0.92rem;color:var(--text-light);line-height:1.65}

.testimonios-section{
  position:relative;z-index:2;
  padding:100px 40px;
  background:var(--bg2);
  text-align:center;
  transition:background .4s;
}
.testimonios-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:20px;max-width:1000px;margin:0 auto;
}
.testimonio-card{
  background:var(--surface-solid);
  border-radius:20px;
  border:1.5px solid var(--card-border);
  padding:32px 28px;text-align:left;
  transition:transform .25s,box-shadow .25s,border-color .25s;
}
.testimonio-card:hover{
  transform:translateY(-4px);
  box-shadow:0 0 0 2px rgba(232,93,160,0.35),0 12px 32px rgba(107,79,160,0.12);
  border-color:rgba(232,93,160,0.4);
}
.testimonio-avatar{
  width:48px;height:48px;border-radius:50%;
  background:var(--lila-pale);
  display:flex;align-items:center;justify-content:center;
  font-size:1.4rem;margin-bottom:16px;
}
.testimonio-card h4{font-size:1rem;font-weight:800;color:var(--text);margin-bottom:4px}
.t-rol{font-size:0.8rem;color:var(--text-light);margin-bottom:14px}
.t-stars{color:#F0A070;font-size:0.9rem;margin-bottom:10px}
.testimonio-card p{font-size:0.92rem;color:var(--text-light);line-height:1.7;font-style:italic}

.como-section{
  position:relative;z-index:2;
  padding:100px 40px;
  background:var(--bg);
  text-align:center;
  transition:background .4s;
}
.pasos-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:20px;max-width:900px;margin:0 auto 48px;
}
.paso-card{
  background:var(--surface);
  border-radius:20px;
  border:1.5px solid var(--card-border);
  padding:36px 24px;text-align:center;
  transition:transform .25s,box-shadow .25s,border-color .25s;
}
.paso-card:hover{
  transform:translateY(-6px);
  box-shadow:0 0 0 2px rgba(232,93,160,0.35),0 12px 32px rgba(107,79,160,0.14);
  border-color:rgba(232,93,160,0.45);
}
.paso-num{
  width:48px;height:48px;border-radius:50%;
  background:var(--lila-dark);color:white;
  font-weight:900;font-size:1.2rem;
  display:flex;align-items:center;justify-content:center;
  margin:0 auto 16px;
}
.paso-card h3{font-size:1.1rem;font-weight:800;color:var(--text);margin-bottom:10px}
.paso-card p{font-size:0.9rem;color:var(--text-light);line-height:1.6}

footer{
  position:relative;z-index:2;
  background:var(--footer-bg);
  color:var(--footer-text);
  padding:60px 40px 32px;
  transition:background .4s;
}
.footer-grid{
  display:grid;
  grid-template-columns:2fr 1fr 1fr 1fr;
  gap:40px;max-width:1100px;margin:0 auto 48px;
}
.footer-brand h3{font-size:1.2rem;font-weight:900;color:white;margin-bottom:12px}
.footer-brand p{font-size:0.88rem;line-height:1.7;max-width:260px}
.footer-col h4{
  font-size:0.82rem;font-weight:800;color:white;
  text-transform:uppercase;letter-spacing:0.5px;margin-bottom:14px;
}
.footer-col ul{list-style:none}
.footer-col ul li{margin-bottom:10px}
.footer-col ul li a{
  color:rgba(255,255,255,0.55);text-decoration:none;
  font-size:0.88rem;transition:color .2s;
}
.footer-col ul li a:hover{color:white}
.footer-bottom{
  border-top:1px solid rgba(255,255,255,0.08);
  padding-top:24px;
  display:flex;align-items:center;justify-content:space-between;
  max-width:1100px;margin:0 auto;flex-wrap:wrap;gap:12px;
}
.footer-bottom p{font-size:0.83rem}
.social-btn{
  width:36px;height:36px;border-radius:50%;
  background:rgba(255,255,255,0.08);
  display:flex;align-items:center;justify-content:center;
  color:rgba(255,255,255,0.6);font-size:0.85rem;font-weight:700;
  cursor:pointer;text-decoration:none;transition:background .2s,color .2s;
}
.social-btn:hover{background:var(--lila);color:white}
.footer-socials{display:flex;gap:10px}

.chat-fab{
  position:fixed;bottom:28px;left:28px;z-index:200;
  width:64px;height:64px;border-radius:50%;
  background:linear-gradient(135deg,var(--lila-dark),var(--lila));
  border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  font-size:1.8rem;
  box-shadow:0 8px 24px rgba(107,79,160,0.4);
  transition:transform .25s,box-shadow .25s;
  animation:pulse-fab 3s ease-in-out infinite;
}
.chat-fab:hover{
  transform:scale(1.1);
  box-shadow:0 0 0 4px rgba(232,93,160,0.4),0 12px 32px rgba(107,79,160,0.5);
}
@keyframes  pulse-fab{
  0%,100%{box-shadow:0 8px 24px rgba(107,79,160,0.4)}
  50%{box-shadow:0 8px 32px rgba(107,79,160,0.6),0 0 0 8px rgba(107,79,160,0.08)}
}
.chat-tooltip{
  position:fixed;bottom:38px;left:102px;z-index:200;
  background:var(--text);color:var(--bg);
  padding:8px 14px;border-radius:10px;
  font-size:0.82rem;font-weight:700;white-space:nowrap;
  opacity:0;pointer-events:none;transition:opacity .2s;
}
.chat-fab:hover + .chat-tooltip{opacity:1}
.chat-tooltip::before{
  content:'';position:absolute;left:-6px;top:50%;transform:translateY(-50%);
  border:6px solid transparent;border-right-color:var(--text);border-left:none;
}

.overlay{
  position:fixed;inset:0;z-index:250;
  background:rgba(45,32,64,0.4);
  opacity:0;pointer-events:none;transition:opacity .35s;
}
.overlay.visible{opacity:1;pointer-events:all}

.chat-panel{
  position:fixed;left:0;top:0;bottom:0;z-index:300;
  width:380px;background:var(--surface-solid);
  box-shadow:4px 0 48px rgba(107,79,160,0.22);
  display:flex;flex-direction:column;
  transform:translateX(-100%);
  transition:transform .35s cubic-bezier(.4,0,.2,1);
}
.chat-panel.open{transform:translateX(0)}
.chat-panel-header{
  padding:16px 18px 12px;
  background:linear-gradient(135deg,var(--lila-dark),var(--lila));
  color:white;flex-shrink:0;
}
.chat-panel-header-top{
  display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;
}
.chat-panel-title{font-size:1.1rem;font-weight:800}
.chat-panel-sub{font-size:0.75rem;opacity:0.85}
.chat-close{
  width:32px;height:32px;border-radius:50%;
  background:rgba(255,255,255,0.2);border:none;
  color:white;cursor:pointer;font-size:1rem;
  display:flex;align-items:center;justify-content:center;
  transition:background .2s;
}
.chat-close:hover{background:rgba(255,255,255,0.35)}
.mascots-pills{display:flex;gap:6px;flex-wrap:wrap}
.m-pill{
  padding:3px 10px;border-radius:20px;
  background:rgba(255,255,255,0.18);
  font-size:0.72rem;font-weight:700;
  transition:background .2s,transform .2s;
}
.m-pill.active{background:rgba(255,255,255,0.4);transform:scale(1.06)}
.chat-messages{
  flex:1;overflow-y:auto;padding:14px 12px;
  display:flex;flex-direction:column;gap:8px;
}
.chat-messages::-webkit-scrollbar{width:3px}
.chat-messages::-webkit-scrollbar-thumb{background:#D0C8E8;border-radius:3px}
.cmsg{display:flex;flex-direction:column;max-width:85%}
.cmsg.bot{align-self:flex-start}
.cmsg.user{align-self:flex-end}
.cmsg-label{font-size:0.65rem;font-weight:700;margin-bottom:3px;margin-left:3px;opacity:0.65}
.cmsg-label.nilo{color:#2B6CB0}
.cmsg-label.kairo{color:#553C9A}
.cmsg-label.pipo{color:#975A16}
.cmsg-label.luma{color:#97266D}
.cmsg-label.equipo{color:#6C757D}
.cbubble{
  padding:10px 13px;border-radius:16px;
  font-size:0.88rem;line-height:1.55;
  white-space:pre-wrap;word-break:break-word;
}
.cmsg.user .cbubble{background:var(--lila-dark);color:white;border-bottom-right-radius:4px}
.cmsg.bot .cbubble{border-bottom-left-radius:4px;color:var(--text)}
.cbubble.nilo{background:#EBF4FF;border-left:3px solid #4A90D9}
.cbubble.kairo{background:#F3EEFF;border-left:3px solid #7B5EA7}
.cbubble.pipo{background:#FFF8EB;border-left:3px solid #E8A020}
.cbubble.luma{background:#FFEEF6;border-left:3px solid #E85DA0}
.cbubble.equipo{background:#F2F2F2;border-left:3px solid #6C757D}
.cbubble.crisis{background:#FFF0F0;border-left:3px solid #E53E3E}
[data-theme="dark"] .cbubble.nilo{background:#0C2A4A;border-left-color:#63B3ED}
[data-theme="dark"] .cbubble.kairo{background:#2D1B4E;border-left-color:#B794F4}
[data-theme="dark"] .cbubble.pipo{background:#3D2800;border-left-color:#F6AD55}
[data-theme="dark"] .cbubble.luma{background:#3D0A28;border-left-color:#FBB6CE}
[data-theme="dark"] .cbubble.equipo{background:#2A2A2A;border-left-color:#888}
.ctyping{
  align-self:flex-start;display:none;
  align-items:center;gap:4px;
  padding:8px 13px;background:#F2F2F2;
  border-radius:16px;border-bottom-left-radius:4px;
}
[data-theme="dark"] .ctyping{background:#2A2A2A}
.ctyping.visible{display:flex}
.ctyping span{width:6px;height:6px;background:#B0A0CC;border-radius:50%;animation:cbounce 1.1s infinite}
.ctyping span:nth-child(2){animation-delay:.18s}
.ctyping span:nth-child(3){animation-delay:.36s}
@keyframes  cbounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-6px)}}
.chat-input-area{
  padding:10px 12px 14px;
  border-top:1px solid var(--card-border);
  display:flex;gap:8px;flex-shrink:0;
}
.chat-input-area textarea{
  flex:1;border:2px solid var(--card-border);border-radius:20px;
  padding:9px 14px;font-family:'Nunito',sans-serif;
  font-size:0.88rem;resize:none;outline:none;
  max-height:90px;overflow-y:auto;transition:border-color .2s;
  line-height:1.4;color:var(--text);background:var(--surface-solid);
}
.chat-input-area textarea:focus{border-color:var(--lila-dark)}
.chat-input-area textarea::placeholder{color:var(--text-light)}
.csend-btn{
  width:40px;height:40px;border-radius:50%;
  background:linear-gradient(135deg,var(--lila-dark),var(--lila));
  border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;align-self:flex-end;
  transition:transform .15s,opacity .15s;
}
.csend-btn:hover{transform:scale(1.08)}
.csend-btn:disabled{opacity:.5;cursor:default;transform:none}
.csend-btn svg{width:16px;height:16px;fill:white}

@media(max-width:768px){
  nav{padding:10px 16px}
  .nav-links{display:none}
  .hero{padding:100px 20px 160px}
  .stack-card{padding:36px 20px}
  .mascotas-section,.testimonios-section,.como-section{padding:60px 20px}
  .footer-grid{grid-template-columns:1fr 1fr}
  .chat-panel{width:100%}
}
</style>
</head>
<body>

<!-- CLOUDS LAYER -->
<div class="clouds-layer" id="cloudsLayer"></div>

<!-- NAV -->
<nav id="nav">
  <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCANoBwoDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAAAAECAwQGBwgFCf/EAF8QAAEDAgMECAUCAwQHBAUCFwEAAgMEEQUGIQcSMXETMjNBUVJhkQgUIoGhI0JiscEVcoLRFiRDU5Kishc0Y+EJJXN10vA2RFR0o8I1VmSEk5SzGCYnN0VVZfFGg+L/xAAcAQEAAgMBAQEAAAAAAAAAAAAAAQUCAwQGBwj/xAA+EQEAAgECBAIHBgYCAgEEAwAAAQIDBBEFEiExQVETIjJhcYGRBhRCobHRIzM0UsHwFeEk8QcWU6KyYtLi/9oADAMBAAIRAxEAPwDslH3SEpN7vQOCWya03GidzQCryX6RysKtIf1DzQIl7kl0BA9vAJUrRoEttUDDdSC3gmOFk8HRA5IeCAg8EDgUFJf0S8UEdR2TlUKt1HZOVTuQClpe1+yi71LS9p9kFpBKEmqCKq7Mc1WVmq7Mc1WQH3U1J13clCpqXrO5ILCX7pEIIavg1V1Yq+DVAECKek/coVPS/uQTIulSHiga/rfZKh2jvshAt1WqO0+ysKCo1k+yCJCEcEFuHsmp+qZD2TU5Aqpzdq7mripS9q7mgakJSoIQXmdUckIZ1RyQPRAHgVRV46gqigErOu3mhKzrt5oLuqLIQEDJT+m7kqV1dl7J3JUkCqSn7YKKykp+3CC4j7JO9LdBDVdl91WKtVPZfdVUApqXrnkorKalP1nkgnS9yRFkEVV2f3VfVWans/uqxQHNS0t988lEVLS9oeSCwhCEEVV2Y5qsrNV2Y5qsgLlT0n7lAp6T9yCe/ohKgaoK9X+1QKxWcWqugRWKPg7mq6sUfB3NBOUBHJKgq1fXbyUSmq+u3koSgFapuy+6qK3Tdl90EiEJUFSo7Y/ZRp9R2xUaBVbg7JvJVPurdP2TUDwlRoEiCm/rnmk+6V/XPNIgQq5D2TeSp2VyHsm8kD+PckRzSoKkx/UKYSE6btCmfZABWKTqHmq6s0vUPNBMkslSX8EEFXxaoNVNV9ZqhQCs0nUPNVlZpeoeaCZCRCCrVdr9lGCpKntTyURQOHEc1dCpDiFdQKkd1Tr3IQ7qnkgojgl7kg4JUDoe1bzVtVYu1bzVpAvBRz9k5Seqjn7JyCqkvdGqCgkpu2VpVabtgraBNUyo7F11Io6jsXIKiEgShBJB2zVbsqkHbNVtABMn7F3JOTZuydyQVEI1Qgkh7UK0FVg7VqsoDkmVHZFPUdRrEboK33SIRwQSU3ajkVb+6q03a/Yq0gNVDVdmOamUFX2Y5oK6TvQlQTUvWdyVjmVBS9Z3JWECKvV8Wqyq1Zxb90EKTkhKgsUnUPNTgqCk6h5qdAKpV9qOStqpVdoOSCJKkSoLdP2I+6kCjp+xCkQIqk3bOVxU5+2cgYhJqlQXIeybyT/ymQ9k3knoBUp9Jnc1dVKftnIGEoRyQEF2Hsm8k8pkPZN5J/3QCpTdq7mrqpTX6V3NAxHcjRL3ILsfUbyTk2Ps28gnIEVOTru5q6qT+u7mgbxScEqBxQXxwCRA4BKEAqBtc81e7lQPE80Ag8UXQgvN6ot4JUM6o5JSgFRl7R3NXlRlt0juaBqEIugvR9m3kEqSPs28glQCoydq7mVfVGTtHcygS6Q8EI7kF8DQJdUg4I4IEf1TyKog6K+eoeSoIAp8Pat5pifCP1Wc0Fzgluk0SoIarsTzCqq3U9ieYVRAXU9JffdyUCno+s4+iCxZCVHBBXq+Lfuq6nq+LfuoUCK1S9n91W7lZpezPNBMj7oQgg3vVIXKew7wEWHgEDYj9CfxVaY2eQNFHvHzFBc+6rS9o7mmXd4n3VmIAxtJGtkFe6UFWd0eCWw8AgRg+kckpsqr3EPIueKTePmKCy7gUwPHioQ43GpVqw8AgbvDxRvAkWIOqdYXtYJJAAx2mtkDkKlvO8Sl3neY+6CzUdk5VFJCSZQDchWd1t+qPZBRCmpe0+ysbo8o9lHPYR3Asb9yCXuShUt4n9xRvHzH3QT1fZjmq2imp/qeQddO9T7rfKPZBSU1J13clY3QO4eyhqRutBbpr3IJ0gVMOd5j7pQ53iUEtXazVApqfUuvrzU1h4D2QUjZT0n7lNut8o9lHOLFu7pyQTA3Qq4v5ik18xQTOP1fZF1WkJvxKaCUFxV6g/qfZMufEqxAAY9RfVBWujS6u7o8B7JLN8B7IEh7JqcqsxIkcASOSZvOv1j7oLpVOXSV1/FJd3mPurUYBjaSATZBVCRXd1vlHsl3R4D2QDeqOSFTeTvHU8fFJvHzH3QXTaxVHvS7xuPqPurga23AeyCmE5nXbzVvdHgPZI9o3DoOCBxSKkXP8x90bzvMfdBbm7J3JUgpI3EyNBJOqtbo8o9kFG6kp+1Ctbo8B7Js7QIiQAED9Et1S3neYpN53ifdBZqOy+6rKSnN5LE3Fu9WbN8B7IKWgUtM5oebm2inLQRwC0f8Ye0abZ/stkiw6odT43jLzR0T43WdE236kg5N0B8XBB4+2L4rMoZLxevwHBKCozDidIHRvkhe1lKyYftL9S6x47o9LrUWUvjPzXBiZdmfLOFV1A99y2hc+GaNvoXFwdb1GviuVJC5rz9RcCbm69TEsvY1Q4LSYxVUEsdDVC8U3EHn4X7rqJtEd2daWtEzEdn0/wBl+1XJu0vBjWZZxVs00YBqKKUblRB/eZ4fxC49VmAcCvkZlrHcZy9jNPjGCYlVYdiFOd6Kop3lrm+3EehXe3wt/ELQ7QoostZqdBQ5qY20bmgMixADvYODZPFnfxHgJYN/aKam655KZpBbctA9LKOoNmC2huglJshU7u8x90XPmPugnquy+6rKanO9IQ430U+62/VHsgpX9VPSWu5T7rfAKCq+kN3dL+CCxqkVIOd5j7o33eY+6Car/aoFYpvq3r681MA0/tHsgokqxR2s7mpt1vgFBVfSW7unJBOUDgqW8fMfdG87xKCWq67eShVim1YS7XXvU26PAIKHsrVN2X3Um63wHsq1QSJbNNhbuQWkclR3nd7j7oufMfdBJUdsVHorcDQYgSAT6p263yj2QUlbg7JqdYeA9lWlJbI4AkD0QWkqo3J/cfdKSfE+6AdbfPNIrjGjcGg4ILR4BBS1VyHsm8ktm+UeyqSE75AJGqC6hULnzH3RvO8x90Ek3alMurUQBYL2KdYeAQUlZpeoeaksPKPZQ1P0lttOSCcoCp3J/cfdF3eY+6CWr4tUHFT02rXb2uvept0eA9kFEqzSH6DzUoaPAKvVfS8W007kFn7pVQDj5j7pS4+Y+6B9T2p5KLircIvE0kAn1T90eA9kFJvEK9ZJujvaPZVC43P1Hj4oLhQeqeSp7x8T7oaSXjU8fFA0Jbq7ut8B7JLDwCCtDbpW81bUctuicbAFVQ4+Y+6C6mT9k7uVUuPmPunQkmVoJJHqgZyKFd3R4D2RujuaPZBWpu2CtcFHMAIyRofRV953mKC4mVHYuVbed5j7pYTeUAkkeqCMJdFd3R4D2Rujyj2QVoO1arajlAETiABoqu8fE+6C7dMn7J3JVS4+Y+6dCSZWgm4QNCLq5YeUJd1vgPZBVgv0rVbUcotG4gAGyq3PmPuguqOp7IqtvO8x90+AkygEkj1QRouru63yj2S7o8AgrUx/V+xVm6jnFoyQLa9yr7zvEoLihq+zGveoN93mPupKY70h3jfTvQQg+qX7q7ut8B7Jd1vg32QQUnWdyU6hqvpDd3TXuUAc7xPugvXVer4tUO87zFTUv1b19eaCDilFlds3yhG6PKPZBFS9Q81Mq9Tdrhu6adyh3j5j7oL11Vqu0HJRhx8x91Yp7OjuQDqgqpdPFXd1vlHsjdb4BA2n7EW9U9VZyWykNJA00CZvOH7j7oLqqT9q5ML3eY+6tQWMTS4XPiUFVAsr263wHsk3W+UeyBIeybyTgqkziJXAEgA9ybvu8x90F5U6jtnc03fd5irUQBiaSATZBTQr4a3yj2Rut8B7IGwn9JvJOVOVzhK4AkC/ik3neY+6C8qU3auv4pN53e4+6txgFjSQCbIKYQVds3yj2RujyhAR9RvIJVTkcRI4bxGqTed5j7oLwVGTtHc0Fzj3n3VtrW7ouBwQUtEqvbrfAeyTdb5R7IFHBA4qiXO3iN4j7o3neJ90F9UDxPNG86/E+6uhrbcB7IKKLq/ut8AfskLW+UeyBW9UckFUnOdvH6jx8Ub7j+4oLwVKW3SO5pN93ifdXGgFoNhw8EFFCvbrT3D2Rut8B7ICPs28gl+ypvcQ9wBNr+KTfd5j7oLyoydq7mUbzvMfdW2AbgJAOnggpIV7db5R7I3W+UeyBRwRqqJe/eP1Hj4o33eY+6C87qnkqCUOJcPqJ1Heru63yj2QUU6HtW81c3R5R7JsrWiJxAsbIHoVHed5j7o3neY+6C1VdieYVRS0x3pbONxbvVktb4D2QUVPSdd3JT7o8o9lFVWawEaG/cgmRxVG7vMfdF3eY+6Car4t5FQfdWKX6g7e1171Nut8o9kFJWaXszzUhDfKPZV6olsgDTYW7kFlKqG86/WPujed5j7oL55IRqgIKtR2pUalqLdKVFxQCtw9m3kqqtQ9k3kgeUiVJ9kFOQ/W7mm3KWTru5pLIAcQryojiFftogT7pJezdySpsvZu5IKl0h9EBLZA6n7UK2qsA/VCtahAvcoqns/upLqOp7P7oKut0v2QhBLS9oeSs2Val7Q8lZQFioKvqt5qbUqGr6reaCDUISIugsUvWdyCnVek6zuQVgIEUc51apVDUabqBqEgI8Qi48UDJBqksnP63FJZAllYp+z+6g1U9P1PugkuUI4oQVJ+1cmKSo7ZyiQKrkXZN5KkrsQ/SbyQP0CEWKNboKL+ueaRK/tHcymoFHEK93KiOIV4IFTXn6HckqR4+g6dyCmkslAQgdEP1G81cVKPtG81cKBdVHPboin6pk/ZFBUQUJUElOP1RyVmxVan7X7Kze3FBBUyNiifLJI2OONpc9zjYNA1JK+ZXxO7THbTdqVdiNPUPfg1Felwth0HRNOr7eL3Xdy3R3Lt/wCKzO2H5K2N442rqXRV+MU0lBh0bOu+R7SCfRrRck/5r5mTNbe7EGabH8oDNuamQVIP9n0o6WqPiL6N+5XUVVhVBPhxw6WkhloyzozC5t2btrWstebAcEOEZJbVOIM+ISdM/TVrRo1v9futlRyOHFUWsyzfLMeT3XB9HGHTRbxt1n/DnTa7ssny+X4zgEUs+Fm5li4upvX1b69y1jR1dRRVMVVTTSQ1MLxJFLG4tcxwNwQRwIXbczo5oXwzRtfG9pa9rhcEHQgrmDbFkCXKuJOrsPje/CKh36buJhJ/Y7+hXXo9Xz+pfuqOMcJ9F/Gwx08Y8v8Ap3L8Lm2LC9o+R8PpMSxeGTN1JBuYhTO+iSTdJAlaODgWgE24EnQLclQ4GMW8V8hssY7iuW8dosawWrko8RopRLBPGdWuH8weBB0IX0+2H5/otpWzTDMyxPhZWvb0eIU8b79BO24c23EA2uL9xCsnnGaJRdBskuEE1L2h5Kwq9Kf1DyVkoEUFX+37qdQVfBqCBFvVJZLfwQT0g0crGtlXpL/UrF0CKCrtdvJTqvWcW8kEJQAgIugsUnUPNTKKl7M81LcoFCqVI/WPJWlVqe1+yCK3qlCEWQW4D+k1ScVHB2LU+6AVSftXc1buqs3auQMAKOaXRIguM6g5JxTWX3ByS3QCpSdd3NXVSf1zzQNQEtggoLkPZhPUcHZhPQKq9Vxap+9QVXFqCA3QlRZBPS9U81OoKXqu5qZApVWr645KyFWq+uOSCDVAKW90FBcp+xbyUvcoqfsW8k9Aqou4nmruqpHidUDdU5nXHMIsEresOYQXUIKTUoGVHYuVPVXJx+k5VEDSVLT9q1R6KSDtmoLdkvBIUC6BlR2LlTVuo7FyqIC6fT9s1MUlOP1WoLiOCRFygbP2LuSpXVye/RO5KoECJ8HbNTU+DtmoLiRGqLeiBk1+idyVRXJuydyVQhAikph+qFHdSU5/VCC2kJRdL9kEVR2R5qrdW6nsjzVRAKWlH6h5KJTUvaHkgsISgo4oIKvqt5qurFX1W81XKAU9J+5QKxScHIJkqTvSoK1V1xyUKmq+s3koEChWqbsvuqt1Zpey+6CYJL6pUlkFSp7c/ZMUlT2xUSAVymH6LVUCtU3YtQS96DZILoQU5+2fzTeKdP2zuaYgUq5D2LeSpq5D2LeSByVHFBQUZu2fzTNbp8w/WdzTUAr0XZt5BUVdj7JvIIHlIlQgpS9o7mmJ0vau5pECW9Veb1RyVG6vs6o5IDglCOKEHnnrHmgaoPWPNCBRxV4BUAdVfHBABKkQgouP1nmkQ7ru5oAQCvM6g5KiVeZ1G8kChKUd6EFF/aO5lNunSdo7mU1AfZXo+o3kqCvsvuN5BA5CRKEHnnrHmkSnieaBwQKzrjmFfXnt645hX7aoFKjm7J3JP1TZuyfp3IKPFLZAQglpb9KORVsKpS9qORVqyBeCgrOzbzU6grOzbzQVr6JEqEFij4O5qwq9HwcrCAVWr7QclaVWr7QckERSFFkqCYk+JSX9SlPohA+PVuovqnWHgPZNi6v3T7oGkDwCRo0CUoF90IE+5SFLqg8EEjQN0aDggAeA9kNH0jknWQIQLHQcFSufE+6ungeSpIC/qUsZPSN1J1Tb+idF2je7VBcsPAJQPQJPulugjn7J1gqtz4n3VqfsnKpZAutuJ91JTm8uuuijUlN2n2QWbC3AeyAB4D2RdCCGq0YCNNe5Vw53C591Yq+zHNVwgW58SpaXV7r66KJTUmj3ckE+6PAIt6BF0WKCGp03baKG7vE+6mqho1QhAtz4n3TmdU315pqc3gUDShKeCRBNTgFpuBxUtvQKOnP0nmpEBp4BVarSXS407lbVWq7X7IIrkDifdFz4n3RokQXILGJpNin2HgEyDsW3TwEBYeA9lUlJ6V3Eaq4VSl7V3NAl3eY+6CXW4n3ScEd3FBdYPoHDh4JQB4BDOqOSEAQ2x0CpXPifdXe43VFAAnxPunMJLhqeKaL96czrt5oLlh4fhAAPci/qlQMlFmONhwVQE+J91bl7N3JVDwQLr4n3T4e1FySo7KSDtWoLNvQeyLDwCWyQoGzWEd/VQlpNrE3PqnVRIi08VrX4g9okGzbZdiWPuLXV8o+Uw6Im2/O8EA8mi7jyQcUfGFtEOeNr1bR007pMIwMuoaNt9C5p/VfzLhbk0LVuTcHlxvH4aRt+gad+Z3lYOPvwXl1DzUSPmke58j3Fz3uNy4nUk+pW4dkOBigy+6vmFpK4hwBGoYOHvxU1jeUTOza2SJmCKSkDQ1rACwDgBwWT7gAWkM6Z7lyg9tPhkcb66ePrP1EYvxt3lepsd2m1uZK0YFi8W/W7rntqW2AcB3EKo12lvz2yR2ev4LxLFGKmnvPrf99G2iGqpitDR4ph8+H10DZ6edha9jhoQrIY7vQGKsidur0kxExtLknaZk+qyfmF9G4OfSS3fSzW67PDmOBXt7BtqeN7Ks5R4xhu/U0M1o8RoS6zKmK/4eOLXd3DgSt9bRcrUua8tTYdMGtnaN+mlI1jf3fY8CuTMaw2uwbFJsNroXQ1MLt17T/MeivdJqPS12nvDwnFuH/dcnNX2Z7fs+s+Q814LnLKtBmbAqr5nD66PfjJFnMPBzHDuc03BHiFkFhbgPZcA/AvtPqMr58bkbEKjfwfHn/pB7wG01UGktcL8A8DdI7zurvqJzi36tF2KgyqFmAjTXuVe58T7qzVH9MW8VWCAufE+6npdS6+qhKmpOLkE+ngEWHgEIQQ1Vxu205KAk+J91PVHqqBAXPifdT0urXX11UBU9J1Xc0EwA8B7JLDwCW3ggIK9TcPFtNFDd3ifdTVXXHJQ3QLc24n3VmnAMQvqqqtU/YhBKGjwCCB4BJdFkFWYkSusbJtz4/lOn7VyZZAov4lWorGNuncqgVuLs28kD7DwCSwvwCCgBBTcSHOsTx8U0E+J90r+u7mkAQPadeJVuwtwCpt4q53ICw8B7It6BASlBUmJEhsdFHc+J90+ftSozdA7e9T7qelF2uvrr3qsrNJ1Hc0E1vQIFvAeyOaVBXqtHC2mncob+pU1X1hyUFkC3PifdT0urDfXXvVZWqS24eaCW3oPZGngPZL90HUIKcxtK6xITN4nvPunT9s5MQOBNx9R91dsPAKi3iFfCBLegTXj6HaDgnlNf1HckFME+J90tz4n3Te5IglhJMrQSSFZsPAeyqwdq26tiyBLDwHsmVGkRIFlLoo6jsigqA+p90XPifdIg6oJac3lF9QrVh4BVKbtQrdkB9h7JlRYQuPA+ik7lFUdi5BUDjfifdLc+J900JwCB8JPStBJKt2HgPZVILdK3mraAsPAJk9hC42snplR2LkFPePifdODneJ901KgkgJ6Ua3VoAeA9lUp7dK1XECaeA9lHUaREiwUgUdT2JQVST4n3QHG3E+6RCCSnJMo1J0PFW7egVSm7YcirenggLA934UVVowW01UveoqvqDmgrXd4n3S7zvE+6ahBPTaudfXTvU9h4BQUh+p3JWAgLAdw9lBU6Fu7orBCr1ehagh3j4n3SXPifdHei6CxS9V19dVNb0Chpeq7mpkBb0HsqtVpLppp3K0qtV2v2QR3PifdF3eJ90iUILVOLxAka+qk08B7JlP2IT9UBYeAVSe/SusbBW9VUnt0zkDLuH7j7o3j4n3SeyEF2KxibcDgnADwHsmw6xN5J6BLegVOYkTOFyBdXTxVKe3TO5oG3PifdFz4n3SIQXIgDE3kn2HgE2Lsm8k+wsgTTwHsqcxIkcATxV3gqU3au5oGgu8T7pN4+J90XQgusA3G6dwS2HgPZDOo3kl4oCw8B7Ki4neOp4+KvKk7rHmgTePifdF3eJ90iXRBdFrDQeyUD0CBwRYhAEDwHsqBLrn6j7q+SqHfogN53mPujed4n3Rr3pLIPQAFhoOCLDvA9kDqjklF0CWHgPZUpC7fd9R4q8qMnXdzQJc+Y+6LnxPuk0QgvMtuN0HBOsPAeyazqN5JSgNPAKlISJHam1z3q8qUnaO5oG7x8T7oufEpNEIL4A8Aiw8AjuSoGvA3ToOHgqO87zH3V5/VPIqjZABzu8n3T4jeVtyeKZwT4e1ZzQXAB4BFvQeyClQRVGkRI017lVufEq1Vdieaqa9yBS4+Y+6mpNXOvrp3qDXvU9H13ckFizfAeyLDwCEv3QVqvRzbaadyhu7zH3U1Z1m8iq6Bd4+Y+6tUmsZvrqqqtUhtEdO9BLYeARp4D2Qlugr3HiEG3iFChBOw2B5p17opuyHMqT7IIrpzSNwcFIqc/au5oJ7jxCQkHvCrDkgj0QXWn6Qlukb1RyTrIEuLHXuVLv4FXXdUoB0QUrHwKdH2jdDxVsJJOzdyQKbeP5QCFRQgtz9kVV+xT4B+sFbQUSOalpu018FZ0UVT2f3QSaeIRp4qkUaoJ6vsxzVe/opabWQ8lYQU+PAFTUo+p1/BTF7Wi5K1Jt228ZP2XxGiqpDiuPOZvR4ZTOG8240dK7hG3nqe4INtve1oLnEAAXJvoAqEGOYNO3ehxbD5W3tdlUwi/uvmztY+ILaLn9klJV4p/ZeFuuPkMOJiY4eD3X3n/gei1KyeRhuy7f7pI/kg+xNS5pawg3B4eqiC+auxvbznrZ/i1O5uMVeJ4QXsFTh9ZIZmGMHXcLjdjrXtY29F9I8v4vQY7gdFjWGVDKihroGz08jeDmOFwgnStOpTyQnQjUoI+KSytgX7kvBBDBo081KD4kKCq67eSg9EF428QqtV2vjoozzVml7L7oKv2Pslt6FXtUIGQW6Fqff1CqVHbOTEF648Qqcvau0701XIuybyQU9fAoINuBV7VFzeyBGdQajgl08VSefrdzKS6C8eBVHXwKG9Yc1fQULHwPsnM0e3mruoSO6p5IAkeiLjxVIFKgtSEdG7kqgB9U9nXbzVtBSA9E+HtQSFaN1HP2TkD7+oR9wqaUFqCWqF2Bo1JK+cnxn5+r81bYK7BulH9k4A80dJE1+8wusDJIbabxOnIBdUfGNtPdkLZmcOwqsbT49jhNPTFp/Uiht+rKPA2+kHxcvnTO97nuLjvEm5JNyUHsZKwWTHsxU9K1hMDXB857gwcffgt+NgLGBkYDGNFmtHAAcAsT2X4THh2W4KkQOjqKob8pdxIvp9lmTHG2q21jaGFp3aU2xMcM36uB/QYLX4L2Phyo5Z9oTaltuipoHukN/HQflY5tQmM2dq8n9rg0fYBZV8NVO6TO9TMHENjo3XHjchcern+FZY8Lrvqsce+HShe22ibvBQgG6dcrzr6HscbFa2225AbmTCji2HRhuKUjCdP8AbRjUg+o7lsgJ4J4FZ48k47RarRqdPTUY5x37S4fje+CYbpLZGu0dexaR/Irvf4MttVZnjDZMm5ml6XHMLphJBVOfd1ZCDY738bdLnvBv4rmHbfs1/sYz5lwe5oZZbzwW7Au7x/Df2Wt8sY5iWWsco8dwaslpMRo5RLBNGbFrh4+IPAjvBK9Diy1y15qvn2q0uTTZJpeH12mJdCDbvUNvRY1sfzjT57yFg2aqdm4K+mDpWWtuSj6ZG8g4FZnxW1zKJ496npP3KewUNXwagmulJHoqHDvRdBYqtd1QWPqpqTg5ToKQup6XQO5qaygq+LeSCx90XHiFRQgkqtXi3h3KKx8CrNL1DzUqCjY+qtU/ZBSfdVKi/SlBbvy90XHoqQSgBA6c/quTVai0jbp3J10FK3ofZWoT+m3XuT73VOXtHc0Fwad4RceIVFFroFfo51weKOPcVcaPoHJLZBS17gVcBFhqlVOXtHc0FsEeIS3HoqQCO9A+cHpCVHr4FW4RoU9BRsfAqxS2DXA6aqZQVf7UE2niPdLcKiEBBNVnUKDj3FWabqnmphdBQsfAqxS6NdfxU+qhqv2oJrgd4SX5e6p/dCB0/au0TAPRXIeybyT7WQUQNRxV0c0G9lRugu3SPI3HcOCqdyVg+tvNA3u70oHp+FeRqEFSEHpWlWtPEJk5vC5VOCC9f1t91HUdkVUOqfT9s1A0cktleSIKtOLSgnRWdO4hNn7Iqogu39R7plQR0J8VUPNSU/bNQRjkUuvgVfQgpQ9q0+qt3Homz9i7kqYQXwR4hMn7JyqXT4O2bxQMsfVFj4FXkvJBTg7Vqt3TKjsXclSCD0dPRRVNuiKqqSmP6oQRWPglt6FXkIKtPpKOStAjxCjqeyPNVe5BfuPFQVfZjn3KvfxKmpe0PJBBZHv7K+UfhBXpOs7krFx4qGr4N5qC/igu3HiFDV67qg5Kel/d9kFdFvQq9qhBDS9Q301U2nj+VXq+uOSgugvg+oVap7XTXRQ2Vql7L7oKtj4H2QL/APyCvoQR09uiCkvY8R7qnUn9c/ZMQXr+oVSo7V2iZ91cp+xbyQU7eIQAR3K/bRH2QNht0TeHBOv6hUp+2fr3poKD0LjxCpT9s42PFNVyDsW8kFLj3FLY+qvEIQNi7JvdonXt3qnKbSu5pt/VBeuPEKpN2juajPjdXo+zbyCClbn7It6K8i6BGdRuo4JfuqL+u7mi6C9ceIVJ1946d6arzeqOSClr4FJY+BV/XklQIOAS39QqHeUILxI8QqBGvApVeHBBQPIosr6AgARYa9yCQe9UT1jzQCgvXHiFSffpHceKQ81eb1ByQULHwKLEL0AkugRlujbr3BKCP/kVRk7R3MpPugvkj0VOS++7mmfdXo+zbyCCl9ik1XoHijvQJp4o08QqB4lA1QXndU6jgqVvRDB9Q5hXigo6+BTou1bzVwJk3ZO5IHkjxCAeXuvPS/dBbqSOiPfqqtj6p9KP1hyKtoKNuampNHuv4Kx91FVn9Mc0EuniEX5e6o3SHignq9XNt6qCxVij6ruasIPP4dxVqkv0Z5qa6q1faDkgs3H/AMilv6hef3ot6lA4IT+jf5Sjo3eUoJqbshzUoUMRaxm642N+9P6RnmCB5VSbtHc1Y6RnmChe1znFzRcHgUESQqURP8PyjoneCCw0/SOScow9gABcAQl6SPzhAruqUvgmOljsRvhO3h4hApSSdm7kluD3hNkN2EAi5CCohOEb/K5LuP8AKfZAsHajVWVXiaWvDnCw8Spt9nmHugco6k/pfdO32eZvuo53B7N1h3jfgEFdKjcf5Cl3H+Q+yCWl7Q8lM8aXGqipxuOLnfSLd6xrapnXCtn2ScRzZi8zRDSxnoYd6zqiU6Mjb6k+wueAQa3+KXbbQ7Mcsz4dhNbBLm+rjAo6W2+adruM7xwAAvug8TbiAV86MUxCtxSvnxCvqZqqtqJDJPPK8ufI46kkniV6Gb8cxLNGYq/MGMVUlTiFdM6aaV5vcnuHgALADuAAWVbINnU2ba01+IMliweA2e8Gxmf5B/UrDJkrjrzWb9Pp8moyRjxx1l42Q8j47m+pDaCn6OmBs+ql0jb/AJn0C2DV7LMIpIZqKR8/zjW2Exfpvdxt4LdGHUdPh1HFR0cDKeCJu6yNgsGhY/njcjlppCbSyXaBbrALh02tnLm5JjpK81/BK6bS+ki29o7+Tlivp5aCumpJ27ssLyxw9Qur/gt25Nw6Gl2b5pdEygaSMMrSbGJznX6N/wDCSdD3cCtA7YcOMeJ0+JsgsyZm5I8Di4cL/ZYXhtbJQ1kdTFo5hvzVjPR5x9g902T4RxWkPhG2muz7kF1DiFR02K4RuRucT9ckJH0PProQeS3bFILne0HrognvZF0zfZ3OHujfZ52+6CGr6zeShupqi73DcG8ANbKMRv8AIfZA1WqXsvuoNx/kPspoXBjN15DTfgUE1whR9Izzt90vSR+ce6CtUds5RG6mla58hc0Eg94Tejf5HII1eh7JvJVejf5Xeysxua1jWlwBA1BKCRCZ0jB+9vujpWedvugpydd3NNspXMeXEhpsSk6N/ld7IGC9xzV9U+jeCDulWukZ5x7oH3TX9Q8k0SM8wSuewtIDhcjxQVLIT+jf5Sl6N3lKBI+u3mrarNY8OBINgVPvN8QgcFHPrEU7eaO9Mle0xkX1QQbt1FWPhpaSarqZmQU8LDJLI82axoFySfABTA2XLXx27VocIy3/ANm2EVG9iOJNbJihYewp73EZ9XniPKPVBzb8UGfqPaRtXrccwmSodhUMTKWi6bQljAbuDe4Eknx4LHNnGWX4ziDK2pDfkKeT9QE6vcNQ2yxqkp6jEK2Oko43STyus1o7yt25MwM4DgkdG54fM5xklcOBcfDksqxuiZ2ZE0sa0NaAABYADglMgChaDZOawlwWxraI2hvD86Yg5puOk/otifDE3/13ib7f/Q4H/MFrTOgc3NeJB2p6dy2R8MUw/wBI8RgtqaXevf8AiC4dZ/KstuE/1eP4ugeKUNKXQcEtwvPPoJAE4ckiVEIcRpKbEMPnoayMSQTxmORh7wQuQdoGWqjKeZ6nCqhpdGDv07+6SM8CuwnBYFtnyWc2Zd6Sjia7FKP6qc3tvj9zPv3eq69Hn9Ffae0qjjGh+84eavtV/wB2Yl8M3xAV+y1jsCxKhOJZdqakSvYJCJaS+j3RDgb6EtNrkHvK+hWXcYw7HsEo8awmriq8OrYmzU88ZuHtI0K+Qc0c1JUyQVMZjljcWvY4WLSO5dk/AhtbonYY3ZbjLmU1RG+SfCZ3P0mDiXPh14OFyRbiL+CvnhpjadnYdwoKzg3mnskjt12+6ZUfqBvR/VbjZEK90qcI3+U+yXcf5D7IJaXg5T9ygg+i+/8ATfhdSGRnnHugf3KtWWu3kpg9nnHuop/rILPqtxsggQnGN/ld7Jdx5/YfZBNS9Q81Lb0UMBDGkP8ApN+9S9Izzj3QO5qrP2pVgyM8wVeUFzy5oJHiEDBoi6UMf5D7Jdx3lPsgnhP6beSeVHG5oaGlwBHEFP3236490ChU5e0dzVvfYf3BVZWP3yQ02v4II+CW6Xcf5D7Jejf5HeyC2zqDknXUbHs3QC4cPFO32eYe6Bb+ipydd3NW95vmCrPa4vJDTa/ggjSgpdyTyH2RZwNiCOaC3H1U6yY1zQ3VwS77fMEDjyVeq/apt9nmCin+uxZ9VuNkFdCeGP8AKUFjvKfZBNS9Q81LxUMH0NIf9N/FSb7POPdA9QVX7VJ0jO9wUU56S259VvBBAQlCduP8h9kdG/ylBZi7NvJPUbCGsAc4AgcCnbzPMPdAp4FUVcL2WtvC/NVgx/kPsgYE5naN5pdx/lPshrHBwJaQAUFzvQmdJHfrt90b7POECVHYuVQhWpXNdGWhwJPcFX6N/kd7IGp9MP1gk3H26p9k+EFjw5wIHiUFlKEzpGedvul32W67fdA2p7FyqK1KWujLWkEnuBVbo5PIfZA0KSDtmppY/wArvZPiaWSBzgQB3lBaRdN6SPzj3S77PM33QNn7J3JU1blc10bmtcCSOAKrdHJ5HeyBqkp+2am9HJ5D7J0TXNkDnNIA4koLiRN6SPzt90dIzzt90CT6wu5Kmrcjmujc1pBJ7gq/Rv8AI5AxSU1+lHJJ0b/K72T4QWSBzgQPEoLQQmdIzzt90dIzzj3QNqeyPNVDfirMzg9m60hxvwCg6N/kd7IGKek7Q8kzo3+R3spIAWOJeN0W70FkIKZ0jO57fdHSM8zfdBFV8G81X1VioIkDQw71jrZRhj/KfZBGrNJwcoujf5Xeylg+i+/9N+F0E4QmF7PM33R0jPO33QQVfaDkoLaqxP8AqOBZrYdyj6OTyO9kEfBXKU/pfdVzG/yn2U0JDGbrzum/AoJ79yRN32ece6OkZ52+6CtUdsfsoyFLM1zpS5oLh4hN6N/lPsgYrlP2LeSrdG/yH2U8TmtjDXEAjiCgmugpnSM8490dIzzj3QVZ+2fzUamlY90jnNBIJ0ITejf5T7IGd6uQdk3kq3Rv8jlYje1sbWucAQNQSgl7kJnSM8w90dKzve33QVZu1dzTLd6kkY90jnNaSCdDZJuP8h9kDFej7NvIKoY3+U+ysscwNALgCBY3QSXQo99nmHulEjPM33QU39d3Mpqkcx5cSGm1/BHRv8rvZBH3L0G9UclSMb7dV3srQewADfAPNBJdHeo+kZ52+6XpGedvugpnibJE/o33vuH2R0b/ACO9kDR3K8FT3H97HeytCRluu33QP5ITOkZ52+6OkZ52+6Cm4/UeaRPMb94ndcdfBHRv8rvZAxX29UclS6OTyH2VsPaABvC4CByEgkZ5m+6DIzzt90FOTtHcymp72PL3EMJBPFN6N/kPsgS6vR9m3kFT6J/kd7K0x7AxoL2ggWIugeNUvemdJH5h7o6SPzj3QUncSksnmN9z9DvZBjf5HeyBGdccwr6pNY8EEsda/grXSM87fdA/mmTdk7kjpGedvumyOaY3NDgSRoAgqI4Jwjf5HeyXo3+V3sgdS9qORVsKrCCyTeeN0W4lT9Izzt90DyoKvs281J0jPO33UdQRI0Bn1EHWyCshP6N9uq72R0b/ACn2QTUnVdzU/cq9Odxrg/6b8LqXpGedvugeqtX2g5KfpI/O33UFQDI8Fg3ha1wghQndG+/Ud7I6OTyH2QXUJSfRAQVqjtSo7p8/alRlAqtQ9k3kqitw9m3kgfZJqluhBSk0e7mkJHglk67uabZADiFesFSbxCuoCw8EjhpwThqkdwQHBCEIGT9kVVVmc/pOVUIBS03a/ZRqSm7X7ILOiQpSkcQOPegrVsgZGC5wa0O1JOgHivmD8QW0bGdou0TFa6uq5P7Ppql8GH0jZCYoomEtaQOG8RqXd9/Cy6e+PzaTUZfy3Q5EwWvjZVYw10mJBh/VjphYNb6B53vUhpHeuG4IJKqojpqSJ0k0rg1jG6lxPciYjeWT7OcnYhnHGW0lO0x0sZDqmoI0jb/U+AXVuC4ZR4Ng9NheHxCOnp2BrAOJ8SfUrwNnWDNy7lHD8N6COKdsLXVG6OtIdST4rJmvPeqHVaicttvCHvOF8OjSY4tPtT3/AGVMXqHUGG1VeYnSinhdKWDi7dF7LlTH8+ZkxnFPnZ8QmYGSl8ETT9MV+4LriTo5YXxSNDmPaWuaeBBFiFyjteyo3KuapYKcEUVR+pTXPd3j7Ldw6axaYnu4vtDXLOKton1fFlWC18edso1NLWtYypYdxxA03rXa4LVWKUNRh2Iy0VUzdlidY+B9Vk2yrETS486hkNo6xu6L9zxqP6rJNrGXxLhbcYiYengIZIR3sPjyV13jd43tLIvgtzlDlbbFT0tVUOipMWj+SkbpuuJN2k8j/Mr6LSt3WNHqvj5RySUs8dRC8xzRuD2PadWuBuCF9QtgGeYtoWybBcwOlY6ubH8vXMaepOzR1x3X0P3WLJnlrISXS3QWKXqu5qVQ0vVdzUxQCq1fa/ZWlVq+1+yCJLZIlQW6fsWqRRwdk1PKBVSl7V3NXLqnL2ruaBqQjRLwQeCC6zqDknJGdUckIA23ToqSu20Kp2QIlYPrbzQErOu3mguJCUuqT7IEf1CogpJOoUwaIFUc3UUgVTFq6jw/Dqiur6iOlpaaMyzTSGzY2NFy4/ZBg23PaZhOy7IlRj1eWy1kodDh1KeNRPbQf3RxcfBfMjNGO4nmLH67HcWqnVVfXzOnqJT+5x/kO4DuACz/AOJPanV7UNoE2IsJbgdFvU+FQ7tt2K+sh/ieRc+lgsDyngdTj2LNpYBaJtnTP8rb6oMy2OYBK+aXHZmlsYaYoAR1iesfstnCK3FR4fDBR0kVLTMDIomhrGjuAVjitsRs1zO5AAE7QJpumm6lDQu0RpZnPEh4y3/AWS/DzWGn2kQRXNqiCSM+1/6Lz9sFC6nzOKoAbtTGHfcaFN2MFzNpeDFgJJmsbHusbrk1Eb47R7nfw+3Lqcc++HWDRfuTgE4WsgWXm30fcAJwCRKiCEBMcnkpCLoOdviLyj/Z2MszNSR2pa127UBo0ZLbj/iH5utXYRiFZhuJ02I0FVJS1VLK2WCVhs5j2m4I5FdmY/g1Bj2D1GFYlCJaadm64d4PcR4EHVcnbRcn1+TsddQVX6kD7vppwNJWX/BHeFc6HURevJbvDx3G+HziyTmpHqz390/9vov8PG02j2pbPafGW9HHitNanxSnb/s5gOsB5XDUey2fSDrL5j/DPtPm2YbR6fEZN52DVtqXFIgdDETpJzYTvcrjvX00w+eOaMSxPbJHI1rmObwc0i4I+ysFAuIsUl0XN0ENVwaq6sVX7VAgQlT0nB3NQEKxR9V3NBMi3qlQUFep6w5KK1lNU8W8lBdAuisU/ZhVSrVP2QQSWRqlA0QeKCpL2ruaYnzdq7mo0EkfXbzVoqpH1xr3q5ZAlkHqnkl5pHH6TyQUuCUFJxQgnpxxU1ioqbgVNdAlrKvUC8hVlV6jr/ZAxISnWKa4HvQJxU1MPpdzUNtFPS9V3NBLZACUI4oIKrg1QXsp6rg1V7IFKmpB1lBZWKX9yCayAlFkFBVnP6pTN5Pn7UqNAoP1jmrips6w071dQJ902W/Ru5J+lkyTsnckFMcEXSJe9BJB2zVbVSDtWq2ECAKOo7EqYKGp7EoKuiW6alQSU/ahWrqtTdqOStIEsmVHZFSKOo7FyCoj7ISIJIe2bzVsqpB2zVbQCZUdi7kn2TKjsXckFNKkQgkp+2CtlVYO1araAUVT2JUijqexKCpZKk4pbIJKbtRyKtBVqbtRyKtIE1uoqvsxzUyhquzHNBVS3SJUE1J1nclYVel6zuSsIBQVf7VOoKv9qCBCEILFIPpdzU9lBSdV3NTXQKqtT2n2Vniq1T2n2QRIQhBbp+xH3Two6YfohS/ZAKnUds5XCqc/bOQMQEiXvQXIuybyT/wmQ9k3knaoBU5+2dzV0KnN2ruaCNLZCRBdi7JvJOTYuzbyTrhAKnN2ruauKpN2ruaBiO5Il7kF1nVHJL3pGdUckp5IFVB3WPNXgqTuseaBuiAiwQgv+CWyTuRf1QBVDvV9UDqSgDoi6ElkHoDqjkgXQBoOSVAgVOTtHc1dVKTtHc0DUJEDigvM6jeQSpGX3G8gnIECoydo7mVf4qjJ2juZQNujvSckvNBf7kW9UDglQNd1TyKo3V5/VPIqj3IDinwgdK3mo1JB2reaC4BdCVFwgiqeyPMKordT2J5hVEAp6Pru5KurFH13ckFjVASovogrVnWbyKgU9Z1m8ioEArNJ2Z5qtZWaTszzQTJUI+6BnSs84SdJH5x7qqhBLIC95c0bw9E3cf5SpoOyCkCCr0b/AClTRva1ga5wBA1BUqpz9s7mgsdIzzt90vSR+cKojuQSOY8uJDTYlJ0b/KVZbbdHJKUFTo33H0lWekZ5h7p3ceSooLnSMv12+6QvaRYOBKqJ0faN5oLN3eB9ktz4H2T0IIZtWEWPsq9j4H2VuXqKEIIw0+BUkP0vu7QWT2pJep90Eu+zzBeFnjNGDZSyviGY8cqGwUFBCZZHEi7rcGN8XONgB3kheoTYcFx9/wCkUzVUhmXMlU7yyCUPxGps8fWQSyMEcbD6zrpw8EHMm1fOdfnzaBjGa68PBr6guhjc7eMMI0jj/wALQAs3+HPKD6rFX5mrae1NTtLaYvHWkPEjkO9apwPDavF8YpcLpGF81RIGN9L959F2Fl7D48IwWjwyANDKaJsd2i1yBqfuVwa/NyU5Y7yvuBaL02X0tu1f1ei6IXvdIWpwJKUNuqR7RE4eC1Z8RuDGsyjDijI7y0Uwu4D9rv8AzH5W2N2y8vN2HR4vljEcNe2/T07g3+8BcfkLbhv6PJFnNrcPp9PbH5w44oKh9NVRVLCQ+J4e0+oN10TA6mxbB2OkaH09XCCWnvBC5zqIzDNJEdHMcWkeoK3Ts4qTPk2hAfvGMOYfSx4L09JfNLxs1fnTBJcvYw+lN3Qv+qB9us3/ADCzH4eNq2J7Lc7QYi2aWXBap7Y8Uogfpkj84HnbxB5jvWVZsy/DmHC3Usv0zN+qCS2rXf5FaMqqeWjq5aepYWyRPLHNPcQomNkxO7674RWUuK4ZS4lh0zamjqomzQSs4PY4XB9lbLH+Q+y4y+CbbhT4a2DZrm2tMVLLJbBauV/0xucf+7uJ4Anqnhc28F2tG4O0AIt4qEo4CIw4PO7c6XT+lZ5x7qOrH1N5KGyC1vs87fdQzgvk3mDeFrXCiVml7L7oIOjf5Sjcf5CriXTuQRRPa2MNcQ0juKd0kfnb7qvUdq5R6oLnSR+ce6rSNe6RzmtJBOhTFch7JvJBV6N/lKOjfbqFXOaVBG2RgaAXAEBL0jD+8e6qvH1HmmoLhkZawcPdVyx/lKYDqFdCCpuP8pSta4OBLSACrVkj+o7kgOkZ52+6OkYf3D3VMcEoOqCzM4FuhuO9RF7R+4Iv+m7kohY8UD3StHBwXIvxzbZoGUEmzDLtYx80p/8AXcsZv0bRYtgv4k2LvAaLevxEZ6Zs82U4tj9PNBHiZZ8vhzZD1p36Agd5aLu+y+YVbVVFXVTT1cr5p5pHSSyPN3PcTcuJ8SUDGNfNKI2Avc42aAOJW9MiZcZgWBxsfGBVzAPnd337m/ZYVsjy62aU45WRksjdu0zXDQu73fZbWaT3lZ1jxY2k3dtwShPAujdWbABODR3pAEXKga723Ydv0VFiLWn9NxjcfAHULWWFYhU4XilLiFJIY56eUSMcPEFb5zhQx4pl2ro5X7oLC4OI6pGt1z6WDeIJvY2uFrvHm20tMTvDtjDqr5mhp6jT9WJr9OGoBVoFa8+H/HG41kSKke69Rhrugfc6lvFp9tPstiltl5nJSaWmsvpWnzRmxVyR4wBqnAJAlWtuFkhCUpCUDCsJ2x5YbmjKE8ccYdW0gM1Mba3A1b9ws3TmtHeAsqXmlotHg15sVc2Ocdu0uG/qa4sI3SDZwPcu6fgW2uDHMAOzzHakvxbDIi/DpZDcz0w/ZfzMv/wkeBXMG33JzMu5ibiVE21FiJc8NDdI397f6rDsjZmxXJuasOzLgtQ6HEKCYSxnucO9p8WuFwea9HiyRkrFofOtTgtp8s47d4fXRsrC3VzQeaN9nnb7rC9lub8Pz/kfDc14Sd2Ctj+uI8YZRo+M+oP4ssqAIWxoTTDftufVbjZM6N/lKfSnVynOoQVOjf5CpYD0YIf9NzpdT2UFZ1W80Ehkj87fdHSR+dvuqeiS6CxMd9w3PqsO5M3H+Up1L1jyU6Cr0b/KVNE5rI7OIafAqVV6kfqfZBMZGece6OkZ5wqgQEEj2uc8ua0kFJ0b/IVYi7NvJPKCq1jwQd0qYys8wT1TePrdzQWekZ5x7oL2uaQ0gm3AKqFNTD6iUDOjf5Sjcf5SraEEMVowQ82v4pxkZ5h7qOqP1DkoUFvpGW6wUMl3PuASFDqrMZtF9kDQW+IQ6x0bqfRMT4R9aBu4/wApUkP0NO9pc96mUVR1RzQKZGeYIEjPMFXKEEs3123DvH0UfRv8hT4O0+ysIKnRv8pT4f0779238VYUNT1BzQOEjPMEu+zzBVQl4oHygufvNBIPek6N3lKni7NvJPQVAx4cDumwKn6Rl+uPdOf1TyVJBb6Rnmb7pHvaWFocCSNFWsnR9dvNAgjfbqH2S9G/ylW9UFBWjBbIHOBAHepukZ52+6J+yN1UQW+kZ52+6bM4OjLWuDie4KspIO1CBoY/yn2S9G/yFWwhBWhaWPDnAgeqn6Rnnb7pKjsiqtkFsyM8490yZzXRlrSHHwCrKSnv0wQNEb/I72R0bx+0q4lCCpG1zZA5wIA4kqx0jL9dvuibsnclTKC50kfnb7psrmujLWuBJ4AKopIB+s1A0Rv8hS9G/wApVyyLoKsTXNkDnAgDvKsdIzzt90k5/ScqaC70jD+9vumTOa+MtaQT4BVVLTdqORQM6N/kd7Jdx/lPsrt7JOKCtAC2TeeC0W4lT9Izzt902pP6R5qr3ILnSM8491HMQ9oDCHG/cq6lpe0PJAzo3+U+yCyTyH2VxCCvB9DiXjdv4qbpI/O33UdV1W81XQXN9nnHuoqj67bn1W42UF1PSfuQR7jvK5JuP8p9lcQghgIY0h53TfvUnSM87fdQ1XWHJQoLvSR+ZvuoJwXv3mDeFu5Qgq1Tdl90Ffcf5CgRv8hVyyVBFE5rIw1xDT4FOEjPO33Veo7Y/ZR3sgudIzzt91Xla58jnNaSD3hR3Ctwdi1BV6N/kKNx/kPsrtiiyCON7Wsa1zgCBqCndIzzt91Vmt0z+abe3egumRnnb7qtI1zpC5rSQeBCiJ0V2DsWckFXo3+Qo6N/lKuEIAQMjewMDS4AgcCUvSM87fdVJe2dzSXQXekZ52+6rSNc6RxDSQToVHdXI+zbyQVejf5Sjo3+Qq4B4pQgjbIwNALwCPVL0jPO33VN/XdzKAgudIzzt91Wcx5cSGHimdyut6o5IKnRv8pSdG/ylXrIQM6SO3Xb7o6SPve33VLvPNCC70kfnHuqvRvv1Cmg6q8OCCn0b7dUpNx/lPsryEDBIywu9vujpI/O33VI9Y80qC50kfnb7qu9jy8kNNiVHxV5vVHJBT6N/lPsjo3+Q+yud6EDGvYGgFwBA8Uu+zzj3VR/aO5lJcoLnSM8zfdVnseXuIaSCUy+ius6g5IKnRv8p9khjf5T7K6EvegYJI/O33SdLH52+6pnihBcMjC0gOF7eKq7j/IfZDOu3mFe4oKXRv8AK5Kxrmva5zSADqVc4Jk3ZO5IDpI/O33Rvx+dvuqSEFqZwfGWtIcfAKDo3+Q+ydTdsORVpBUMb/IfZOgvG8l43QR3q0oKzs280D+kZ52+6BKzzt91TQgnqP1C3o/qA42UW5J5CpqPqu5qdBS6OTyn2U9OQxpDzum/ep1Vq+0HJBP0kfnb7o6SPzt91SR9kCoCk6KTylHRSeUoJqc/pDmpdFDEQxga8gEdyd0kfmCB6qTdq7mrPSx+cKvIxznlzWkg96CNKndHJ5Cl6KTylBZZ1BySpgkYAAXAEBL0sfmCB3cVRVwyMt1gq3RSeQoGCydH2reaXopPIUrI3te1xaQAdSgt96OCZ0jPMEvSM8wQJL1FEpHva5tmm58E0Md4FAl02U/Rx71JunwKiqGPLLAFB5mZsdwzLeXa/H8YqBT0FBA6eeQ9zWjgPEngB3khfLXatnCvz7tAxbNlcXtdXTkwwueXdBENGRg+AFvvddY/+kDzkaDJ+EZGpat0dTik/wA3WRNtrTx9QO7wDJYjx3CuNctYdHieYKHDJqjoGVMzY3Sbt9258FEztG8sq1m1oiG7Ph0ylTx4Q7M1TEXVcz3RwOe3qM7yOa3C1llWwWjpMIwqmwyijEcFNGI2Dl38+9XL3XnM2Scl5s+jaPTxpsNcceHf4m6BKHItdFlpdRd5G7vJLI3y1SOPNo1I+iz1jEDgRu1T7XFtCVmGxWva6CswyR2rCJox6HQpfiOoKemzu2qjeOkrIhI9luHddY5soqG0+bGROFzPG5jT4HivS6e/NSsvm+uxeiz3p75brDmt4LXW1bK76txxzD4t57W/6yxo1IH7gthMYe9StiadCAfFdMxu4ezmeJ264O1BGotoQvoN8Ge2M58yqMr4/Wh2ZMIjH1yO+qspxo2T1c3g77FcX7VssNwjE24hRQ7tFU6m3Bj+8el1j+UMyYvlTMdFmDA66SjxGikEkMjfyCO8EaEd4WrbZsiX1xqHhzm2Pco7rXGwXathO1fJ0WJ0hjp8VpmiPEqG/wBUEnmHix3EH7dy2SInltw0oG2Vim7LTxKi6KTylSwuEbN153Te9igl18EXTelj84R0kfmCCtUdq5MupZGOe8uY27TwKb0UnlKBnBXIuybyVbopPKVOyRjWBrnAECxQS2SJvSsP7wjpY/OEFR/WdzKTipDG8kkNJBOiTopPIUDB1gr/ADVQRSA33Cp+ljt1wgfokf1Hck3pI/MEOfGWkBwJIQVUW9FI2F/lKd0T/KgjOkbuSq1E0VNTyVNRMyGGJpfJJI6zWNAuST3ABXJWuaw3C5Q+OrapiGBYbBs8wR01PPidP8xiNQNL05uBE08fqIu4+GiDSPxZbVnbSc/OpsMqQ/LuDudDh5aTaZx68x/vEaei11kPK8uYcSEkwIoYHAzv8fBo9SsepIZq2qipaaJz5pHBjWgcSV0DlnDIsHwWmw9jW70bB0jmjrP7ypiN0TOy1T08dPEyGGNscTBZrWiwAU7U6yAAtjAosnck0BORA7khCUIsghmjbIx0bxdrgWkehXP2cMKdg2YKmisRGHb0f908F0M4LXO2XBzPQRYvC27oPolI8vcVFurKsq/w4Y0cMz2MOkl3YMSiMVjwMg1b/UfddNFcRYLiFThWLUmJ0ptNSytlYfUG67OwHFKbGcGo8VpXB0NVE2Rtu641H2NwqPiGPa8X83svs/qObFbFPh1+UrpRdJcIvdVz0JwSGyS6CUCFMc4px1SFqDH88YDTZoy9UYRWADpBeKS2sbxwcFydmDBq7L+Nz4XikZjnhP2cO4j0K7SDGnitDfE7l9kWIUGYod8idvQT6aAt6p+4XfoM01vyT2lQ8e0dcmL01Y9av6Nuf+j6z9hcVPi2z2rlkjr56g19FvO+iRoYA9jR3OFt71+y6/Dg4aL5IZUx/EMs5jw7HsImMNdh9Q2eF4NvqaeB9CLg+hX1WyFj1LmzJmEZmoQfl8TpI6hotbdLhq37G4V08a9+lbq7TuU4AUMR3Cd8bt+Cf0rPMED1DWcG80/pY/OEya0oHR/Vbigr3Qn9FJ5Cjo5OG4UD6XrnkrH4UELXRuJeN0WUvSR+cIHhVantPsp+kYP3hQzAyPuwbw8UESE4RSeUpejk8hQWIuzbyT1GxwawNcbEBL0jPMED1Ul7R3NWOkj8wUL2ue8uaLg96CMWU9PwKj6OTyqWFpYDvAhBKk1TTKzzWSdLH50EVT1xfwUYUsoMhDmfUE3opPL+UDFK02j+yZ0Unl/KUuAG6dCgapIeuFGDcqWNrrh27ognUNTwbzUvuoalzQBzQRo+yN5vmRvN8UD4e0+ysC6rxA728LkDwU4P8LkCqGp6g5qQu/hd7KKd1wAbjXvQQpW8Utmn9wSgNH7kFhmjBySm6Yxw3BqnghAjh9J5KkFdcQQR6Kt0UvlKBidH2jeaOikH7SnMY5rgS0gA6oLSE3pGdzgk32eYIEnP6RVS6tSFrmFrTcnuUHRP8pQMKkp+1CTopB+wp0TXMeHPBaPEoLST7JvSx+YI6RnmCBtT2JVVWpXB7C1pu7wUPRSeQoI1JT9qEgik7mlPiY5jw54sPFBZRqmdJH5gjpGecIEn7Jyqaq1K9rmFrSCTwVfo5O9hQMUlP2rUnRP8hT42PY8Oc0ho4lBaCDZM6SPzo6SPzBAk/YuVMK3I5r2FrTcngFB0UnlKCNS0vbDkUnRSH9hT4mOjkDniw8UFlCZvx+YI6RnmCBtR2R5qqrMrg9m6w3PgoTFJ5SgYpqXrnko+ik8pUkAMbiXjdFu9BYsjmm9KzzBG+zzBBHVn6W81Xup5yZAAz6iD3KLopPIUDeSnpP3KMRP8hUsH6YO/9N+F0E3FF00SM8wR0kfmCCCqP1jkolNO0yOBYN4AJnRSeUoGK1Tdl91B0cnkKmhc2Nm687p8CgmQo+lj84R0sfnCCvUdsVER6KeVrnvLmAuae9N6J9uoUEY5K5T9k3kq/RyeQqeN7WRhrnAOHcglSE3TOlZ5wgyR21eEFWbtn80zvUsjHvkc5rSWk6FJ0UnkKBnDuV2Hsm8lV6KThuFWGPY1ga5wBA1CCVJdM6VnnCOkj8wQVJe1dzSBSyRvc8ua0kHgkEUnkKBncrsXZt5Kr0UnlKna9jWhrnAECxCCVImdLH5wjpY/OEFN/XdzKFI6N5cSGmxN0nRyX6hQNV5vVHJU+ikOm4VZEjAAC4XCB6BxTelZ5gjpI/OEFLvPNKnGKS5+ko6KTylA0K8OCqdFJ5SrHSx26wQSJEzpY/MEvSs8wQUj1jzS8U7opCT9J4peikH7SgYrreqOSq9HJ5SrDZGBoBeAQEEmncEib0sfmCOkj84QVH233cykT3RvLyQ02JR0UnlKBius6g5KqY5PIVYEjA0AuAI4oJEg4pvSx+cI6WO/XCCmeKRP6OTylHRP8pQNYPrbzCvqm2N4IJYbAqz0sfmCBybL2TuSTpI/OEkj2OYWtcCSNAgqIT+ik8hS9FJ5CgWm7YcirSrQtMb9543W24qfpY/OEDlDV9m3mpOlj8wUc5ErQGfUQbmyCshP6KThuFHRSeQoJqTqu5qa6ggIjBEh3SeF1L0kfnCB33VaqH6g5KfpY/OFDMDI4OjG8ALIISkT+ikP7Cl6GXyILYSpEvBBVqO1Kj+ykqDeUqO6BFcg7FvJU1cg7JvJA5CO9KgpP67uabYpz+u7XvTboAcRzV/RURxHNXSgE2Xs3ck6ybJ2buSCoEX1QLI4oHw36UK2AqsHahWkAq9ZOynY6eZ4ZDG0ve4nRrQLkqdx+krRnxnZ8GUdi9dQQTNZiWP3w6nbvWcI3D9V45MuL9xcEHC+27ONRtA2mY1mqWZ7oqmoc2ka49nTt+mNoHd9IB5kr3fh2yyMUzBNjlXFv09AAI7jQynh7DVasLXghoOpOi632WZejy9krD6Pca2eSMTTkG+89wv/ACsFxa7LyY9o7yuuB6T0+o5rdq9f2ZM0KRqW1koAVE9wVCQJRxUoNI1TXNupbXSgWQ3c/wDxR0gjxXBqwN7SB8Zd42PD8rWGTKgU+asNlOgFQ0H76f1W7/ijoemyxhuINGtNUljjbucP/JaAwo7mL0bt7dtOw38PqCvtDbfDDwfGqcust79p/J0s/duQEy57kxhvqDcFSAaqxUylitJBiFFLR1cYlhkbZzT/APLitH54y1NlzEWt3nS0soLoZCPwfULfwaCdVRzDgdFj2EyUFY2wOsbwNY3dxCxtG6YnZqDY/n7F9nOeqHNGFuMhhdu1FMXlramE9aN3PuPcbFfTLZNtBy9tHyjT5iy/Ub0L/onp326Wml743juPgeBGoXyzzJg1bgGJyUNbHuuGrHgfTI3uIWQ7HtpeYtmWbYcdwCdzmkhlZRvceiqou9jh4+B4grWzfVvQi6rVQ/U+yxjZbn7AdoeUaTMmA1O/BMN2WFxHSU8tvqjeO5w/I1Cyao1kHJBHYpeaEILcPZNTk2Dsmp6BFTlH6ruauX1VOXSV3NA2xQUI7kF1nUHJLdDeqOSCCgDwVJXe4qlzQFilbo9vNCVnXbzQWykLk48VFLct0NkGGbZ8/Yds5yFiOZ8T3X9AzcpYL61E7uowffU+gK+X2dcyYxmzM1fmLGqs1NfXSulld+1tz1WjuaOAC6E+P3OxxbaDQ5MpqoupMGh6WpY0/SamQX19WssPS5XOWXsLlxjGoMPhF+kf9R8re8oNjbHcDjjwl+MVFO3p5pCIJHD6gwCxtzK2C1tkyjgipaWKmhaGxxMDGAeAUtx6rbDXPUqVIEo1QAHilAQOSVEABBSpEDHFU8aoYcTwqooJhdkzCPv3K64KM3Qc2VsElLVzU0jS18by0g91it6/DHjsk2HV+AVE7f0HCamY462PWA9OBWB7ZcKhpcQp8ThaWuqriUAaFw7+axPK2M1eA47S4tRv3ZaeQO/vDvB9CFx6nD6THNVlw7V/dc9cnh4/B2gL96cvPyzi1Pj+BUuLUl+iqGB1vKe8fYr0LHwXnZiYnaX0KtotEWjtJLi6VG6ghEhIUEpEA7VeBnnL8OZst1WEVGnSNvG+3UeOBWQAghODmjiFNbTWYmGN6Res1tG8S4pxzCq3AsWmw3EYHRVELtQe8dx5Lsr4Hts7MQo6PZZj8cME1JA7+yKhp3emaCS6Jw84vcEcRfwWivibwMwY3R5hiDjFVR9DKe5r28PcLWWUMcq8u5qwvH6Nz2zYdVR1DS3j9LgSPuLj7r0eDJ6WkWfPNbpvu2e2Py/R9c5nNc1tvFREKlguKU2OYDh+M0MjX0tdAyoiINxuvaD/AFVwXW1yCynpODuahU9JazkEyVCQlAyo7P7qqrNQbx/dVuKBLlWaY/p/dV7KxS9meaCayEJCUEFRxUPLVTVPFQAoHKxB2arjVWoB+mgcgo4IQVHj6k2xSyH6k3eQWafs/upbqOmt0X3UtkAqUo/WdzV1UJXfrEeqCQDXRWIuoFXaVYjvuIH30soKoaNU6hquDUFYDVKlSFBZpj9B5qS6hpuoeamAQHFQVI1bdWFXquLUEQQUn2QEFqEfpNTyEyHsmqTTggb3ap3ekNrIQLomydm7TuSpJOzdyQVe5HckB0QgfB2gVlV4dZArBQCZOP0nJ41TKjsigqpUiNEElN2v2VmyrU3a/YqzdAvBR1HZFSKOo7IoKt0EoSFBJB2reatWVSDtWq4gLeqZN2TuSfcFMm7J3JBUv4IJRZJb1QSU/ahW1Vg7UK0gSxTKjsipNFFUdkUFYFBKQIQS09+l+xVlVqbteHcVaugQKKpH6Y5qW6jqezHNBWsgFF0IJqXrO5Ke6gpes7krGiAsoKn9qm1UNV+1BAlukugILFL1TzUyhpuoealN0Boq1T2v2VnRV6ntPsghKEpCO5Bap+xCfxTKfsQn80CqlUds7mrnJU5+2dzQMQlARayC5D2TeSdxTYeybyTygFSl7Z3NXVSl7V3NAzvShKgILcekbeScki6jeQTkCcFSl7V3NXdVSl7V3NAiLJAl1QXW6tHJOATWn6RfwS8UChUX9Y81dVJ3WPNAiRKhBe7gl5pNNEqAKoFXtVRPeUBwQEnFKEF4DRCBwS6IBUXdY81dVFx+o80BdJx4I/CVBdb1RySobwHJKeSBFRf13c1e0VF5+t3NAiLoGvFGiC/3IsgcEFAjuq7kVSV13VPJUfsgE+HtW800WT4e1bzQW0JbaJEEdSP0jzVUK3UdkeaqFAKek6zuSgupqTrO5ILBQhKgrVfWbyKhupqsat+6gQCtUvZnmqys0vZfdBKbpUh4I+yCPp4/U/ZHTx+J9lVQgmex0rt9lt0+Kb0MngPdTU3Yj7qRBW6GTwHupGSNY0Mde40NlMqc3bOQWBPH4n2SdPH4n2VXj6IQSmJ7iXaWOvFJ0EngPdWWdQckv3QVehlGpA91N08fifZSHgeSooLXTMvxPskdK1wLQTc6cFWsnxj9RvNA7oZPAe6Ohk8B7q0jRBA1jozvuAsPVO6aPxPsln7JyqC6Cw+Zv7SfZfPP47s1SZh22TYRDPv0eAUzKVjQfpErgHyHnq0H+6voFNJHBDJUzuDIYWmSRx4BoFyfYL5PbQccGYs749jzZZJG4hiE9RG6QWcWOeS24/u2CD0Nk2VZM1Zphp3gmkgcJKk+DV1kxrGMbHG0Na0BrQO4DgtTfDThMEGUZ8W3XfMVU7mFzhoGttoFtnRUWtyzfJt5Pc8E00YdNFvG3X9i96LIHoncVxLglkoGqVLa6lBBcIPBCLIhr3b7BNUbNK8Qxl5jfHI6w4NB1K5mwelirMWoqaaTo45ZWsc/wBK6n21sn/7M8XFO8Mc5jQ4k2u2+oXKlISKiEg6h7SPcK54dP8Ofi8d9oIj7xHw/zLpGCDoo2RNvZjQ0X8ApbJYyTDGTxLGk+yCrV50iUO8Cm96Cg8rNGCUOP0XytfFcjWORvWjPiCtGZrwGqy/ir6OY77eMcgFg5q6GOq8vMmA0WP0BpK1mo7OQdZh8QomN0xOzV2yDaZmrZlmJuLZbqg1j7CrpJiXQVTB+17fHwcNQvozsS2j4XtWyXFmPC4ZKWRjzBV0spu6CUC5AP7mkG4P9V8xszYDiGAV8lNVxO3Af05QPpeO4grYPw/bbsybJ8SeyjYyvwOqlD6zDpTbeNrb8buLX2+x71rZvpiYpPAe6OiktwHusf2YZ7y9tCyrT5iy3VCell+mVj9JIJBxje3ucPyNQsq0OoKCFkrY2hjyd4cU4VEfr7KCoA6ZyaLILPTx37/ZROic9xeALHUaqIq5F2TeSCv0Dx3D3SGCTwHureqLII2zMaACdRpwS9OzxPsqrh9Z5lCCyZoyLa+yi6F/gPdRgaq6OCCt0L/Ae6URPBDjwGp1VhI82Y7kgTpWnx9liu1HOOH5EyTimasReBBQwF7WHTpZDoxg/vOsPdZCH6aLlH/0hubY4Mu4BkqGqcJqyc11VE06dEwbsd+bt4jkg46zVjNXmPMOIY9iMm/W4hUvqJj/E43sPQcFsfZBg0NLhBxeQB1RVEtYbdRg/zWrsMw+XEcVgoKcFz5nhot3eJXQuG0MVBQwUUAtHCwMH2WVYRZaGvBOA70jQnhZsAAlASgBKiCI1TrI1QNugpfskspDSmkJ9rpCoHjZuwOLHMDmon6P68TrdVw4Ln+oidBUPheLPjcWkeoK6Wc8jgtN7WcFNDjDcRp4yIKrV9ho1/wD5rG0Mqy218MeKuqMo11BLu/6pUgs11s4a/kLa5e0rlTYLiNRRbSKKFlQIoaoOila51muFjb73supgxw0svPa3HyZZ973vBc/ptLEeNeh5cEDVN3XeCwjPG1DLuVJJKR73V2IsH/doD1T4OdwC56Utedqxuss2bHhrz5J2hnT2hjN97mtb5nGwXlux7BBif9mnFaT5v/ddILrlbOWfcxZqr3TV1dLFDf8ATpoXlscY8LDjzK9HZHlevzPmymlLJXUtO8STTuvYW7r+K7p0EUpNr2UccdnLljHhpvvPi6ouOCQtv3p3Rbug4DQItZVz0LHNo2W2ZlybX4Xugzuj6SnJ7pG6j/JcikGnmfFIN18bi1wPcRoV2+L8bXtquR9rmBjAtoWJ0jW2hkl6eL1a/VWfDsnejzH2i0+8VzR8J/w7g+BfNEWP7EafCJKxs1ZglVJTOj/dHE470d/TiPst+dE/ut7r54/BFnF2XNtNLhEkpZQ4/EaKRvd0vWid7gj7r6KRt3W2J1Vs8qg6GT091JEehB6TS/C2qmUFXxbqgk6ZnifZJ00fr7KsCEX8EFh7hK0tZx46qPoZPT3TqXrO5Ke10FboZPT3UkbhE3dfx46aqZVqvrt5IJemZ4n2R00fr7KpcpWuBNtSfAaoJ5GmUbzBp6qLoZPAe68fNGd8pZRovmMy5iwzCowbf6xUNa4nwDeJK0rnf4u9nGDF8WBQYlmKZri28MfQw899/Ecgg6EEThxsPupoi3dte5HhquBc2fGPtCxCUDAMOwfBIgTxjNRIR3XLrAfYLW+L7f8Aa9ikxfU56xaMb12sp3NiaPs0IPpnjuYMEwKmfUYxitFh8TGGRzqmdsf0jidTeywTEdveyLD5BHUZ9wYuNtInuktz3QvmbmPMGOZixB+I47idbiVW/rS1Upkdy14D0C8sF44OtyNkH0dx74n9jmG4maP/AEgqq2wBM9FRPlhFxw3tL/YLzKr4stkELSYqrHKogaCPDi0H7uK+fcVJWzM6WKnqJGeZsbiPcK5DgGPTMEkeD4lIw8HNpnkH8JsjeHeWGfGFstkqJIqmmzBSRNtuSupGvDvs03CiqPjI2aMqnRxYdmKWIOsJBTsFx42JuuLMt7Os7ZhbM7CMsYnUCHtD0RYB6fVa5VOvyVmuiq3UtVlvFo528WGlcT+Ap5ZOaPN3rSfFvsfqNJK7GKU/+LhziD/wkr18O+InYzXO3xnempydbVFPIz+i+b9RQV9I5zaijqoXNNnB8Tm29wq5kkGm8R6EqEvq5l7aJkPHnBmDZvwOuebWZHWsDjf0NllMNZE9p6I9Lbj0ZDrey+O7Xva4ObbeBuCOI+69bCc0ZlwycTYdj2KUcgNw6Grkb/VB9dBWR3sd4HwISSzRvAFnaei+duQfik2n5b6GDEa2mzFRRgjosRj+u3d+q36tPut05T+MnKtUGR5mytiWGv3fqlopW1Ed/wC6bOAQdUdE86i1uaOhk9PdYNs/2ybOM8MZHl/NNFJUltzS1DugmHd1X2v9ln4eAbHQ+qBIwYmnf4E9yd0zPX2Tag3YOag1QWOnZ4n2TJP1rGPu430URUtJwcgb0Evp7o6GTwHurQCCUEDZGxtDHXuE7pmeJ9lBUH9VyjQW+mjOmvsn3d5fyqbeI0V4IG/V5R7pr94sI3e7xUh4pHdU69yCo1j/AA/Kd0b/AA/KezgE8IImt3HBzhoFJ0rPX2SS9T7qEoJ+mZ4n2TXvbI0sbe58VEnQD9QIAQv8B7peif4D3VhFwAggY10Tt93D0TzMw959ktR2RVX7ILPTM8T7JHvbIwsaTcqv9k+n7YIDopOFh7pehk8B7qzZKAgqtjfG8PcBYcbFSdNHxufZPm7JypoLQmj9fZI6Rr2ljL3PBV7p8HatQL0Ml+A90dC/wHurVroIQVmMdG7fcNBx1UnTR+J9ks/ZOVXRBZ6Vnj+EkjmyN3GEklV7qSn7UIAQyeA90dDJ4D3VlKQgrRtdE7efw4KXpWeJ9klR2X3UA0QWBKzxPsmykSN3WanioSSpKc3eeSBnQv8AL+UdDJ4D3VrVFkEMQMRJeLXUnSM9fZNqDYDmoboLHSM9fZRyjpbbgvbjdMUtOesgi6GTwHuk6GTw/Kt29UiCCJ3RAtfoTqpBNH4n2UVUPrHJRBBa6Znj+FHI0yneZqOGqhVmnH6f3QQ9DJ4D3S9BJ4D3Vrh6o+yCBjxGzcfo4eCd00fifZQ1HbFRoLRmZ4n2UT43SOL223Tw1UStwdi3kgg6CS3Ae6Ogk8B7q2hBC2RrGhjiQRodEvTR+J9lBP2zuaZyQWumj8T7KJ0bnuL2jQ6jVRcVch7FvJBB0MngPdHQyeA91aSWQRNla1oa46jQ6Jemj8T7KtJ2ruaRBa6ePxPsonRPe4uFrHUaqPuVuPs28kFfoJPT3R0EngPdWkqCMSMGhJuNOCDMzxPsqzz+o7mUAoLPTMHefZQuikcSQBY+qjPNXG9QckFboJPAe6Ogk8B7q13JUEQmjtxPsl6WPxPsqp0J5oQWTLH4n2UJhk7gPdMHFXe5BV6GTw/KBDJ4D3VoC6VBF00Y7z7JemYeJPsqveeaLoLXSx+vsoOheToBr6pt1bb1RyQVuhk8B7o6GTwHurXNKgi6Zg0JNx6I6Zh7z7Kq7rnmlugtdNH4n2UJheXFwAsdRqoyVcb1ByQVuhk8B7pOgk8B7q3b1QEEfTx8Ln2R00fifZVe9F0FozMIsL66cFCIJfAe6Y0/WOYV1BV6CTwHuhkb2OD3AbrdTqrQsmz9i/kgb08fcT7I6ePxPsqgSoLD3iVpYzjxUfQyeA90U3bDkVbCCoYZL8B7p0QMLi54sDoFZIUFX2beaB3TR+J9kdNH4n2VW6LoJpf1rGPW3G+ib0EluA91JSdV3NTIKvQS+A91JG4Qt3X6HjpqplWq+0HJBL00fifZHTxeJ9lVSIFQpvl3eZqPl3eZqCSm7EcypfsoGvEI3HAkjwS/MN8rkEypT9s7mpxUMtwKY6J0h6RpAB11QQoUop3eZqX5d3mCCdnUHJKoRM1v0kHTRKahnlKCW2hVEKx8w3hY6pvy7vM1BELJ0faN5p4gf4tSiFzCHkiw1QTlGqiE7fApTO23AoFn7Fyqg2U73iQbjQQT4qKSBzRcuCDnz45NosmUNmceWsPc5tfmXfgdIHWMVMy3SEerrhvJxXz+cN8gMGpNgAup/wD0i+J0dTnXLGCwvc+soKCWWoFtGtle3cHP9N34WgNlOBHHs9YfSOj34IXiefw3Gm/87BY3tFazafBtw4py5IpHeZ2dJbNsI/sPJGFYfu2e2APk/vu+o/zWSAlI0g8BYJwXmrW5pm0vpOOkY6RSPAounBIAlCxZHIBQk70DglskCCbINf7fqhsGzWsDw09JIxgB8dVy3C8smieDYtcDfkV0f8S9RbJNPCDbfqr28bNXNkbd+VjNfqICuuHxti+bxfH7b6rbyiHTNHJ0tHBKDcPjab+OikVXC2Ngw2lhbezIWtF+StBWrzwRZOtdLaygNsEo5JdEhOiCpjWG0eL4dLQ10YfFI23q0+I9VoTN+AVeXMTNLP8AXG76oZQNHt/zXQbrryM0YHSY/hb6KqFiNYpANY3eKiY3ZROzX2wnaxj2yrNbcVw55qMOqC1mI4e51mVEYP4eO539F9LNn+bcEzrlWizLl+sbU4dVsuw8HMcOsxw7nNOhC+T2P4RW4Hib6OsZZ7dWOHVe3uIWzfhs2yYpsqzVGZpZarLldI0YlRX0Hd0zPB7fyND3Ea2b6Vz6yuUfckoaqnxOigxGhqIpqSpjbLBKw3D2OFw4ehCm6Fx/cEEQCuxdm3koRTu8zU4Shg3C0kt0uEEyFF07fKUhqGj9pQQO6x5oU3QOd9QcLHVJ0DvM1BEOIV1QdA7zNTunb5SglskeLsdyUXzAB6pSOqA5pAadQggcF86fjVzNRZj254hFQUxY3B4mYdLKX36aSO+8bdwBNvsvoHm/FP7AytiuOPbvDD6KaqtcaljCQPubL5NYnXz4jX1VfVyOknqpnTSOc65LnG5ufugyfY9SyVOcY523DKeJz3nnoAt1ELX2xOi+XwSqxB7LOqJdxjvFrf8AzWwb3WysdGFu4CcBpqkATlLEWTkgSoE+6VL9kiANk2yckQNsmuCeU0oI3BY7tCoXV2UqyKNoL2NEgHLiskcFBKwPY5jhdrhYjxCSlzdFI6ORr43Fj2m7SDYgrqzZhnyixvIH9qYpUx08+HNEVdJIbC4GjvuPyuZ85YTJg2YKmkc20ZcXxnxaeCpR1lTHh0tDHUPbTTPa+WIHR5bwJ5XK4tTp4zV2WnDtfbR3m0RvEx2/Rt/aFtvrJp5aDKjY4aXdLTVyM/UffvaDw5rS000s8rpJpHPc9xc5zjckniSrGHYdWYlWxUdDTyVFRK7dZGxtySt45B2JRU3RV+apBNKLOFFGfob/AHz38gsN8Olr/u7dWms4pk38PyhiGxjZ23MdS7FcZhlbhUXZt6vTu8L+ULo7CKSjwyjZR4fSxUsDBYMjbYf+adTUkNPCyCGNkUTButYwWDR4AKYNAVPqNRbNbeez1+h4fi0ePlr1nxlJvIuCm8UWWh2hzrcFon4n8JkMuGY7G36d008pHceLVvUjx1WHbY8IGN7PsRp2NvLC0TxgeLf/ACXRpr8mWJcPEsHp9Levjtv9HM+R8TGB5vwfHJGvdHQVsNQ9rDZxax4JAPja6+teE4hT4lQ0uIUj+kp6uFk8Th3teA4H2K+PzX204DvC+jHwR5rdmDYTQU9XN0tTg88lATrcMH1R3J/hP4XonztvgqvV8Wp3zLLW1JSO/wBY6um74oK5CAFP0B73BL0B8wQJS6OdyVi6rn/VwXu1B00WM7QNomUMiYX/AGjmrGqfDIiCY45HXmlI7mRj6nHkEGWk24ryMy41hOB0LsSxrEqPDaKNpL56qYRsH3K5D2k/GbWGpdTZCy9DFC0kfOYqN57+UTSLDmb+i5kz9nzNee8XfieZsZqsSnLi5jZHfpxejGdVo5C6DtPaX8XWRcBMlJlOiqMzVbTbprmClB/vH6nfYWXN+0D4l9qeaulgZjQwOifcCnwtnRfSe4vN3HnotS4Lg2LY7XsosJoKrEKp/VjgjL3fjgt25E+GrH8QDKnNmIx4PCdfl4AJpzz13W/c39FlWlrdoYWvWveWi6utrK2pdVVdRLPM4/VLLIXuP+IklengGXcfzDOIcFwevxGQm1oIXOHvwXY+VNiGzrANyT+xP7TqG69NiEhk1/uizf5rY9DBBRUwpqOCGmgHCOBgjb7NsFvjTT4y0zqY/DDjvBfhx2iV7OkrYsOwkdzaqpBd7Nus9y/8L2GRdHJj2Z6qocNXxUVOGN5Bzjf8LowegsiwW2MFIaZz3lrPCthezChja12WzVub++qqnvJ52sFlNDkPJFC0CkyjgkQHD/VA4/8ANdZGEcFsitY7Q1ze095QU1HRU0IhpqOmhiHBkcLWtH2AVjedazXFoHcNAkS2WTExwJ6xJ8LlPbJI0WD3gejiiyE3FeopoKgETwQzA8RJG11/cLyMRyflbEGFldlzCJweO9RsB9wAvfskKhLBMT2QbNcSINTlKhY4C29Tl0R/BWEZk+GjJ1b0kmCYriWFSHqsfaeIH72dZbxKSywnHWe8M4yWjtLkrM/w0Zuo29JgmK4bi474y4wP/wCbQ+61PnDJeZ8pVfy2YMFq6F1rtc9l2OHo4aFfQ2yZU09PU07qapgingf1opWB7D/hOi1209Z7NldRaO75sxyStc1zSbtN2m+oPoe5bd2dfETtRyWyOmp8eOK0LBYUuJt6drR6OvvD3K6EzbsP2c5hLpf7HdhNS7jNhz+jF/Vhu0/ay0XtO+HrMmAB1blaV+YKAC7o2sDamPmy/wBQ9W3Wi2G0OiuelujojZb8XeUMfEVBnaiflusJA+ZYTLSOPqR9TPuLeq6JwzEMPxWgixDC62nraOZodHPTyCRjgeBBC+QdVBU0lQ6GoilgmYbOZI0tcD6grJcgbRM4ZFr21eWMercNcDd0cb7xP9HRn6T7X9VqbX1eKmpbfUuTtjnxdYZis1NhO0SjhwqofZgxSmv8uT3GRnGO/iLgd9l1LhNfSVtBFX0NVBWUk7Q6KankD2PB1BDhoUHpIUQmHe0pemb4FBDUD9UpgCndGZPrBABSdA/zNQRDiroVboHcd4J5nb3tKCUpHdQ8lF07fAo6ZrhugHXRAR8An6JGxkd4T913ogjm6n3UKmmB3dbcUzoz4oGX8U6DtAndGlaNxwKCZHHuTQ/xb+Ub/g38oEn7Iqt9lYeS8btrXTOhd5gghKfB2oT+gcf3BAjMbt8kEDwQT31RdRdM3wKOmb4FA+bsnKorDpBINwAgnxTRA7zNQQWUkPatT+gf5moEbo/rJBA8EFgJL6qHp2+BS9O3wKB0/ZOVVTmQSDcANz4pBA7zBBDZSU/ahOMDvMErIzG4OJBHDRBNeyVM3vRG8EDajs/uoFPKd5trd6jDD4j3QMIUlP1zySbh8QnRjcdc6oJxZCZv+hSdIB3FA2p4DmolK79U7o0trqk6F3mCCJTU/wC5HQm3WCGDoz9RGqCZBsEzeb4pd4cboIKrrN5KJWJGGUgtIsNE3oHeZqCFWafs/umdA7xanNIiG47noglJQmdK31R0reOqCCo7UqNTujMrt9pAB8Uny7h+5qCHmrkHZN5KHoH+ZoT2yCMBhBJGiCYpLqLp234FL07fAoK83bP5pqmdEZCXggB2uqPl3eZqCGyuQj9JvJQ9A7zNTxIIwGEEkIJbpVF0zPAo6ZvgUFeW3Su5pFMYXPO8CNdUnQOH7moIu5XI+zbyUHQO8zU/pA0bpBJGmiCVCj6ZvgUnTN8CghePrdzKapjC9zi64F9UdC7xaghVxh+gclCYHeLVIHgCx4jRBJdINSmb7UoezjdBTPWPNGpUvQPuTcapegf4tQQq93Kv0D/EKUSNOiCRCZvDxQXhBT7yfVKpegdfi1L0DvFqCJXG9UclCYHeLUvTtGm6dNEE3ehQ9O3ylJ07fKUFd3XdzSWKnMDybhzbHVHQPP7moIVdZ1G8lB0D/M1PEzWjdIOmiCbRIVEJ2+BR8w3ylBV70tlL8u+995qX5d/magiZ1xzCvKsIHtO9dumqeZ2+BQTXTJuydyTOnb4FI6VrxuAG7tEFZLf0U3y7vM1Hy7/M1A2m7UcirSrtYYT0jiCBpon/ADDPKUEygq+o3ml+YZ4OTXnpxut0trqgr9yFOKd/maj5d/magdSdV3NTqu0/Liztd7XRL8wzuaUEyrVPaDkpBO3wKa5pnO+3QDTVBAjVTfLu8zUfLu8zUFi5SoRp4IKdT2x5KNSVPbHTuUYQCuQdk3kqiuQdk3kgchKPVCClJ13c00BLJ2juaS6AHEc1fVAHUc1fQJomyX6N3JOTZB+m7kgp3Si6El0EsHahTSlhaS82a0XJ9FXgNpWrC9vOPzZX2O5txuDf6aHDZGwlvFr3jdadOFiboPnTt5zd/pptezJmGOR8lNPVujpS7/cx/Qy3gCG3t6rM/hgw2QjFsTdE3cduxB/fe97clpaQW77811JsHw/5HZtRPdGGPqnOmNr6i9gT7Li19+XFt5rngWHn1UW/t6s2AATggjVAFlRvblShInAIFCEIUgCQ6oJTbFQNPfE7K1uX8Ph6WzzK5255hoLrQmFRdNidLFYHelaLfddE/EfhmF1OVoa2rrfl66ncRTMv2oPWbb+q0XkSmNRmzD2N3Duyb5DjYEBXmgmJxQ8Px2JjVzM+UN/MYGta3wAH4Twow8klOurJRHX1SpoShAoRwQEEIEKaWp5QUHj5jy9huP0ggxCIks6kjTZzORWjc1YPLgGOT4c5xkaw3Y8ttvNPArom6xvPOWYMx4eWG0dXGCYZfA+B9FjMbsonZD8OPxDY/s1qKbA8VL8Vyo6X9SnOstIDxdC7w79w6HutdfQvLmM4Zj2C0eM4RXRVtBWxCWnnj1a9p/ke4jiCCF8iK+iqsNrZKSqidFNGbOaV0f8ABxt6pMhSPyXm2VzcArJ+kpawm7aGV2h3h/u3aXI6p1tqSsGbvxUZSeldfxU1LVRTQsmilZNHI0OY9hu1zTqCCOIUEjgZnc0CXSk3ShuiR2gQXmdUckWXk5gzJgOXKFlZmDGMPwqne4MbJWVDYWud4AuIuVhmLbd9keG4gKCqz7g/T724RHIZGtPq5oLR9yg2VfRUhqFzXmT4zMjUGMmjwjAMYxakZIWvq2lkTXC/WY1xuRz3VjOcPjTpI4mR5PydM+Qi75cVmDQ0+AZGTfu1uEHXBaUoFl8/q74vNrU9Q2SCXAaVjTfoo8Pu06cCXOJ9VUqPiy2wylxbi+FwXN7R4azT0FyUHX/xV1rqX4es4yMLd40TYxc+aVgP4XzILgRcjRbGz5tu2l52wmrwfMGZ5Z8Nq3NdLSRwRxxndNwButva/qtbOv3oOhsn0DcPyxh9KAA5sIc63e46levYhaEwfOmYsNAZDXukja0NDJQHAAeC29kXMDcw4K2peA2ojO5MALC/otkTv0YTD32lOCaAlClieEqaE5SF4JEI7lAEhslSH1QIU0pxTSgQppsSnFNKDXG2zDmOoKTFGg9Ix/ROsNLHVapB+oXJt3robN9A3FMuVlG4C7oy5no4ahc+bliQe7RYWhsq6q2U5QwfLGExVdGPmKuribI6peBvbpF90eAWcFznLXeyTMMD9ltHiGKzx08dFvU75ZHaEN4feyq5i215Ywu8VBBUYnMPKOjYPuf8l5y+LLkyTG28voWHU6XT6elt4rExvs2WSQUuvgVzvmHbtmGsj6PCqGkw0Hi/tX/nQLFo9p+dxIXOx6pdc3sQLfy4LbXh+WY3naHLk+0GlrO0bz/vvdYXsdU4OWkdne0PMuKSsppC7EHk63jBP4W6aMTPpY5J4uikIu5l72XPlw2xTtZYaXWY9VXmpunGqJKZk8T4ni7ZGlh5EWSAWPFSNeGrU6bRvDivMmHOwzMdfQSAgwVD2WPhfRdP/wDo8swNhzBmfLD3kfNU8dbC3uJjO6772K0dt/phS7TcQIAAnayUW9QvZ+EnMbctbecvVE8hZT1sjqGY91pRui/3svS4rc9It5vm+qx+izWp5TL6RtJur1Efpd9lU6N4NrajQqel3mh1/FbHOuXHG68fN2Z8Byngk2NZixWlwzD4R9U077AnwaOLie4C5K1D8QnxF5Z2ZiXB8P6PG8y2/wC5sk/SpieBmcOH9wa8uK4O2nbRs27RMddiuaMWlrJAT0MLfpgp2n9sbODR68T3koOlts/xfy1Mc+FbNaF9M0nd/tesYOkI8Y4j1fQu1/hXKGY8bxfMGKS4pjWJVWI10xvJPUymR59LngPQaBS5Ryzj2bMWZhmA4dPXVLtXBgs2MeZ7jo0epXTGzP4dcCwpsVdnKf8AtitFnfKROLKZh8Ces/8AA5rOmK1+zC+WtO7nTI+Qc150q+hy/hM9W0Gz5yNyGP8AvPOgXSGzX4csAwYR1ub5hjdaLH5aMltNGfX9z/wOa3hh9NS0FHHR0FLDS00QtHDCwMY0egGinJXVTBWvfq5L57W7dHn4Ng2EYLTmnwfC6LDoj1mU0Ij3udtT91eAt3JUtlu7NBLBLZKj7oBGiAlv6IERySoUhOaEWRyQKEvehJyQGiEvckUBCElk5IiQkISoUhtk1wupQlABUDFs5ZFytnGnMOYMHgq3EWbOBuTM5PGvvcLnzaN8M+MUIfWZKrP7Vp9SaOoIZUN/uu6r/wAH0XVhFk0vNrLC+Ot+7OmS1Oz5u4xhWI4LiElBilFUUNXEbPhnjLHN+xWX7KtrWd9m1a2XLWMyx0pdvS0E/wCpSy+N2HQE+LbH1XaGdsoZezlQGizDhUFa3dtHKRaWL1Y8ajlw9Fy9tU+H7MGXRNiWWulxvC2guMbW/wCswj1aOuPVvsFzZME16x1dWPPW3SejrPYV8RuUdpHQ4TXbmA5jcLfJTyAx1B/8F54/3TZ3Pit03JNrEL4/NbJDJxcxzDfwLSP5FdIbDfipzHlOKnwTOkcuY8HZZjajf/12nb/eOkoHg4g/xdy0N7vuG/RNT1jmQs5Zazrl2HG8sYtT4jRSaF0Zs6N3le06scPAhZE03QL3KkrvcqXegLJWddvNJdKw/W3TvQXUXSEaosgbLbcKj+6kl7MqLeFkC3KGkukATS5JF2oQWLIsjkj7oEtqE5If6p3cgRMn7IqQ2Uc3ZFBWRdCLIHw9q1WiqsI/VarXegEybsnJ5TJuycgqIQg2CB9P2oVtU6ftQriATZBoOacmyHQc0CAaJUBCBkujLjxUVypZ+z+6hBQOv6p8ZBd9lCpIOueSCUphF1J3JjkCQ6Su5BSqKHtX8gpggOCgqj1fupyoKvi1BEHaJd5M1QEFmnN2nmpCFFTdQ81MCgQcVXqO0+ys3Vao7X7II7pUiEFmDsgpPuo6fshonoFKqTdq5WuSqzdq5AxAQlQWouybyTuabF2beSfogSyqy9q7mrXeqkvau5oEuhIhBcjt0Y5JUkfZt5J1xwQCpyX6R3NXFUl7R3NA26EiXuQXGdUckW1SM6o5J2nigFTkNnnmraqP67uaADroumpUFwAWCEo6oQgQ8LKnexVzuVM3uUChxRdNShBcHAJbpBwCUIBUX9Y28VeVJ3XdzQNBQhCC83gEHikHVHJOQJZUn6PPNXlRf13c0CX8EIsjvQXu5ACUJCUA7qnkqN1ed1DyVFAXToe1bzTbap8Pat5oLeqVIShBHU9ieYVVWqnsTzVQIFBU9J1nclAp6TrO5IJ7IQlQVazrN5FQqes6zeRUCACtUvUPNVTxVql7I80EpQhGqCD5keQ+6PmR5D7qDghBMWGY9ICG37ikFOfMFLTdiPupO9BW+XdfrD2ThL0Q6MtuW96nVObtnc0EvzI8h90fMDyH3UCEE3QF31bwF9Uny5849lYZ1G8kuiCv8ueO8NPRO+ZHlPupjwPJUO9BZ+YHkPukMwf9G7be04qBOj7RvNBJ8u7zBHy58wVlCCv0fRDpCQQFoj43M7OytsWqaGkbGarH5v7O+sB27EWl0jgPHdFr9xIW+ay/QO5Lh/8A9IXj7KnM+W8qse0mjpZKydttQ6Vwa3Xk06IOVHyb+7p38F2dlo2y9hojjEbPlYrMH7fpGi5Byvhj8VzNh+GxtLjPO1pA8L6/hdmUzWRQshjFmRtDG8gLKq4laPVh6n7N45/iX8OkJBfvTkiUKrenKEqAhSgqS6Ci5QGhQHBqQpt/FQlpT4o5wYMLZu8A8g+Gq09ktj5M14Y1jiHGdvBbV+KOa9XhUAH0iJzr+pctVZMeWZrwxwJH+sN4K/0P8mrwfGZ31l/l+joOwBNvFOsjd1PNKu9TAJRyRohAuqVIEXsgCkKUppQBKS4SG6SxRLF9oeVYswUXzNKGtxCFv0H/AHg8p/otJVME1NUPp5mOjex1nscLEFdJyAtBN7LVu1p+ATxtliqYTijHAWi13m94dbhZY2jxZRPg2n8JXxBy5OqafJWc6t8mWpHblHVyauw9xPAniYif+HiNLrqnP22XZhkkXxrNlHJUvaHtpaE/MykHhoy4bfuLiAvl6HnuSF7lgydkZ2+NONu9BkvKN+IFRi0vsRHGf5uWnc2/E5tex9ro25kbhMLgQY8Np2w8f4jd35WocPw6uxCUR0dLNO49zGkrLMK2bY5Uua6qMNHGeO87ecPsE2N2P5hzLmHMVTHU49jWI4rNEC2N9ZUvmLATchu8TYX8F5gdI42BJJ7gtxYXszwOnj/1yWesk8d7caPsFkmGYBg2GAfJYbTxOH7tzed7lZRWWPM0EMLxNwDhh9UQ7gehdqvUosl5mqwHR4TO0Hvksz+a36C7xRqp5TmaYpdmuZJR+pHSw/35h/RWmbLMXPaV9EzkXH+i27qi105YRzS1KNltcOtitN9o3FKdl1eT9GK0xHqxwW2N1G6PBTywc0tZ0eyg3aanGAB+4RRa/lZ9gODUWCUDKKhYWxt1JPFx8SvQCcEiIhEzuBdKCgIUoKOKcPRNCVA5CQG6VSDuSFLZCgNKanO4pvFAhRZKl7kSifGHAgjQjVc9ZrojhuY62kLbBspLeR1C6ILgFpLa5SGDNsk+pZUMa8H14WWNk17pMqVrqnKtbh00sj4aR/zDIQCRdwsXW+yxKds9fWPfBDJI5x0a1pcfwth/DtVx0+e30cti2tpXxhpbcOIsbH2K6NosNoqU71PRU0B8WRNb/IKszar0F5jZ6PR8MnX4a3m+23Ts5JwnIubcTcwUuA1xa/g50Za33K2PlTYTXTOZNmKvjpY+JhgO88/fgFvsvcBa6YXFcl+IZLR06LXBwDT453tM2eRljK+C5ZpegwikbFfrSHV7uZXsb570gJKUNXFa02neV1SlaV5axtA3rprwSpA1PACxZ7udvieoTFmDC68NI6anLHO8S0/5LWuXa1+GYxQYjG8skpqqKZrhxG68Fb5+J+npnZTw6oeSJo6rdjHiCNVzo6QtsASLaghX+itzYYeD41jimrtMeO0vrq7G8Op8AGP4hXU1HQClbUzVE7xHHGwtDrknhxXHfxFfFTW4qZ8ubMqiahw43ZUYvulk1R6RA6xt/i6x7t3v03tg205q2h4ThOBVr30WD4fSwx/JxvNqiVjQDLIf3E20B0Hd4rBMsYDi+ZcagwjBqOWsrJj9EbOAHe5x4Bo7yV191TKm7p6ypsBJPPM/uu573E+5JK3fsq+HfGMZ6LEs4GXBsPNnNpR/3qUeo4Rjnr6LcOw7Y7g+Q4WYpiZhxLML26z7t46bxbED3+LuPhZbWeQSurHgjvZy5M/hV4eVcsYJlfCm4ZgOHQUNK3UtjGrz5nOOrj6lew1oTkh0XT7nKWyEDVKGlSAH0SotbXgkJPcHHkFAdb1SJrXdyf3KUEQlNiksoSVASIHqpQUnwQhCgGqAhCkGqEiOKgKk4oSoEShFl4+csx4blLLdXj+MTdHSUzbm3We49VjfEk6JM7J79Ho4rW0uG0bqusmbDE3vPf6DxWpM47cqDBhJ8hQRzbgJvNLYm3gAuetpe2HNOc8RlkNScOoLlsNLAbbre67uJPiteP35nb73Oe497jcrlvqPCrqpp/GzpXCvina6pDcUypanJ1dTVP1j/C4WPuty7PM/5az3RunwGvD5oxeallG5NFzb4eouFwYMJxD5F1f8nUfKscGum6M7gJ4C6sZdxnE8vYvBiuD1stHW07t6OWN1iPQ+IPeDoVjXPas9WdsFZjo+jIYQEodurXuxDadSbQ8smaRscGL0dmV1O06XPCRo8rvwdPBZ9v7y7KzzRvDjtHLO0tW7YNjeXM7skrqJkeEY5YkVMTP05j4StHH+8Nea5Gzzk7MGTMXOG49QPppTrHI3WKZvmY7gR+R3r6FbgKoZky5gmZsHlwnHcPhraSQaskGrT5mni13qFqyYYt1ju2481q9J7ODtmmfM0bPcwx43lfEpKKoBAlj60VQ0fskZwc38i+hB1X0K2AbeMs7UsOjpWdHheZI2XqcMkk1fbi+Enrt9OI7x3nizbjsWxPIzpMXwh0uI5fLtZN28tNfgJAOI/iGnjZanw2urMNxCCvoKqalq6d4khnhkLXxuHAgjUFcVqzWdpdlbRaN4fYP5thIG6dfVHQk/uHsuW/hj+JGlzXJRZTz7PHTY+5zYqXECN2KuPANfbRkp/wCFx8CbLqthbe1xveChkh+XPmCOhLRvFwIGqsXTZD+k7kgiM48h90fMDyn3VcG4SkIJ+k6T6A2xKDC7xCjg7VqtcEEPQu8wRuGM75IIHgpwo5+zKBvTjylJ0/8ACfdQoQTtk3zugWKk+rxCrwdqFZHFAgDvEJsgcGG50T02Xsygg3SUBhPgngXTrWQMa0sO8baJxn/hPukkP0lQEoJ+n/hPulMnSDcDSLqFounwi0gvogXoHeYJOgceLgpi5viPdKCPFBEyEsdvkg2Utz4JXdU6oPNAhKZK6zQSNAU4n1UU5/TKA6ceU+6OnHlPuoBqlt6oJ98SnctY8UdCfMPZMpx+qOStIIOgPmHsgDojvHW+imuo5+qOaAEl+5Bue5NYNVIEEesbt8672lgl6ceUoqeq0KBBP048pTXgzHTS3iowVLTcXIGiB/mCXoXW6wVhIUEIJhFj9V9dEdOPKfdJUX3hyUaCbphfqlI5plO+CAFErEHZ/dBH0DvMECF3mCsFCCAP6L6CCbI+YHlPumVHalMsUE/Tt8pSGMyHfBABUICsw9k3kgjNOfMPZHQO7nBTpbBBXbLuDcLSSNLp3Tg/tKhf2juaLeKCbpx3NKaYi879wLpisRD9NvJBF0DvEJOgd4hWUiCEShg3C0m2iXph5T7qJ/aO5oCCbpv4fymuiLnF1xrqhgBUgsgi6F3iEGFw7wpjZJdAzpWiwIOiDMPKVA7iUIJ+nb5SmmJzvqDgL6qPuVpnVbyQQdCfEJegceDgpylCCHpwNN06I6ceUqueJ5pR6oJ+nFuqUzoHcd4KNXBwQQCB3mCOhd3EKfRCCETjhulL0w8pVc8TzQgn+YHlKb0DjrvDXVRq2zqjkggEDvMEvQO8wU5Qgh6YD6S06aIM48pUMnXdzKQHRBOJxfqlNMLid7eGuqi4hXGD6RyQQCB3mCOgd5grFkqCA1AtbdKT5geRyrnii5QWPmA76d0i+iT5d3mCiZ128wryCt8u7zBHROj+u4IbqrFvVNm7J3JBF8wPIfdHzA8p91XSoJy/pv0wLE63SfLu8wSU3bDkVa5oKwp3eYJQDB9R+q+min5KKr6jeaBvzI8h90vzI8pVcoQTuBqNR9O74pPl3eYJ1J1Xc1Mgr/Lu8wSh/QfQ4b19bhWFVqu0HJA41I8h90fMjyH3VdCBwKRWPl/4rfZJ8v8Ax/hA+m7IfdSFQGQw/p7u9bvR8wfJ+UFhUpu2dzUvzB8v5QIuk/U3rX1sgg70cFOYD5/wj5c+f8IJmdQckoVfp936d29tOKX5n+D8oLB4FUO9T/Md25a/qgU/8f4QQH1To+0bzUvy/wDH+EGHc+revbXggnukuoPmCf2flKJz5PygfOf0XX4L5n/F5XVFd8Q+bDUF3+r1EdPG0nqsZEy1vcn7r6Wl3SjcI3QeOvcvlZt3xyozDtkzZitRIJDJik0bHC1tyN3Rstb+FgQev8OuECvz785I3eZRQOkv4OOgXSe7ZaW+FyOI0eMTtBMpcxjjfS3EfyW67Kh11t80x5PdcExxTSRPnvJoTwm2QLrkWx4QkB9EoKIKkukJCS6lIKa4EqQAJ7LAqBoD4ot75zCWngInH8rVuS272a8MH/jtW1vigkhfiVFEJR0kcAc5h8CdCFqzIzC/N2GhvdKDxsr/AEX8mrwPGP6y/wDvg6CJ+o28Uoso26kp/erBUHIsiyByUAQlSd6AJTUp4pO9EkcqmL4hFhmG1FfMC5kLC4gd6tlV8Qo6evopqOqZvQyt3Xi9tEGjMy5xxnGZpN+qkgpnE7sMZ3QB624rHoopZpWxxMc97jYNaLkrbs+zDCnYkyWOrmZSAfXDxcT/AHvBZPg+XsFwgh1Dh8TJBwkcN53uVhyyy3hp7A8j49ibwTSmli75Jxu+w4lZrhGzLDYXh+IVctUR+xg3G/5rYJ14puiy5YRzSr0NHTUMDYKSFkMbRYNaLKyEv3QApYlCOSAlCBLJe5HelQFkWSpbIG2S2CWyRAAXQl5IQHNCRKEC2SpAEqBw9EqaEqBUiEhUhCkQShQEKRKdUiBjxdat22UzhPQThp3d0tLu69+C2mQtf7a4z/YlJLY/TMRpyUW7Mq92KbIMSGFbRMIqnuYyN03RSOcNA1wsVuiv225Wp8WmozRYh0EchjNQACNDx3eNlzfh73/PU4Yd1xkaAb8DdXM34XiWDZgqqLFoiypD94n9rwdQ4HvBXBl02PLf1vJcaTiGfTYZjHHTf/H/AE7Bw7EKbEqKCuopRLTzsD43jvBVxjbjVct7I8/1mVcWjgrppZsHlO7LDe/R/wATfC3guosMraLEqCKuw6pjqaaVt2SMNwf8j6Kp1Gnthtt4PW6DiNNZj3jpaO8JN2yL2TimEXK53edvJCSeCAEvBBrP4jqcv2d9KQCY6phBtwXNBbd1yur9uDI6jZjiolB/SDZG8wVyhvg62V1w6f4W3veM+0MbamJ84/dmez7I2M5+zBT4ZhEbQBE11VUyA9HTsv1nHx8BxK7M2Z7Pcu5CwMYfhEW/PIAaqskaOlqHevg3waNAsW+HGho8P2Q4I6jlZK6ra+one1oB6QuILD47tu/xWz4rkBXeHHFY3eUzZJtO3gl3QEhShKuhoN1RcJSEm7dAu8BrdYDtZ2t5e2ewMgqmvr8WmZvw0MLgHbvc57v2t/J7lZ2wZ4o9n+UpcVnDZayW8VDTE6zS27/4RxJ/zXC+YMWxHHsXqsWxaokqa6qkMksrzqT/AEA4AdwWjNl5ekd27Di5us9m08zfEXtDxOeX+z6ukwando2Omp2uc0f33Am/qsAr89Z0r5zPVZrxqV5N7mseP5FS5HyLi+aXGWEClommzqmUHdJ8Gj9xWy6TYxgvQ7s+MV75bdZrGNbflYrVXHlyRvDfbJix9JYhlXbNtEy/KDFmSorYr6w1/wCuw/8AFqPsQumNie2PDNoMMlBVwx4djsDd51O1xLJm974766d7eI9Vy/tD2bYjlmmOIQ1Da7Dw7ddI1u66O/DeHh6hYlgWJ12C4xR4rh0roaujmbLE8HvBvbkeB9FEWvittYmlMtd6vo4JLpwK8vKeIxY9lnDMcgAbFX0sdQ1t+rvNuR9jovUIsu3o4tpgJU3klHNEFRdJ3pSUAjmhCgCLIQgEISG/gpBvbq5v+NnFakQ5awdryKaXpqmRnc5zbNaTyuV0iG+K0D8aOX3VOWcGzJDG5xoJnU05HBscmoJ/xAD7rVm9idm3D7cOacn4A/MeZ6TB4pWw9M4l7z+1oFyR4my6Ly3kXLWBwsFLhcUsoGs1QOke7110H2XNmXsYqMGxyjxWlF5aaUSAHg4DiDzC6iyzmHD8xYTFiOGSh8Tx9bCfqid3tcO4j8qNHFJ337stXN428nozx076V9JJTxPp3tLXRFg3SPAhc7bX8mMy1iUdbh4Iwyrcdxp16F/Esv4d4/8AJdGBm8sU2tYS3ENn+Jx9HvyQsE8foWm9/a66NRji9PfDRgyTW/uac2G5pflDaRheIiUto55BS1ovo6F5AJPLR32XeoiDe8H1HevmpvdEQR3G4X0RyRikmJ5KwLEJm7stTh1PK8eBMbbrk08ztMOrUVjpL2HaJhKdcFFgulzIZY2zRuilY2SN4LXMeLhwPEEHiFzptu+H5j2T5gyFThrtX1GFDge8uh/+D28F0gUlyOCxtSLxtKaXmk7w+bh6WlmLXCSKSN1iNWua4H8EFdbfDD8UFXDW0mUdplaJqWW0VHjUp/UiPBrJz+5vdvnUfuuNQu3zYtT5ubLmHLMMVPj4G9ND1Y63+gk9e/v8VyRW0tRQVk1LW074aiF5jkikaWuY4aEEeK4MmOaT1d+PJF46PsRE9sjQ5pBaRcEG4I8U94/TdyXDvwkfEU/BHUOQc91gfhRIiw3EpX60nlikJ4x9wd+3gdOHbbakSANABDuBBvoe9YNiECwSqfoP4vwj5f8Ai/CBkPatVruUHR9H9d727knzH8H5QTpk5/SKj+Y/gHujpOl/Tta/egiTgLqQQEfu/COit+78IEhH6gVhQ26Mb972VPFsbw7CaQ1mK1lLQUwNumqp2RMv4bziAg9G6bNrGbLQ+aPiv2S4NidRQQ1uI4uYYyenoKXehc8fsDnFtz62t6laHzj8Zed698sWWsAwjB4C79OSfeqZgL99yGf8qDupp8LnkFjGZdpGQ8tzMgx3N+CUE0hs2OWsZv8AG2oBJA9Svmrm/a5tLzc57cdzji9VC5290DJjFCD6MZZo4+Cw6kpqyvqRDSwzVE7zYMjYZHuPhYXJUTMQPopnv4odk+Wq6OijxapxyV3XOEwiaOMer3Oa08m3WtcS+NPBosQezD8iYhU0jSQyWevZE93HXdDHAd2lyue6TYFtZqaijibkzEB83CJo3PLGNY09zyT9Dv4Tr6LOsr/Cbn7EopJMZrsKwMtfutZK8zveLdYbmluZXHk4hpccb2yR9f2bIxXntDJcS+NXMrrf2ZkvBqfT6vmKiWX23S1Ylinxe7XKpwNK/AaC3+4w8O
  <ul class="nav-links">
    <li><a href="#nosotros" data-i18n="nav.about">Nosotros</a></li>
    <li><a href="#equipo" data-i18n="nav.team">Nuestro equipo</a></li>
    <li><a href="#testimonios" data-i18n="nav.families">Familias</a></li>
    <li><a href="#como" data-i18n="nav.how">Cómo funciona</a></li>
    <li><a href="<?php echo e(route('contacto')); ?>" data-i18n="nav.contact">Contacto</a></li>
  </ul>
  <div class="nav-right">
    <div class="lang-wrap">
      <button class="lang-btn" id="langBtn" onclick="toggleLang()">ES</button>
      <div class="lang-dropdown" id="langDropdown">
        <button class="lang-opt active" onclick="setLang('es')">🇸🇻 Español</button>
        <button class="lang-opt" onclick="setLang('en')">🇺🇸 English</button>
      </div>
    </div>
    <button class="dark-btn" id="darkBtn" onclick="toggleDark()" title="Modo oscuro">🌙</button>
    <button class="btn-ghost" onclick="openChat()" data-i18n="nav.chat">Hablar con IA</button>
    <?php if(auth()->guard()->check()): ?>
      <a href="<?php echo e(route('paciente.inicio')); ?>" class="btn-solid">Mi Panel</a>
    <?php else: ?>
      <a href="<?php echo e(route('login')); ?>" class="btn-ghost" style="margin-right:6px">Iniciar sesión</a>
      <a href="<?php echo e(route('register')); ?>" class="btn-solid">Registrarse</a>
    <?php endif; ?>
  </div>
</nav>

<!-- HERO -->
<section class="hero" id="inicio">
  <span class="hero-badge" data-i18n="hero.badge">✨ NUEVO · IA especializada en neurodivergencia infantil</span>
  <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCANoBwoDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAAAAECAwQGBwgFCf/EAF8QAAEDAgMECAUCAwQHBAUCFwEAAgMEEQUGIQcSMXETMjNBUVJhkQgUIoGhI0JiscEVcoLRFiRDU5Kishc0Y+EJJXN10vA2RFR0o8I1VmSEk5SzGCYnN0VVZfFGg+L/xAAcAQEAAgMBAQEAAAAAAAAAAAAAAQUCAwQGBwj/xAA+EQEAAgECBAIHBgYCAgEEAwAAAQIDBBEFEiExQVETIjJhcYGRBhRCobHRIzM0UsHwFeEk8QcWU6KyYtLi/9oADAMBAAIRAxEAPwDslH3SEpN7vQOCWya03GidzQCryX6RysKtIf1DzQIl7kl0BA9vAJUrRoEttUDDdSC3gmOFk8HRA5IeCAg8EDgUFJf0S8UEdR2TlUKt1HZOVTuQClpe1+yi71LS9p9kFpBKEmqCKq7Mc1WVmq7Mc1WQH3U1J13clCpqXrO5ILCX7pEIIavg1V1Yq+DVAECKek/coVPS/uQTIulSHiga/rfZKh2jvshAt1WqO0+ysKCo1k+yCJCEcEFuHsmp+qZD2TU5Aqpzdq7mripS9q7mgakJSoIQXmdUckIZ1RyQPRAHgVRV46gqigErOu3mhKzrt5oLuqLIQEDJT+m7kqV1dl7J3JUkCqSn7YKKykp+3CC4j7JO9LdBDVdl91WKtVPZfdVUApqXrnkorKalP1nkgnS9yRFkEVV2f3VfVWans/uqxQHNS0t988lEVLS9oeSCwhCEEVV2Y5qsrNV2Y5qsgLlT0n7lAp6T9yCe/ohKgaoK9X+1QKxWcWqugRWKPg7mq6sUfB3NBOUBHJKgq1fXbyUSmq+u3koSgFapuy+6qK3Tdl90EiEJUFSo7Y/ZRp9R2xUaBVbg7JvJVPurdP2TUDwlRoEiCm/rnmk+6V/XPNIgQq5D2TeSp2VyHsm8kD+PckRzSoKkx/UKYSE6btCmfZABWKTqHmq6s0vUPNBMkslSX8EEFXxaoNVNV9ZqhQCs0nUPNVlZpeoeaCZCRCCrVdr9lGCpKntTyURQOHEc1dCpDiFdQKkd1Tr3IQ7qnkgojgl7kg4JUDoe1bzVtVYu1bzVpAvBRz9k5Seqjn7JyCqkvdGqCgkpu2VpVabtgraBNUyo7F11Io6jsXIKiEgShBJB2zVbsqkHbNVtABMn7F3JOTZuydyQVEI1Qgkh7UK0FVg7VqsoDkmVHZFPUdRrEboK33SIRwQSU3ajkVb+6q03a/Yq0gNVDVdmOamUFX2Y5oK6TvQlQTUvWdyVjmVBS9Z3JWECKvV8Wqyq1Zxb90EKTkhKgsUnUPNTgqCk6h5qdAKpV9qOStqpVdoOSCJKkSoLdP2I+6kCjp+xCkQIqk3bOVxU5+2cgYhJqlQXIeybyT/ymQ9k3knoBUp9Jnc1dVKftnIGEoRyQEF2Hsm8k8pkPZN5J/3QCpTdq7mrqpTX6V3NAxHcjRL3ILsfUbyTk2Ps28gnIEVOTru5q6qT+u7mgbxScEqBxQXxwCRA4BKEAqBtc81e7lQPE80Ag8UXQgvN6ot4JUM6o5JSgFRl7R3NXlRlt0juaBqEIugvR9m3kEqSPs28glQCoydq7mVfVGTtHcygS6Q8EI7kF8DQJdUg4I4IEf1TyKog6K+eoeSoIAp8Pat5pifCP1Wc0Fzgluk0SoIarsTzCqq3U9ieYVRAXU9JffdyUCno+s4+iCxZCVHBBXq+Lfuq6nq+LfuoUCK1S9n91W7lZpezPNBMj7oQgg3vVIXKew7wEWHgEDYj9CfxVaY2eQNFHvHzFBc+6rS9o7mmXd4n3VmIAxtJGtkFe6UFWd0eCWw8AgRg+kckpsqr3EPIueKTePmKCy7gUwPHioQ43GpVqw8AgbvDxRvAkWIOqdYXtYJJAAx2mtkDkKlvO8Sl3neY+6CzUdk5VFJCSZQDchWd1t+qPZBRCmpe0+ysbo8o9lHPYR3Asb9yCXuShUt4n9xRvHzH3QT1fZjmq2imp/qeQddO9T7rfKPZBSU1J13clY3QO4eyhqRutBbpr3IJ0gVMOd5j7pQ53iUEtXazVApqfUuvrzU1h4D2QUjZT0n7lNut8o9lHOLFu7pyQTA3Qq4v5ik18xQTOP1fZF1WkJvxKaCUFxV6g/qfZMufEqxAAY9RfVBWujS6u7o8B7JLN8B7IEh7JqcqsxIkcASOSZvOv1j7oLpVOXSV1/FJd3mPurUYBjaSATZBVCRXd1vlHsl3R4D2QDeqOSFTeTvHU8fFJvHzH3QXTaxVHvS7xuPqPurga23AeyCmE5nXbzVvdHgPZI9o3DoOCBxSKkXP8x90bzvMfdBbm7J3JUgpI3EyNBJOqtbo8o9kFG6kp+1Ctbo8B7Js7QIiQAED9Et1S3neYpN53ifdBZqOy+6rKSnN5LE3Fu9WbN8B7IKWgUtM5oebm2inLQRwC0f8Ye0abZ/stkiw6odT43jLzR0T43WdE236kg5N0B8XBB4+2L4rMoZLxevwHBKCozDidIHRvkhe1lKyYftL9S6x47o9LrUWUvjPzXBiZdmfLOFV1A99y2hc+GaNvoXFwdb1GviuVJC5rz9RcCbm69TEsvY1Q4LSYxVUEsdDVC8U3EHn4X7rqJtEd2daWtEzEdn0/wBl+1XJu0vBjWZZxVs00YBqKKUblRB/eZ4fxC49VmAcCvkZlrHcZy9jNPjGCYlVYdiFOd6Kop3lrm+3EehXe3wt/ELQ7QoostZqdBQ5qY20bmgMixADvYODZPFnfxHgJYN/aKam655KZpBbctA9LKOoNmC2huglJshU7u8x90XPmPugnquy+6rKanO9IQ430U+62/VHsgpX9VPSWu5T7rfAKCq+kN3dL+CCxqkVIOd5j7o33eY+6Car/aoFYpvq3r681MA0/tHsgokqxR2s7mpt1vgFBVfSW7unJBOUDgqW8fMfdG87xKCWq67eShVim1YS7XXvU26PAIKHsrVN2X3Um63wHsq1QSJbNNhbuQWkclR3nd7j7oufMfdBJUdsVHorcDQYgSAT6p263yj2QUlbg7JqdYeA9lWlJbI4AkD0QWkqo3J/cfdKSfE+6AdbfPNIrjGjcGg4ILR4BBS1VyHsm8ktm+UeyqSE75AJGqC6hULnzH3RvO8x90Ek3alMurUQBYL2KdYeAQUlZpeoeaksPKPZQ1P0lttOSCcoCp3J/cfdF3eY+6CWr4tUHFT02rXb2uvept0eA9kFEqzSH6DzUoaPAKvVfS8W007kFn7pVQDj5j7pS4+Y+6B9T2p5KLircIvE0kAn1T90eA9kFJvEK9ZJujvaPZVC43P1Hj4oLhQeqeSp7x8T7oaSXjU8fFA0Jbq7ut8B7JLDwCCtDbpW81bUctuicbAFVQ4+Y+6C6mT9k7uVUuPmPunQkmVoJJHqgZyKFd3R4D2RujuaPZBWpu2CtcFHMAIyRofRV953mKC4mVHYuVbed5j7pYTeUAkkeqCMJdFd3R4D2Rujyj2QVoO1arajlAETiABoqu8fE+6C7dMn7J3JVS4+Y+6dCSZWgm4QNCLq5YeUJd1vgPZBVgv0rVbUcotG4gAGyq3PmPuguqOp7IqtvO8x90+AkygEkj1QRouru63yj2S7o8AgrUx/V+xVm6jnFoyQLa9yr7zvEoLihq+zGveoN93mPupKY70h3jfTvQQg+qX7q7ut8B7Jd1vg32QQUnWdyU6hqvpDd3TXuUAc7xPugvXVer4tUO87zFTUv1b19eaCDilFlds3yhG6PKPZBFS9Q81Mq9Tdrhu6adyh3j5j7oL11Vqu0HJRhx8x91Yp7OjuQDqgqpdPFXd1vlHsjdb4BA2n7EW9U9VZyWykNJA00CZvOH7j7oLqqT9q5ML3eY+6tQWMTS4XPiUFVAsr263wHsk3W+UeyBIeybyTgqkziJXAEgA9ybvu8x90F5U6jtnc03fd5irUQBiaSATZBTQr4a3yj2Rut8B7IGwn9JvJOVOVzhK4AkC/ik3neY+6C8qU3auv4pN53e4+6txgFjSQCbIKYQVds3yj2RujyhAR9RvIJVTkcRI4bxGqTed5j7oLwVGTtHc0Fzj3n3VtrW7ouBwQUtEqvbrfAeyTdb5R7IFHBA4qiXO3iN4j7o3neJ90F9UDxPNG86/E+6uhrbcB7IKKLq/ut8AfskLW+UeyBW9UckFUnOdvH6jx8Ub7j+4oLwVKW3SO5pN93ifdXGgFoNhw8EFFCvbrT3D2Rut8B7ICPs28gl+ypvcQ9wBNr+KTfd5j7oLyoydq7mUbzvMfdW2AbgJAOnggpIV7db5R7I3W+UeyBRwRqqJe/eP1Hj4o33eY+6C87qnkqCUOJcPqJ1Heru63yj2QUU6HtW81c3R5R7JsrWiJxAsbIHoVHed5j7o3neY+6C1VdieYVRS0x3pbONxbvVktb4D2QUVPSdd3JT7o8o9lFVWawEaG/cgmRxVG7vMfdF3eY+6Car4t5FQfdWKX6g7e1171Nut8o9kFJWaXszzUhDfKPZV6olsgDTYW7kFlKqG86/WPujed5j7oL55IRqgIKtR2pUalqLdKVFxQCtw9m3kqqtQ9k3kgeUiVJ9kFOQ/W7mm3KWTru5pLIAcQryojiFftogT7pJezdySpsvZu5IKl0h9EBLZA6n7UK2qsA/VCtahAvcoqns/upLqOp7P7oKut0v2QhBLS9oeSs2Val7Q8lZQFioKvqt5qbUqGr6reaCDUISIugsUvWdyCnVek6zuQVgIEUc51apVDUabqBqEgI8Qi48UDJBqksnP63FJZAllYp+z+6g1U9P1PugkuUI4oQVJ+1cmKSo7ZyiQKrkXZN5KkrsQ/SbyQP0CEWKNboKL+ueaRK/tHcymoFHEK93KiOIV4IFTXn6HckqR4+g6dyCmkslAQgdEP1G81cVKPtG81cKBdVHPboin6pk/ZFBUQUJUElOP1RyVmxVan7X7Kze3FBBUyNiifLJI2OONpc9zjYNA1JK+ZXxO7THbTdqVdiNPUPfg1Felwth0HRNOr7eL3Xdy3R3Lt/wCKzO2H5K2N442rqXRV+MU0lBh0bOu+R7SCfRrRck/5r5mTNbe7EGabH8oDNuamQVIP9n0o6WqPiL6N+5XUVVhVBPhxw6WkhloyzozC5t2btrWstebAcEOEZJbVOIM+ISdM/TVrRo1v9futlRyOHFUWsyzfLMeT3XB9HGHTRbxt1n/DnTa7ssny+X4zgEUs+Fm5li4upvX1b69y1jR1dRRVMVVTTSQ1MLxJFLG4tcxwNwQRwIXbczo5oXwzRtfG9pa9rhcEHQgrmDbFkCXKuJOrsPje/CKh36buJhJ/Y7+hXXo9Xz+pfuqOMcJ9F/Gwx08Y8v8Ap3L8Lm2LC9o+R8PpMSxeGTN1JBuYhTO+iSTdJAlaODgWgE24EnQLclQ4GMW8V8hssY7iuW8dosawWrko8RopRLBPGdWuH8weBB0IX0+2H5/otpWzTDMyxPhZWvb0eIU8b79BO24c23EA2uL9xCsnnGaJRdBskuEE1L2h5Kwq9Kf1DyVkoEUFX+37qdQVfBqCBFvVJZLfwQT0g0crGtlXpL/UrF0CKCrtdvJTqvWcW8kEJQAgIugsUnUPNTKKl7M81LcoFCqVI/WPJWlVqe1+yCK3qlCEWQW4D+k1ScVHB2LU+6AVSftXc1buqs3auQMAKOaXRIguM6g5JxTWX3ByS3QCpSdd3NXVSf1zzQNQEtggoLkPZhPUcHZhPQKq9Vxap+9QVXFqCA3QlRZBPS9U81OoKXqu5qZApVWr645KyFWq+uOSCDVAKW90FBcp+xbyUvcoqfsW8k9Aqou4nmruqpHidUDdU5nXHMIsEresOYQXUIKTUoGVHYuVPVXJx+k5VEDSVLT9q1R6KSDtmoLdkvBIUC6BlR2LlTVuo7FyqIC6fT9s1MUlOP1WoLiOCRFygbP2LuSpXVye/RO5KoECJ8HbNTU+DtmoLiRGqLeiBk1+idyVRXJuydyVQhAikph+qFHdSU5/VCC2kJRdL9kEVR2R5qrdW6nsjzVRAKWlH6h5KJTUvaHkgsISgo4oIKvqt5qurFX1W81XKAU9J+5QKxScHIJkqTvSoK1V1xyUKmq+s3koEChWqbsvuqt1Zpey+6CYJL6pUlkFSp7c/ZMUlT2xUSAVymH6LVUCtU3YtQS96DZILoQU5+2fzTeKdP2zuaYgUq5D2LeSpq5D2LeSByVHFBQUZu2fzTNbp8w/WdzTUAr0XZt5BUVdj7JvIIHlIlQgpS9o7mmJ0vau5pECW9Veb1RyVG6vs6o5IDglCOKEHnnrHmgaoPWPNCBRxV4BUAdVfHBABKkQgouP1nmkQ7ru5oAQCvM6g5KiVeZ1G8kChKUd6EFF/aO5lNunSdo7mU1AfZXo+o3kqCvsvuN5BA5CRKEHnnrHmkSnieaBwQKzrjmFfXnt645hX7aoFKjm7J3JP1TZuyfp3IKPFLZAQglpb9KORVsKpS9qORVqyBeCgrOzbzU6grOzbzQVr6JEqEFij4O5qwq9HwcrCAVWr7QclaVWr7QckERSFFkqCYk+JSX9SlPohA+PVuovqnWHgPZNi6v3T7oGkDwCRo0CUoF90IE+5SFLqg8EEjQN0aDggAeA9kNH0jknWQIQLHQcFSufE+6ungeSpIC/qUsZPSN1J1Tb+idF2je7VBcsPAJQPQJPulugjn7J1gqtz4n3VqfsnKpZAutuJ91JTm8uuuijUlN2n2QWbC3AeyAB4D2RdCCGq0YCNNe5Vw53C591Yq+zHNVwgW58SpaXV7r66KJTUmj3ckE+6PAIt6BF0WKCGp03baKG7vE+6mqho1QhAtz4n3TmdU315pqc3gUDShKeCRBNTgFpuBxUtvQKOnP0nmpEBp4BVarSXS407lbVWq7X7IIrkDifdFz4n3RokQXILGJpNin2HgEyDsW3TwEBYeA9lUlJ6V3Eaq4VSl7V3NAl3eY+6CXW4n3ScEd3FBdYPoHDh4JQB4BDOqOSEAQ2x0CpXPifdXe43VFAAnxPunMJLhqeKaL96czrt5oLlh4fhAAPci/qlQMlFmONhwVQE+J91bl7N3JVDwQLr4n3T4e1FySo7KSDtWoLNvQeyLDwCWyQoGzWEd/VQlpNrE3PqnVRIi08VrX4g9okGzbZdiWPuLXV8o+Uw6Im2/O8EA8mi7jyQcUfGFtEOeNr1bR007pMIwMuoaNt9C5p/VfzLhbk0LVuTcHlxvH4aRt+gad+Z3lYOPvwXl1DzUSPmke58j3Fz3uNy4nUk+pW4dkOBigy+6vmFpK4hwBGoYOHvxU1jeUTOza2SJmCKSkDQ1rACwDgBwWT7gAWkM6Z7lyg9tPhkcb66ePrP1EYvxt3lepsd2m1uZK0YFi8W/W7rntqW2AcB3EKo12lvz2yR2ev4LxLFGKmnvPrf99G2iGqpitDR4ph8+H10DZ6edha9jhoQrIY7vQGKsidur0kxExtLknaZk+qyfmF9G4OfSS3fSzW67PDmOBXt7BtqeN7Ks5R4xhu/U0M1o8RoS6zKmK/4eOLXd3DgSt9bRcrUua8tTYdMGtnaN+mlI1jf3fY8CuTMaw2uwbFJsNroXQ1MLt17T/MeivdJqPS12nvDwnFuH/dcnNX2Z7fs+s+Q814LnLKtBmbAqr5nD66PfjJFnMPBzHDuc03BHiFkFhbgPZcA/AvtPqMr58bkbEKjfwfHn/pB7wG01UGktcL8A8DdI7zurvqJzi36tF2KgyqFmAjTXuVe58T7qzVH9MW8VWCAufE+6npdS6+qhKmpOLkE+ngEWHgEIQQ1Vxu205KAk+J91PVHqqBAXPifdT0urXX11UBU9J1Xc0EwA8B7JLDwCW3ggIK9TcPFtNFDd3ifdTVXXHJQ3QLc24n3VmnAMQvqqqtU/YhBKGjwCCB4BJdFkFWYkSusbJtz4/lOn7VyZZAov4lWorGNuncqgVuLs28kD7DwCSwvwCCgBBTcSHOsTx8U0E+J90r+u7mkAQPadeJVuwtwCpt4q53ICw8B7It6BASlBUmJEhsdFHc+J90+ftSozdA7e9T7qelF2uvrr3qsrNJ1Hc0E1vQIFvAeyOaVBXqtHC2mncob+pU1X1hyUFkC3PifdT0urDfXXvVZWqS24eaCW3oPZGngPZL90HUIKcxtK6xITN4nvPunT9s5MQOBNx9R91dsPAKi3iFfCBLegTXj6HaDgnlNf1HckFME+J90tz4n3Te5IglhJMrQSSFZsPAeyqwdq26tiyBLDwHsmVGkRIFlLoo6jsigqA+p90XPifdIg6oJac3lF9QrVh4BVKbtQrdkB9h7JlRYQuPA+ik7lFUdi5BUDjfifdLc+J900JwCB8JPStBJKt2HgPZVILdK3mraAsPAJk9hC42snplR2LkFPePifdODneJ901KgkgJ6Ua3VoAeA9lUp7dK1XECaeA9lHUaREiwUgUdT2JQVST4n3QHG3E+6RCCSnJMo1J0PFW7egVSm7YcirenggLA934UVVowW01UveoqvqDmgrXd4n3S7zvE+6ahBPTaudfXTvU9h4BQUh+p3JWAgLAdw9lBU6Fu7orBCr1ehagh3j4n3SXPifdHei6CxS9V19dVNb0Chpeq7mpkBb0HsqtVpLppp3K0qtV2v2QR3PifdF3eJ90iUILVOLxAka+qk08B7JlP2IT9UBYeAVSe/SusbBW9VUnt0zkDLuH7j7o3j4n3SeyEF2KxibcDgnADwHsmw6xN5J6BLegVOYkTOFyBdXTxVKe3TO5oG3PifdFz4n3SIQXIgDE3kn2HgE2Lsm8k+wsgTTwHsqcxIkcATxV3gqU3au5oGgu8T7pN4+J90XQgusA3G6dwS2HgPZDOo3kl4oCw8B7Ki4neOp4+KvKk7rHmgTePifdF3eJ90iXRBdFrDQeyUD0CBwRYhAEDwHsqBLrn6j7q+SqHfogN53mPujed4n3Rr3pLIPQAFhoOCLDvA9kDqjklF0CWHgPZUpC7fd9R4q8qMnXdzQJc+Y+6LnxPuk0QgvMtuN0HBOsPAeyazqN5JSgNPAKlISJHam1z3q8qUnaO5oG7x8T7oufEpNEIL4A8Aiw8AjuSoGvA3ToOHgqO87zH3V5/VPIqjZABzu8n3T4jeVtyeKZwT4e1ZzQXAB4BFvQeyClQRVGkRI017lVufEq1Vdieaqa9yBS4+Y+6mpNXOvrp3qDXvU9H13ckFizfAeyLDwCEv3QVqvRzbaadyhu7zH3U1Z1m8iq6Bd4+Y+6tUmsZvrqqqtUhtEdO9BLYeARp4D2Qlugr3HiEG3iFChBOw2B5p17opuyHMqT7IIrpzSNwcFIqc/au5oJ7jxCQkHvCrDkgj0QXWn6Qlukb1RyTrIEuLHXuVLv4FXXdUoB0QUrHwKdH2jdDxVsJJOzdyQKbeP5QCFRQgtz9kVV+xT4B+sFbQUSOalpu018FZ0UVT2f3QSaeIRp4qkUaoJ6vsxzVe/opabWQ8lYQU+PAFTUo+p1/BTF7Wi5K1Jt228ZP2XxGiqpDiuPOZvR4ZTOG8240dK7hG3nqe4INtve1oLnEAAXJvoAqEGOYNO3ehxbD5W3tdlUwi/uvmztY+ILaLn9klJV4p/ZeFuuPkMOJiY4eD3X3n/gei1KyeRhuy7f7pI/kg+xNS5pawg3B4eqiC+auxvbznrZ/i1O5uMVeJ4QXsFTh9ZIZmGMHXcLjdjrXtY29F9I8v4vQY7gdFjWGVDKihroGz08jeDmOFwgnStOpTyQnQjUoI+KSytgX7kvBBDBo081KD4kKCq67eSg9EF428QqtV2vjoozzVml7L7oKv2Pslt6FXtUIGQW6Fqff1CqVHbOTEF648Qqcvau0701XIuybyQU9fAoINuBV7VFzeyBGdQajgl08VSefrdzKS6C8eBVHXwKG9Yc1fQULHwPsnM0e3mruoSO6p5IAkeiLjxVIFKgtSEdG7kqgB9U9nXbzVtBSA9E+HtQSFaN1HP2TkD7+oR9wqaUFqCWqF2Bo1JK+cnxn5+r81bYK7BulH9k4A80dJE1+8wusDJIbabxOnIBdUfGNtPdkLZmcOwqsbT49jhNPTFp/Uiht+rKPA2+kHxcvnTO97nuLjvEm5JNyUHsZKwWTHsxU9K1hMDXB857gwcffgt+NgLGBkYDGNFmtHAAcAsT2X4THh2W4KkQOjqKob8pdxIvp9lmTHG2q21jaGFp3aU2xMcM36uB/QYLX4L2Phyo5Z9oTaltuipoHukN/HQflY5tQmM2dq8n9rg0fYBZV8NVO6TO9TMHENjo3XHjchcern+FZY8Lrvqsce+HShe22ibvBQgG6dcrzr6HscbFa2225AbmTCji2HRhuKUjCdP8AbRjUg+o7lsgJ4J4FZ48k47RarRqdPTUY5x37S4fje+CYbpLZGu0dexaR/Irvf4MttVZnjDZMm5ml6XHMLphJBVOfd1ZCDY738bdLnvBv4rmHbfs1/sYz5lwe5oZZbzwW7Au7x/Df2Wt8sY5iWWsco8dwaslpMRo5RLBNGbFrh4+IPAjvBK9Diy1y15qvn2q0uTTZJpeH12mJdCDbvUNvRY1sfzjT57yFg2aqdm4K+mDpWWtuSj6ZG8g4FZnxW1zKJ496npP3KewUNXwagmulJHoqHDvRdBYqtd1QWPqpqTg5ToKQup6XQO5qaygq+LeSCx90XHiFRQgkqtXi3h3KKx8CrNL1DzUqCjY+qtU/ZBSfdVKi/SlBbvy90XHoqQSgBA6c/quTVai0jbp3J10FK3ofZWoT+m3XuT73VOXtHc0Fwad4RceIVFFroFfo51weKOPcVcaPoHJLZBS17gVcBFhqlVOXtHc0FsEeIS3HoqQCO9A+cHpCVHr4FW4RoU9BRsfAqxS2DXA6aqZQVf7UE2niPdLcKiEBBNVnUKDj3FWabqnmphdBQsfAqxS6NdfxU+qhqv2oJrgd4SX5e6p/dCB0/au0TAPRXIeybyT7WQUQNRxV0c0G9lRugu3SPI3HcOCqdyVg+tvNA3u70oHp+FeRqEFSEHpWlWtPEJk5vC5VOCC9f1t91HUdkVUOqfT9s1A0cktleSIKtOLSgnRWdO4hNn7Iqogu39R7plQR0J8VUPNSU/bNQRjkUuvgVfQgpQ9q0+qt3Homz9i7kqYQXwR4hMn7JyqXT4O2bxQMsfVFj4FXkvJBTg7Vqt3TKjsXclSCD0dPRRVNuiKqqSmP6oQRWPglt6FXkIKtPpKOStAjxCjqeyPNVe5BfuPFQVfZjn3KvfxKmpe0PJBBZHv7K+UfhBXpOs7krFx4qGr4N5qC/igu3HiFDV67qg5Kel/d9kFdFvQq9qhBDS9Q301U2nj+VXq+uOSgugvg+oVap7XTXRQ2Vql7L7oKtj4H2QL/APyCvoQR09uiCkvY8R7qnUn9c/ZMQXr+oVSo7V2iZ91cp+xbyQU7eIQAR3K/bRH2QNht0TeHBOv6hUp+2fr3poKD0LjxCpT9s42PFNVyDsW8kFLj3FLY+qvEIQNi7JvdonXt3qnKbSu5pt/VBeuPEKpN2juajPjdXo+zbyCClbn7It6K8i6BGdRuo4JfuqL+u7mi6C9ceIVJ1946d6arzeqOSClr4FJY+BV/XklQIOAS39QqHeUILxI8QqBGvApVeHBBQPIosr6AgARYa9yCQe9UT1jzQCgvXHiFSffpHceKQ81eb1ByQULHwKLEL0AkugRlujbr3BKCP/kVRk7R3MpPugvkj0VOS++7mmfdXo+zbyCCl9ik1XoHijvQJp4o08QqB4lA1QXndU6jgqVvRDB9Q5hXigo6+BTou1bzVwJk3ZO5IHkjxCAeXuvPS/dBbqSOiPfqqtj6p9KP1hyKtoKNuampNHuv4Kx91FVn9Mc0EuniEX5e6o3SHignq9XNt6qCxVij6ruasIPP4dxVqkv0Z5qa6q1faDkgs3H/AMilv6hef3ot6lA4IT+jf5Sjo3eUoJqbshzUoUMRaxm642N+9P6RnmCB5VSbtHc1Y6RnmChe1znFzRcHgUESQqURP8PyjoneCCw0/SOScow9gABcAQl6SPzhAruqUvgmOljsRvhO3h4hApSSdm7kluD3hNkN2EAi5CCohOEb/K5LuP8AKfZAsHajVWVXiaWvDnCw8Spt9nmHugco6k/pfdO32eZvuo53B7N1h3jfgEFdKjcf5Cl3H+Q+yCWl7Q8lM8aXGqipxuOLnfSLd6xrapnXCtn2ScRzZi8zRDSxnoYd6zqiU6Mjb6k+wueAQa3+KXbbQ7Mcsz4dhNbBLm+rjAo6W2+adruM7xwAAvug8TbiAV86MUxCtxSvnxCvqZqqtqJDJPPK8ufI46kkniV6Gb8cxLNGYq/MGMVUlTiFdM6aaV5vcnuHgALADuAAWVbINnU2ba01+IMliweA2e8Gxmf5B/UrDJkrjrzWb9Pp8moyRjxx1l42Q8j47m+pDaCn6OmBs+ql0jb/AJn0C2DV7LMIpIZqKR8/zjW2Exfpvdxt4LdGHUdPh1HFR0cDKeCJu6yNgsGhY/njcjlppCbSyXaBbrALh02tnLm5JjpK81/BK6bS+ki29o7+Tlivp5aCumpJ27ssLyxw9Qur/gt25Nw6Gl2b5pdEygaSMMrSbGJznX6N/wDCSdD3cCtA7YcOMeJ0+JsgsyZm5I8Di4cL/ZYXhtbJQ1kdTFo5hvzVjPR5x9g902T4RxWkPhG2muz7kF1DiFR02K4RuRucT9ckJH0PProQeS3bFILne0HrognvZF0zfZ3OHujfZ52+6CGr6zeShupqi73DcG8ANbKMRv8AIfZA1WqXsvuoNx/kPspoXBjN15DTfgUE1whR9Izzt90vSR+ce6CtUds5RG6mla58hc0Eg94Tejf5HII1eh7JvJVejf5Xeysxua1jWlwBA1BKCRCZ0jB+9vujpWedvugpydd3NNspXMeXEhpsSk6N/ld7IGC9xzV9U+jeCDulWukZ5x7oH3TX9Q8k0SM8wSuewtIDhcjxQVLIT+jf5Sl6N3lKBI+u3mrarNY8OBINgVPvN8QgcFHPrEU7eaO9Mle0xkX1QQbt1FWPhpaSarqZmQU8LDJLI82axoFySfABTA2XLXx27VocIy3/ANm2EVG9iOJNbJihYewp73EZ9XniPKPVBzb8UGfqPaRtXrccwmSodhUMTKWi6bQljAbuDe4Eknx4LHNnGWX4ziDK2pDfkKeT9QE6vcNQ2yxqkp6jEK2Oko43STyus1o7yt25MwM4DgkdG54fM5xklcOBcfDksqxuiZ2ZE0sa0NaAABYADglMgChaDZOawlwWxraI2hvD86Yg5puOk/otifDE3/13ib7f/Q4H/MFrTOgc3NeJB2p6dy2R8MUw/wBI8RgtqaXevf8AiC4dZ/KstuE/1eP4ugeKUNKXQcEtwvPPoJAE4ckiVEIcRpKbEMPnoayMSQTxmORh7wQuQdoGWqjKeZ6nCqhpdGDv07+6SM8CuwnBYFtnyWc2Zd6Sjia7FKP6qc3tvj9zPv3eq69Hn9Ffae0qjjGh+84eavtV/wB2Yl8M3xAV+y1jsCxKhOJZdqakSvYJCJaS+j3RDgb6EtNrkHvK+hWXcYw7HsEo8awmriq8OrYmzU88ZuHtI0K+Qc0c1JUyQVMZjljcWvY4WLSO5dk/AhtbonYY3ZbjLmU1RG+SfCZ3P0mDiXPh14OFyRbiL+CvnhpjadnYdwoKzg3mnskjt12+6ZUfqBvR/VbjZEK90qcI3+U+yXcf5D7IJaXg5T9ygg+i+/8ATfhdSGRnnHugf3KtWWu3kpg9nnHuop/rILPqtxsggQnGN/ld7Jdx5/YfZBNS9Q81Lb0UMBDGkP8ApN+9S9Izzj3QO5qrP2pVgyM8wVeUFzy5oJHiEDBoi6UMf5D7Jdx3lPsgnhP6beSeVHG5oaGlwBHEFP3236490ChU5e0dzVvfYf3BVZWP3yQ02v4II+CW6Xcf5D7Jejf5HeyC2zqDknXUbHs3QC4cPFO32eYe6Bb+ipydd3NW95vmCrPa4vJDTa/ggjSgpdyTyH2RZwNiCOaC3H1U6yY1zQ3VwS77fMEDjyVeq/apt9nmCin+uxZ9VuNkFdCeGP8AKUFjvKfZBNS9Q81LxUMH0NIf9N/FSb7POPdA9QVX7VJ0jO9wUU56S259VvBBAQlCduP8h9kdG/ylBZi7NvJPUbCGsAc4AgcCnbzPMPdAp4FUVcL2WtvC/NVgx/kPsgYE5naN5pdx/lPshrHBwJaQAUFzvQmdJHfrt90b7POECVHYuVQhWpXNdGWhwJPcFX6N/kd7IGp9MP1gk3H26p9k+EFjw5wIHiUFlKEzpGedvul32W67fdA2p7FyqK1KWujLWkEnuBVbo5PIfZA0KSDtmppY/wArvZPiaWSBzgQB3lBaRdN6SPzj3S77PM33QNn7J3JU1blc10bmtcCSOAKrdHJ5HeyBqkp+2am9HJ5D7J0TXNkDnNIA4koLiRN6SPzt90dIzzt90CT6wu5Kmrcjmujc1pBJ7gq/Rv8AI5AxSU1+lHJJ0b/K72T4QWSBzgQPEoLQQmdIzzt90dIzzj3QNqeyPNVDfirMzg9m60hxvwCg6N/kd7IGKek7Q8kzo3+R3spIAWOJeN0W70FkIKZ0jO57fdHSM8zfdBFV8G81X1VioIkDQw71jrZRhj/KfZBGrNJwcoujf5Xeylg+i+/9N+F0E4QmF7PM33R0jPO33QQVfaDkoLaqxP8AqOBZrYdyj6OTyO9kEfBXKU/pfdVzG/yn2U0JDGbrzum/AoJ79yRN32ece6OkZ52+6CtUdsfsoyFLM1zpS5oLh4hN6N/lPsgYrlP2LeSrdG/yH2U8TmtjDXEAjiCgmugpnSM8490dIzzj3QVZ+2fzUamlY90jnNBIJ0ITejf5T7IGd6uQdk3kq3Rv8jlYje1sbWucAQNQSgl7kJnSM8w90dKzve33QVZu1dzTLd6kkY90jnNaSCdDZJuP8h9kDFej7NvIKoY3+U+ysscwNALgCBY3QSXQo99nmHulEjPM33QU39d3Mpqkcx5cSGm1/BHRv8rvZBH3L0G9UclSMb7dV3srQewADfAPNBJdHeo+kZ52+6XpGedvugpnibJE/o33vuH2R0b/ACO9kDR3K8FT3H97HeytCRluu33QP5ITOkZ52+6OkZ52+6Cm4/UeaRPMb94ndcdfBHRv8rvZAxX29UclS6OTyH2VsPaABvC4CByEgkZ5m+6DIzzt90FOTtHcymp72PL3EMJBPFN6N/kPsgS6vR9m3kFT6J/kd7K0x7AxoL2ggWIugeNUvemdJH5h7o6SPzj3QUncSksnmN9z9DvZBjf5HeyBGdccwr6pNY8EEsda/grXSM87fdA/mmTdk7kjpGedvumyOaY3NDgSRoAgqI4Jwjf5HeyXo3+V3sgdS9qORVsKrCCyTeeN0W4lT9Izzt90DyoKvs281J0jPO33UdQRI0Bn1EHWyCshP6N9uq72R0b/ACn2QTUnVdzU/cq9Odxrg/6b8LqXpGedvugeqtX2g5KfpI/O33UFQDI8Fg3ha1wghQndG+/Ud7I6OTyH2QXUJSfRAQVqjtSo7p8/alRlAqtQ9k3kqitw9m3kgfZJqluhBSk0e7mkJHglk67uabZADiFesFSbxCuoCw8EjhpwThqkdwQHBCEIGT9kVVVmc/pOVUIBS03a/ZRqSm7X7ILOiQpSkcQOPegrVsgZGC5wa0O1JOgHivmD8QW0bGdou0TFa6uq5P7Ppql8GH0jZCYoomEtaQOG8RqXd9/Cy6e+PzaTUZfy3Q5EwWvjZVYw10mJBh/VjphYNb6B53vUhpHeuG4IJKqojpqSJ0k0rg1jG6lxPciYjeWT7OcnYhnHGW0lO0x0sZDqmoI0jb/U+AXVuC4ZR4Ng9NheHxCOnp2BrAOJ8SfUrwNnWDNy7lHD8N6COKdsLXVG6OtIdST4rJmvPeqHVaicttvCHvOF8OjSY4tPtT3/AGVMXqHUGG1VeYnSinhdKWDi7dF7LlTH8+ZkxnFPnZ8QmYGSl8ETT9MV+4LriTo5YXxSNDmPaWuaeBBFiFyjteyo3KuapYKcEUVR+pTXPd3j7Ldw6axaYnu4vtDXLOKton1fFlWC18edso1NLWtYypYdxxA03rXa4LVWKUNRh2Iy0VUzdlidY+B9Vk2yrETS486hkNo6xu6L9zxqP6rJNrGXxLhbcYiYengIZIR3sPjyV13jd43tLIvgtzlDlbbFT0tVUOipMWj+SkbpuuJN2k8j/Mr6LSt3WNHqvj5RySUs8dRC8xzRuD2PadWuBuCF9QtgGeYtoWybBcwOlY6ubH8vXMaepOzR1x3X0P3WLJnlrISXS3QWKXqu5qVQ0vVdzUxQCq1fa/ZWlVq+1+yCJLZIlQW6fsWqRRwdk1PKBVSl7V3NXLqnL2ruaBqQjRLwQeCC6zqDknJGdUckIA23ToqSu20Kp2QIlYPrbzQErOu3mguJCUuqT7IEf1CogpJOoUwaIFUc3UUgVTFq6jw/Dqiur6iOlpaaMyzTSGzY2NFy4/ZBg23PaZhOy7IlRj1eWy1kodDh1KeNRPbQf3RxcfBfMjNGO4nmLH67HcWqnVVfXzOnqJT+5x/kO4DuACz/AOJPanV7UNoE2IsJbgdFvU+FQ7tt2K+sh/ieRc+lgsDyngdTj2LNpYBaJtnTP8rb6oMy2OYBK+aXHZmlsYaYoAR1iesfstnCK3FR4fDBR0kVLTMDIomhrGjuAVjitsRs1zO5AAE7QJpumm6lDQu0RpZnPEh4y3/AWS/DzWGn2kQRXNqiCSM+1/6Lz9sFC6nzOKoAbtTGHfcaFN2MFzNpeDFgJJmsbHusbrk1Eb47R7nfw+3Lqcc++HWDRfuTgE4WsgWXm30fcAJwCRKiCEBMcnkpCLoOdviLyj/Z2MszNSR2pa127UBo0ZLbj/iH5utXYRiFZhuJ02I0FVJS1VLK2WCVhs5j2m4I5FdmY/g1Bj2D1GFYlCJaadm64d4PcR4EHVcnbRcn1+TsddQVX6kD7vppwNJWX/BHeFc6HURevJbvDx3G+HziyTmpHqz390/9vov8PG02j2pbPafGW9HHitNanxSnb/s5gOsB5XDUey2fSDrL5j/DPtPm2YbR6fEZN52DVtqXFIgdDETpJzYTvcrjvX00w+eOaMSxPbJHI1rmObwc0i4I+ysFAuIsUl0XN0ENVwaq6sVX7VAgQlT0nB3NQEKxR9V3NBMi3qlQUFep6w5KK1lNU8W8lBdAuisU/ZhVSrVP2QQSWRqlA0QeKCpL2ruaYnzdq7mo0EkfXbzVoqpH1xr3q5ZAlkHqnkl5pHH6TyQUuCUFJxQgnpxxU1ioqbgVNdAlrKvUC8hVlV6jr/ZAxISnWKa4HvQJxU1MPpdzUNtFPS9V3NBLZACUI4oIKrg1QXsp6rg1V7IFKmpB1lBZWKX9yCayAlFkFBVnP6pTN5Pn7UqNAoP1jmrips6w071dQJ902W/Ru5J+lkyTsnckFMcEXSJe9BJB2zVbVSDtWq2ECAKOo7EqYKGp7EoKuiW6alQSU/ahWrqtTdqOStIEsmVHZFSKOo7FyCoj7ISIJIe2bzVsqpB2zVbQCZUdi7kn2TKjsXckFNKkQgkp+2CtlVYO1araAUVT2JUijqexKCpZKk4pbIJKbtRyKtBVqbtRyKtIE1uoqvsxzUyhquzHNBVS3SJUE1J1nclYVel6zuSsIBQVf7VOoKv9qCBCEILFIPpdzU9lBSdV3NTXQKqtT2n2Vniq1T2n2QRIQhBbp+xH3Two6YfohS/ZAKnUds5XCqc/bOQMQEiXvQXIuybyT/wmQ9k3knaoBU5+2dzV0KnN2ruaCNLZCRBdi7JvJOTYuzbyTrhAKnN2ruauKpN2ruaBiO5Il7kF1nVHJL3pGdUckp5IFVB3WPNXgqTuseaBuiAiwQgv+CWyTuRf1QBVDvV9UDqSgDoi6ElkHoDqjkgXQBoOSVAgVOTtHc1dVKTtHc0DUJEDigvM6jeQSpGX3G8gnIECoydo7mVf4qjJ2juZQNujvSckvNBf7kW9UDglQNd1TyKo3V5/VPIqj3IDinwgdK3mo1JB2reaC4BdCVFwgiqeyPMKordT2J5hVEAp6Pru5KurFH13ckFjVASovogrVnWbyKgU9Z1m8ioEArNJ2Z5qtZWaTszzQTJUI+6BnSs84SdJH5x7qqhBLIC95c0bw9E3cf5SpoOyCkCCr0b/AClTRva1ga5wBA1BUqpz9s7mgsdIzzt90vSR+cKojuQSOY8uJDTYlJ0b/KVZbbdHJKUFTo33H0lWekZ5h7p3ceSooLnSMv12+6QvaRYOBKqJ0faN5oLN3eB9ktz4H2T0IIZtWEWPsq9j4H2VuXqKEIIw0+BUkP0vu7QWT2pJep90Eu+zzBeFnjNGDZSyviGY8cqGwUFBCZZHEi7rcGN8XONgB3kheoTYcFx9/wCkUzVUhmXMlU7yyCUPxGps8fWQSyMEcbD6zrpw8EHMm1fOdfnzaBjGa68PBr6guhjc7eMMI0jj/wALQAs3+HPKD6rFX5mrae1NTtLaYvHWkPEjkO9apwPDavF8YpcLpGF81RIGN9L959F2Fl7D48IwWjwyANDKaJsd2i1yBqfuVwa/NyU5Y7yvuBaL02X0tu1f1ei6IXvdIWpwJKUNuqR7RE4eC1Z8RuDGsyjDijI7y0Uwu4D9rv8AzH5W2N2y8vN2HR4vljEcNe2/T07g3+8BcfkLbhv6PJFnNrcPp9PbH5w44oKh9NVRVLCQ+J4e0+oN10TA6mxbB2OkaH09XCCWnvBC5zqIzDNJEdHMcWkeoK3Ts4qTPk2hAfvGMOYfSx4L09JfNLxs1fnTBJcvYw+lN3Qv+qB9us3/ADCzH4eNq2J7Lc7QYi2aWXBap7Y8Uogfpkj84HnbxB5jvWVZsy/DmHC3Usv0zN+qCS2rXf5FaMqqeWjq5aepYWyRPLHNPcQomNkxO7674RWUuK4ZS4lh0zamjqomzQSs4PY4XB9lbLH+Q+y4y+CbbhT4a2DZrm2tMVLLJbBauV/0xucf+7uJ4Anqnhc28F2tG4O0AIt4qEo4CIw4PO7c6XT+lZ5x7qOrH1N5KGyC1vs87fdQzgvk3mDeFrXCiVml7L7oIOjf5Sjcf5CriXTuQRRPa2MNcQ0juKd0kfnb7qvUdq5R6oLnSR+ce6rSNe6RzmtJBOhTFch7JvJBV6N/lKOjfbqFXOaVBG2RgaAXAEBL0jD+8e6qvH1HmmoLhkZawcPdVyx/lKYDqFdCCpuP8pSta4OBLSACrVkj+o7kgOkZ52+6OkYf3D3VMcEoOqCzM4FuhuO9RF7R+4Iv+m7kohY8UD3StHBwXIvxzbZoGUEmzDLtYx80p/8AXcsZv0bRYtgv4k2LvAaLevxEZ6Zs82U4tj9PNBHiZZ8vhzZD1p36Agd5aLu+y+YVbVVFXVTT1cr5p5pHSSyPN3PcTcuJ8SUDGNfNKI2Avc42aAOJW9MiZcZgWBxsfGBVzAPnd337m/ZYVsjy62aU45WRksjdu0zXDQu73fZbWaT3lZ1jxY2k3dtwShPAujdWbABODR3pAEXKga723Ydv0VFiLWn9NxjcfAHULWWFYhU4XilLiFJIY56eUSMcPEFb5zhQx4pl2ro5X7oLC4OI6pGt1z6WDeIJvY2uFrvHm20tMTvDtjDqr5mhp6jT9WJr9OGoBVoFa8+H/HG41kSKke69Rhrugfc6lvFp9tPstiltl5nJSaWmsvpWnzRmxVyR4wBqnAJAlWtuFkhCUpCUDCsJ2x5YbmjKE8ccYdW0gM1Mba3A1b9ws3TmtHeAsqXmlotHg15sVc2Ocdu0uG/qa4sI3SDZwPcu6fgW2uDHMAOzzHakvxbDIi/DpZDcz0w/ZfzMv/wkeBXMG33JzMu5ibiVE21FiJc8NDdI397f6rDsjZmxXJuasOzLgtQ6HEKCYSxnucO9p8WuFwea9HiyRkrFofOtTgtp8s47d4fXRsrC3VzQeaN9nnb7rC9lub8Pz/kfDc14Sd2Ctj+uI8YZRo+M+oP4ssqAIWxoTTDftufVbjZM6N/lKfSnVynOoQVOjf5CpYD0YIf9NzpdT2UFZ1W80Ehkj87fdHSR+dvuqeiS6CxMd9w3PqsO5M3H+Up1L1jyU6Cr0b/KVNE5rI7OIafAqVV6kfqfZBMZGece6OkZ5wqgQEEj2uc8ua0kFJ0b/IVYi7NvJPKCq1jwQd0qYys8wT1TePrdzQWekZ5x7oL2uaQ0gm3AKqFNTD6iUDOjf5Sjcf5SraEEMVowQ82v4pxkZ5h7qOqP1DkoUFvpGW6wUMl3PuASFDqrMZtF9kDQW+IQ6x0bqfRMT4R9aBu4/wApUkP0NO9pc96mUVR1RzQKZGeYIEjPMFXKEEs3123DvH0UfRv8hT4O0+ysIKnRv8pT4f0779238VYUNT1BzQOEjPMEu+zzBVQl4oHygufvNBIPek6N3lKni7NvJPQVAx4cDumwKn6Rl+uPdOf1TyVJBb6Rnmb7pHvaWFocCSNFWsnR9dvNAgjfbqH2S9G/ylW9UFBWjBbIHOBAHepukZ52+6J+yN1UQW+kZ52+6bM4OjLWuDie4KspIO1CBoY/yn2S9G/yFWwhBWhaWPDnAgeqn6Rnnb7pKjsiqtkFsyM8490yZzXRlrSHHwCrKSnv0wQNEb/I72R0bx+0q4lCCpG1zZA5wIA4kqx0jL9dvuibsnclTKC50kfnb7psrmujLWuBJ4AKopIB+s1A0Rv8hS9G/wApVyyLoKsTXNkDnAgDvKsdIzzt90k5/ScqaC70jD+9vumTOa+MtaQT4BVVLTdqORQM6N/kd7Jdx/lPsrt7JOKCtAC2TeeC0W4lT9Izzt902pP6R5qr3ILnSM8491HMQ9oDCHG/cq6lpe0PJAzo3+U+yCyTyH2VxCCvB9DiXjdv4qbpI/O33UdV1W81XQXN9nnHuoqj67bn1W42UF1PSfuQR7jvK5JuP8p9lcQghgIY0h53TfvUnSM87fdQ1XWHJQoLvSR+ZvuoJwXv3mDeFu5Qgq1Tdl90Ffcf5CgRv8hVyyVBFE5rIw1xDT4FOEjPO33Veo7Y/ZR3sgudIzzt91Xla58jnNaSD3hR3Ctwdi1BV6N/kKNx/kPsrtiiyCON7Wsa1zgCBqCndIzzt91Vmt0z+abe3egumRnnb7qtI1zpC5rSQeBCiJ0V2DsWckFXo3+Qo6N/lKuEIAQMjewMDS4AgcCUvSM87fdVJe2dzSXQXekZ52+6rSNc6RxDSQToVHdXI+zbyQVejf5Sjo3+Qq4B4pQgjbIwNALwCPVL0jPO33VN/XdzKAgudIzzt91Wcx5cSGHimdyut6o5IKnRv8pSdG/ylXrIQM6SO3Xb7o6SPve33VLvPNCC70kfnHuqvRvv1Cmg6q8OCCn0b7dUpNx/lPsryEDBIywu9vujpI/O33VI9Y80qC50kfnb7qu9jy8kNNiVHxV5vVHJBT6N/lPsjo3+Q+yud6EDGvYGgFwBA8Uu+zzj3VR/aO5lJcoLnSM8zfdVnseXuIaSCUy+ius6g5IKnRv8p9khjf5T7K6EvegYJI/O33SdLH52+6pnihBcMjC0gOF7eKq7j/IfZDOu3mFe4oKXRv8AK5Kxrmva5zSADqVc4Jk3ZO5IDpI/O33Rvx+dvuqSEFqZwfGWtIcfAKDo3+Q+ydTdsORVpBUMb/IfZOgvG8l43QR3q0oKzs280D+kZ52+6BKzzt91TQgnqP1C3o/qA42UW5J5CpqPqu5qdBS6OTyn2U9OQxpDzum/ep1Vq+0HJBP0kfnb7o6SPzt91SR9kCoCk6KTylHRSeUoJqc/pDmpdFDEQxga8gEdyd0kfmCB6qTdq7mrPSx+cKvIxznlzWkg96CNKndHJ5Cl6KTylBZZ1BySpgkYAAXAEBL0sfmCB3cVRVwyMt1gq3RSeQoGCydH2reaXopPIUrI3te1xaQAdSgt96OCZ0jPMEvSM8wQJL1FEpHva5tmm58E0Md4FAl02U/Rx71JunwKiqGPLLAFB5mZsdwzLeXa/H8YqBT0FBA6eeQ9zWjgPEngB3khfLXatnCvz7tAxbNlcXtdXTkwwueXdBENGRg+AFvvddY/+kDzkaDJ+EZGpat0dTik/wA3WRNtrTx9QO7wDJYjx3CuNctYdHieYKHDJqjoGVMzY3Sbt9258FEztG8sq1m1oiG7Ph0ylTx4Q7M1TEXVcz3RwOe3qM7yOa3C1llWwWjpMIwqmwyijEcFNGI2Dl38+9XL3XnM2Scl5s+jaPTxpsNcceHf4m6BKHItdFlpdRd5G7vJLI3y1SOPNo1I+iz1jEDgRu1T7XFtCVmGxWva6CswyR2rCJox6HQpfiOoKemzu2qjeOkrIhI9luHddY5soqG0+bGROFzPG5jT4HivS6e/NSsvm+uxeiz3p75brDmt4LXW1bK76txxzD4t57W/6yxo1IH7gthMYe9StiadCAfFdMxu4ezmeJ264O1BGotoQvoN8Ge2M58yqMr4/Wh2ZMIjH1yO+qspxo2T1c3g77FcX7VssNwjE24hRQ7tFU6m3Bj+8el1j+UMyYvlTMdFmDA66SjxGikEkMjfyCO8EaEd4WrbZsiX1xqHhzm2Pco7rXGwXathO1fJ0WJ0hjp8VpmiPEqG/wBUEnmHix3EH7dy2SInltw0oG2Vim7LTxKi6KTylSwuEbN153Te9igl18EXTelj84R0kfmCCtUdq5MupZGOe8uY27TwKb0UnlKBnBXIuybyVbopPKVOyRjWBrnAECxQS2SJvSsP7wjpY/OEFR/WdzKTipDG8kkNJBOiTopPIUDB1gr/ADVQRSA33Cp+ljt1wgfokf1Hck3pI/MEOfGWkBwJIQVUW9FI2F/lKd0T/KgjOkbuSq1E0VNTyVNRMyGGJpfJJI6zWNAuST3ABXJWuaw3C5Q+OrapiGBYbBs8wR01PPidP8xiNQNL05uBE08fqIu4+GiDSPxZbVnbSc/OpsMqQ/LuDudDh5aTaZx68x/vEaei11kPK8uYcSEkwIoYHAzv8fBo9SsepIZq2qipaaJz5pHBjWgcSV0DlnDIsHwWmw9jW70bB0jmjrP7ypiN0TOy1T08dPEyGGNscTBZrWiwAU7U6yAAtjAosnck0BORA7khCUIsghmjbIx0bxdrgWkehXP2cMKdg2YKmisRGHb0f908F0M4LXO2XBzPQRYvC27oPolI8vcVFurKsq/w4Y0cMz2MOkl3YMSiMVjwMg1b/UfddNFcRYLiFThWLUmJ0ptNSytlYfUG67OwHFKbGcGo8VpXB0NVE2Rtu641H2NwqPiGPa8X83svs/qObFbFPh1+UrpRdJcIvdVz0JwSGyS6CUCFMc4px1SFqDH88YDTZoy9UYRWADpBeKS2sbxwcFydmDBq7L+Nz4XikZjnhP2cO4j0K7SDGnitDfE7l9kWIUGYod8idvQT6aAt6p+4XfoM01vyT2lQ8e0dcmL01Y9av6Nuf+j6z9hcVPi2z2rlkjr56g19FvO+iRoYA9jR3OFt71+y6/Dg4aL5IZUx/EMs5jw7HsImMNdh9Q2eF4NvqaeB9CLg+hX1WyFj1LmzJmEZmoQfl8TpI6hotbdLhq37G4V08a9+lbq7TuU4AUMR3Cd8bt+Cf0rPMED1DWcG80/pY/OEya0oHR/Vbigr3Qn9FJ5Cjo5OG4UD6XrnkrH4UELXRuJeN0WUvSR+cIHhVantPsp+kYP3hQzAyPuwbw8UESE4RSeUpejk8hQWIuzbyT1GxwawNcbEBL0jPMED1Ul7R3NWOkj8wUL2ue8uaLg96CMWU9PwKj6OTyqWFpYDvAhBKk1TTKzzWSdLH50EVT1xfwUYUsoMhDmfUE3opPL+UDFK02j+yZ0Unl/KUuAG6dCgapIeuFGDcqWNrrh27ognUNTwbzUvuoalzQBzQRo+yN5vmRvN8UD4e0+ysC6rxA728LkDwU4P8LkCqGp6g5qQu/hd7KKd1wAbjXvQQpW8Utmn9wSgNH7kFhmjBySm6Yxw3BqnghAjh9J5KkFdcQQR6Kt0UvlKBidH2jeaOikH7SnMY5rgS0gA6oLSE3pGdzgk32eYIEnP6RVS6tSFrmFrTcnuUHRP8pQMKkp+1CTopB+wp0TXMeHPBaPEoLST7JvSx+YI6RnmCBtT2JVVWpXB7C1pu7wUPRSeQoI1JT9qEgik7mlPiY5jw54sPFBZRqmdJH5gjpGecIEn7Jyqaq1K9rmFrSCTwVfo5O9hQMUlP2rUnRP8hT42PY8Oc0ho4lBaCDZM6SPzo6SPzBAk/YuVMK3I5r2FrTcngFB0UnlKCNS0vbDkUnRSH9hT4mOjkDniw8UFlCZvx+YI6RnmCBtR2R5qqrMrg9m6w3PgoTFJ5SgYpqXrnko+ik8pUkAMbiXjdFu9BYsjmm9KzzBG+zzBBHVn6W81Xup5yZAAz6iD3KLopPIUDeSnpP3KMRP8hUsH6YO/9N+F0E3FF00SM8wR0kfmCCCqP1jkolNO0yOBYN4AJnRSeUoGK1Tdl91B0cnkKmhc2Nm687p8CgmQo+lj84R0sfnCCvUdsVER6KeVrnvLmAuae9N6J9uoUEY5K5T9k3kq/RyeQqeN7WRhrnAOHcglSE3TOlZ5wgyR21eEFWbtn80zvUsjHvkc5rSWk6FJ0UnkKBnDuV2Hsm8lV6KThuFWGPY1ga5wBA1CCVJdM6VnnCOkj8wQVJe1dzSBSyRvc8ua0kHgkEUnkKBncrsXZt5Kr0UnlKna9jWhrnAECxCCVImdLH5wjpY/OEFN/XdzKFI6N5cSGmxN0nRyX6hQNV5vVHJU+ikOm4VZEjAAC4XCB6BxTelZ5gjpI/OEFLvPNKnGKS5+ko6KTylA0K8OCqdFJ5SrHSx26wQSJEzpY/MEvSs8wQUj1jzS8U7opCT9J4peikH7SgYrreqOSq9HJ5SrDZGBoBeAQEEmncEib0sfmCOkj84QVH233cykT3RvLyQ02JR0UnlKBius6g5KqY5PIVYEjA0AuAI4oJEg4pvSx+cI6WO/XCCmeKRP6OTylHRP8pQNYPrbzCvqm2N4IJYbAqz0sfmCBybL2TuSTpI/OEkj2OYWtcCSNAgqIT+ik8hS9FJ5CgWm7YcirSrQtMb9543W24qfpY/OEDlDV9m3mpOlj8wUc5ErQGfUQbmyCshP6KThuFHRSeQoJqTqu5qa6ggIjBEh3SeF1L0kfnCB33VaqH6g5KfpY/OFDMDI4OjG8ALIISkT+ikP7Cl6GXyILYSpEvBBVqO1Kj+ykqDeUqO6BFcg7FvJU1cg7JvJA5CO9KgpP67uabYpz+u7XvTboAcRzV/RURxHNXSgE2Xs3ck6ybJ2buSCoEX1QLI4oHw36UK2AqsHahWkAq9ZOynY6eZ4ZDG0ve4nRrQLkqdx+krRnxnZ8GUdi9dQQTNZiWP3w6nbvWcI3D9V45MuL9xcEHC+27ONRtA2mY1mqWZ7oqmoc2ka49nTt+mNoHd9IB5kr3fh2yyMUzBNjlXFv09AAI7jQynh7DVasLXghoOpOi632WZejy9krD6Pca2eSMTTkG+89wv/ACsFxa7LyY9o7yuuB6T0+o5rdq9f2ZM0KRqW1koAVE9wVCQJRxUoNI1TXNupbXSgWQ3c/wDxR0gjxXBqwN7SB8Zd42PD8rWGTKgU+asNlOgFQ0H76f1W7/ijoemyxhuINGtNUljjbucP/JaAwo7mL0bt7dtOw38PqCvtDbfDDwfGqcust79p/J0s/duQEy57kxhvqDcFSAaqxUylitJBiFFLR1cYlhkbZzT/APLitH54y1NlzEWt3nS0soLoZCPwfULfwaCdVRzDgdFj2EyUFY2wOsbwNY3dxCxtG6YnZqDY/n7F9nOeqHNGFuMhhdu1FMXlramE9aN3PuPcbFfTLZNtBy9tHyjT5iy/Ub0L/onp326Wml743juPgeBGoXyzzJg1bgGJyUNbHuuGrHgfTI3uIWQ7HtpeYtmWbYcdwCdzmkhlZRvceiqou9jh4+B4grWzfVvQi6rVQ/U+yxjZbn7AdoeUaTMmA1O/BMN2WFxHSU8tvqjeO5w/I1Cyao1kHJBHYpeaEILcPZNTk2Dsmp6BFTlH6ruauX1VOXSV3NA2xQUI7kF1nUHJLdDeqOSCCgDwVJXe4qlzQFilbo9vNCVnXbzQWykLk48VFLct0NkGGbZ8/Yds5yFiOZ8T3X9AzcpYL61E7uowffU+gK+X2dcyYxmzM1fmLGqs1NfXSulld+1tz1WjuaOAC6E+P3OxxbaDQ5MpqoupMGh6WpY0/SamQX19WssPS5XOWXsLlxjGoMPhF+kf9R8re8oNjbHcDjjwl+MVFO3p5pCIJHD6gwCxtzK2C1tkyjgipaWKmhaGxxMDGAeAUtx6rbDXPUqVIEo1QAHilAQOSVEABBSpEDHFU8aoYcTwqooJhdkzCPv3K64KM3Qc2VsElLVzU0jS18by0g91it6/DHjsk2HV+AVE7f0HCamY462PWA9OBWB7ZcKhpcQp8ThaWuqriUAaFw7+axPK2M1eA47S4tRv3ZaeQO/vDvB9CFx6nD6THNVlw7V/dc9cnh4/B2gL96cvPyzi1Pj+BUuLUl+iqGB1vKe8fYr0LHwXnZiYnaX0KtotEWjtJLi6VG6ghEhIUEpEA7VeBnnL8OZst1WEVGnSNvG+3UeOBWQAghODmjiFNbTWYmGN6Res1tG8S4pxzCq3AsWmw3EYHRVELtQe8dx5Lsr4Hts7MQo6PZZj8cME1JA7+yKhp3emaCS6Jw84vcEcRfwWivibwMwY3R5hiDjFVR9DKe5r28PcLWWUMcq8u5qwvH6Nz2zYdVR1DS3j9LgSPuLj7r0eDJ6WkWfPNbpvu2e2Py/R9c5nNc1tvFREKlguKU2OYDh+M0MjX0tdAyoiINxuvaD/AFVwXW1yCynpODuahU9JazkEyVCQlAyo7P7qqrNQbx/dVuKBLlWaY/p/dV7KxS9meaCayEJCUEFRxUPLVTVPFQAoHKxB2arjVWoB+mgcgo4IQVHj6k2xSyH6k3eQWafs/upbqOmt0X3UtkAqUo/WdzV1UJXfrEeqCQDXRWIuoFXaVYjvuIH30soKoaNU6hquDUFYDVKlSFBZpj9B5qS6hpuoeamAQHFQVI1bdWFXquLUEQQUn2QEFqEfpNTyEyHsmqTTggb3ap3ekNrIQLomydm7TuSpJOzdyQVe5HckB0QgfB2gVlV4dZArBQCZOP0nJ41TKjsigqpUiNEElN2v2VmyrU3a/YqzdAvBR1HZFSKOo7IoKt0EoSFBJB2reatWVSDtWq4gLeqZN2TuSfcFMm7J3JBUv4IJRZJb1QSU/ahW1Vg7UK0gSxTKjsipNFFUdkUFYFBKQIQS09+l+xVlVqbteHcVaugQKKpH6Y5qW6jqezHNBWsgFF0IJqXrO5Ke6gpes7krGiAsoKn9qm1UNV+1BAlukugILFL1TzUyhpuoealN0Boq1T2v2VnRV6ntPsghKEpCO5Bap+xCfxTKfsQn80CqlUds7mrnJU5+2dzQMQlARayC5D2TeSdxTYeybyTygFSl7Z3NXVSl7V3NAzvShKgILcekbeScki6jeQTkCcFSl7V3NXdVSl7V3NAiLJAl1QXW6tHJOATWn6RfwS8UChUX9Y81dVJ3WPNAiRKhBe7gl5pNNEqAKoFXtVRPeUBwQEnFKEF4DRCBwS6IBUXdY81dVFx+o80BdJx4I/CVBdb1RySobwHJKeSBFRf13c1e0VF5+t3NAiLoGvFGiC/3IsgcEFAjuq7kVSV13VPJUfsgE+HtW800WT4e1bzQW0JbaJEEdSP0jzVUK3UdkeaqFAKek6zuSgupqTrO5ILBQhKgrVfWbyKhupqsat+6gQCtUvZnmqys0vZfdBKbpUh4I+yCPp4/U/ZHTx+J9lVQgmex0rt9lt0+Kb0MngPdTU3Yj7qRBW6GTwHupGSNY0Mde40NlMqc3bOQWBPH4n2SdPH4n2VXj6IQSmJ7iXaWOvFJ0EngPdWWdQckv3QVehlGpA91N08fifZSHgeSooLXTMvxPskdK1wLQTc6cFWsnxj9RvNA7oZPAe6Ohk8B7q0jRBA1jozvuAsPVO6aPxPsln7JyqC6Cw+Zv7SfZfPP47s1SZh22TYRDPv0eAUzKVjQfpErgHyHnq0H+6voFNJHBDJUzuDIYWmSRx4BoFyfYL5PbQccGYs749jzZZJG4hiE9RG6QWcWOeS24/u2CD0Nk2VZM1Zphp3gmkgcJKk+DV1kxrGMbHG0Na0BrQO4DgtTfDThMEGUZ8W3XfMVU7mFzhoGttoFtnRUWtyzfJt5Pc8E00YdNFvG3X9i96LIHoncVxLglkoGqVLa6lBBcIPBCLIhr3b7BNUbNK8Qxl5jfHI6w4NB1K5mwelirMWoqaaTo45ZWsc/wBK6n21sn/7M8XFO8Mc5jQ4k2u2+oXKlISKiEg6h7SPcK54dP8Ofi8d9oIj7xHw/zLpGCDoo2RNvZjQ0X8ApbJYyTDGTxLGk+yCrV50iUO8Cm96Cg8rNGCUOP0XytfFcjWORvWjPiCtGZrwGqy/ir6OY77eMcgFg5q6GOq8vMmA0WP0BpK1mo7OQdZh8QomN0xOzV2yDaZmrZlmJuLZbqg1j7CrpJiXQVTB+17fHwcNQvozsS2j4XtWyXFmPC4ZKWRjzBV0spu6CUC5AP7mkG4P9V8xszYDiGAV8lNVxO3Af05QPpeO4grYPw/bbsybJ8SeyjYyvwOqlD6zDpTbeNrb8buLX2+x71rZvpiYpPAe6OiktwHusf2YZ7y9tCyrT5iy3VCell+mVj9JIJBxje3ucPyNQsq0OoKCFkrY2hjyd4cU4VEfr7KCoA6ZyaLILPTx37/ZROic9xeALHUaqIq5F2TeSCv0Dx3D3SGCTwHureqLII2zMaACdRpwS9OzxPsqrh9Z5lCCyZoyLa+yi6F/gPdRgaq6OCCt0L/Ae6URPBDjwGp1VhI82Y7kgTpWnx9liu1HOOH5EyTimasReBBQwF7WHTpZDoxg/vOsPdZCH6aLlH/0hubY4Mu4BkqGqcJqyc11VE06dEwbsd+bt4jkg46zVjNXmPMOIY9iMm/W4hUvqJj/E43sPQcFsfZBg0NLhBxeQB1RVEtYbdRg/zWrsMw+XEcVgoKcFz5nhot3eJXQuG0MVBQwUUAtHCwMH2WVYRZaGvBOA70jQnhZsAAlASgBKiCI1TrI1QNugpfskspDSmkJ9rpCoHjZuwOLHMDmon6P68TrdVw4Ln+oidBUPheLPjcWkeoK6Wc8jgtN7WcFNDjDcRp4yIKrV9ho1/wD5rG0Mqy218MeKuqMo11BLu/6pUgs11s4a/kLa5e0rlTYLiNRRbSKKFlQIoaoOila51muFjb73supgxw0svPa3HyZZ973vBc/ptLEeNeh5cEDVN3XeCwjPG1DLuVJJKR73V2IsH/doD1T4OdwC56Utedqxuss2bHhrz5J2hnT2hjN97mtb5nGwXlux7BBif9mnFaT5v/ddILrlbOWfcxZqr3TV1dLFDf8ATpoXlscY8LDjzK9HZHlevzPmymlLJXUtO8STTuvYW7r+K7p0EUpNr2UccdnLljHhpvvPi6ouOCQtv3p3Rbug4DQItZVz0LHNo2W2ZlybX4Xugzuj6SnJ7pG6j/JcikGnmfFIN18bi1wPcRoV2+L8bXtquR9rmBjAtoWJ0jW2hkl6eL1a/VWfDsnejzH2i0+8VzR8J/w7g+BfNEWP7EafCJKxs1ZglVJTOj/dHE470d/TiPst+dE/ut7r54/BFnF2XNtNLhEkpZQ4/EaKRvd0vWid7gj7r6KRt3W2J1Vs8qg6GT091JEehB6TS/C2qmUFXxbqgk6ZnifZJ00fr7KsCEX8EFh7hK0tZx46qPoZPT3TqXrO5Ke10FboZPT3UkbhE3dfx46aqZVqvrt5IJemZ4n2R00fr7KpcpWuBNtSfAaoJ5GmUbzBp6qLoZPAe68fNGd8pZRovmMy5iwzCowbf6xUNa4nwDeJK0rnf4u9nGDF8WBQYlmKZri28MfQw899/Ecgg6EEThxsPupoi3dte5HhquBc2fGPtCxCUDAMOwfBIgTxjNRIR3XLrAfYLW+L7f8Aa9ikxfU56xaMb12sp3NiaPs0IPpnjuYMEwKmfUYxitFh8TGGRzqmdsf0jidTeywTEdveyLD5BHUZ9wYuNtInuktz3QvmbmPMGOZixB+I47idbiVW/rS1Upkdy14D0C8sF44OtyNkH0dx74n9jmG4maP/AEgqq2wBM9FRPlhFxw3tL/YLzKr4stkELSYqrHKogaCPDi0H7uK+fcVJWzM6WKnqJGeZsbiPcK5DgGPTMEkeD4lIw8HNpnkH8JsjeHeWGfGFstkqJIqmmzBSRNtuSupGvDvs03CiqPjI2aMqnRxYdmKWIOsJBTsFx42JuuLMt7Os7ZhbM7CMsYnUCHtD0RYB6fVa5VOvyVmuiq3UtVlvFo528WGlcT+Ap5ZOaPN3rSfFvsfqNJK7GKU/+LhziD/wkr18O+InYzXO3xnempydbVFPIz+i+b9RQV9I5zaijqoXNNnB8Tm29wq5kkGm8R6EqEvq5l7aJkPHnBmDZvwOuebWZHWsDjf0NllMNZE9p6I9Lbj0ZDrey+O7Xva4ObbeBuCOI+69bCc0ZlwycTYdj2KUcgNw6Grkb/VB9dBWR3sd4HwISSzRvAFnaei+duQfik2n5b6GDEa2mzFRRgjosRj+u3d+q36tPut05T+MnKtUGR5mytiWGv3fqlopW1Ed/wC6bOAQdUdE86i1uaOhk9PdYNs/2ybOM8MZHl/NNFJUltzS1DugmHd1X2v9ln4eAbHQ+qBIwYmnf4E9yd0zPX2Tag3YOag1QWOnZ4n2TJP1rGPu430URUtJwcgb0Evp7o6GTwHurQCCUEDZGxtDHXuE7pmeJ9lBUH9VyjQW+mjOmvsn3d5fyqbeI0V4IG/V5R7pr94sI3e7xUh4pHdU69yCo1j/AA/Kd0b/AA/KezgE8IImt3HBzhoFJ0rPX2SS9T7qEoJ+mZ4n2TXvbI0sbe58VEnQD9QIAQv8B7peif4D3VhFwAggY10Tt93D0TzMw959ktR2RVX7ILPTM8T7JHvbIwsaTcqv9k+n7YIDopOFh7pehk8B7qzZKAgqtjfG8PcBYcbFSdNHxufZPm7JypoLQmj9fZI6Rr2ljL3PBV7p8HatQL0Ml+A90dC/wHurVroIQVmMdG7fcNBx1UnTR+J9ks/ZOVXRBZ6Vnj+EkjmyN3GEklV7qSn7UIAQyeA90dDJ4D3VlKQgrRtdE7efw4KXpWeJ9klR2X3UA0QWBKzxPsmykSN3WanioSSpKc3eeSBnQv8AL+UdDJ4D3VrVFkEMQMRJeLXUnSM9fZNqDYDmoboLHSM9fZRyjpbbgvbjdMUtOesgi6GTwHuk6GTw/Kt29UiCCJ3RAtfoTqpBNH4n2UVUPrHJRBBa6Znj+FHI0yneZqOGqhVmnH6f3QQ9DJ4D3S9BJ4D3Vrh6o+yCBjxGzcfo4eCd00fifZQ1HbFRoLRmZ4n2UT43SOL223Tw1UStwdi3kgg6CS3Ae6Ogk8B7q2hBC2RrGhjiQRodEvTR+J9lBP2zuaZyQWumj8T7KJ0bnuL2jQ6jVRcVch7FvJBB0MngPdHQyeA91aSWQRNla1oa46jQ6Jemj8T7KtJ2ruaRBa6ePxPsonRPe4uFrHUaqPuVuPs28kFfoJPT3R0EngPdWkqCMSMGhJuNOCDMzxPsqzz+o7mUAoLPTMHefZQuikcSQBY+qjPNXG9QckFboJPAe6Ogk8B7q13JUEQmjtxPsl6WPxPsqp0J5oQWTLH4n2UJhk7gPdMHFXe5BV6GTw/KBDJ4D3VoC6VBF00Y7z7JemYeJPsqveeaLoLXSx+vsoOheToBr6pt1bb1RyQVuhk8B7o6GTwHurXNKgi6Zg0JNx6I6Zh7z7Kq7rnmlugtdNH4n2UJheXFwAsdRqoyVcb1ByQVuhk8B7pOgk8B7q3b1QEEfTx8Ln2R00fifZVe9F0FozMIsL66cFCIJfAe6Y0/WOYV1BV6CTwHuhkb2OD3AbrdTqrQsmz9i/kgb08fcT7I6ePxPsqgSoLD3iVpYzjxUfQyeA90U3bDkVbCCoYZL8B7p0QMLi54sDoFZIUFX2beaB3TR+J9kdNH4n2VW6LoJpf1rGPW3G+ib0EluA91JSdV3NTIKvQS+A91JG4Qt3X6HjpqplWq+0HJBL00fifZHTxeJ9lVSIFQpvl3eZqPl3eZqCSm7EcypfsoGvEI3HAkjwS/MN8rkEypT9s7mpxUMtwKY6J0h6RpAB11QQoUop3eZqX5d3mCCdnUHJKoRM1v0kHTRKahnlKCW2hVEKx8w3hY6pvy7vM1BELJ0faN5p4gf4tSiFzCHkiw1QTlGqiE7fApTO23AoFn7Fyqg2U73iQbjQQT4qKSBzRcuCDnz45NosmUNmceWsPc5tfmXfgdIHWMVMy3SEerrhvJxXz+cN8gMGpNgAup/wD0i+J0dTnXLGCwvc+soKCWWoFtGtle3cHP9N34WgNlOBHHs9YfSOj34IXiefw3Gm/87BY3tFazafBtw4py5IpHeZ2dJbNsI/sPJGFYfu2e2APk/vu+o/zWSAlI0g8BYJwXmrW5pm0vpOOkY6RSPAounBIAlCxZHIBQk70DglskCCbINf7fqhsGzWsDw09JIxgB8dVy3C8smieDYtcDfkV0f8S9RbJNPCDbfqr28bNXNkbd+VjNfqICuuHxti+bxfH7b6rbyiHTNHJ0tHBKDcPjab+OikVXC2Ngw2lhbezIWtF+StBWrzwRZOtdLaygNsEo5JdEhOiCpjWG0eL4dLQ10YfFI23q0+I9VoTN+AVeXMTNLP8AXG76oZQNHt/zXQbrryM0YHSY/hb6KqFiNYpANY3eKiY3ZROzX2wnaxj2yrNbcVw55qMOqC1mI4e51mVEYP4eO539F9LNn+bcEzrlWizLl+sbU4dVsuw8HMcOsxw7nNOhC+T2P4RW4Hib6OsZZ7dWOHVe3uIWzfhs2yYpsqzVGZpZarLldI0YlRX0Hd0zPB7fyND3Ea2b6Vz6yuUfckoaqnxOigxGhqIpqSpjbLBKw3D2OFw4ehCm6Fx/cEEQCuxdm3koRTu8zU4Shg3C0kt0uEEyFF07fKUhqGj9pQQO6x5oU3QOd9QcLHVJ0DvM1BEOIV1QdA7zNTunb5SglskeLsdyUXzAB6pSOqA5pAadQggcF86fjVzNRZj254hFQUxY3B4mYdLKX36aSO+8bdwBNvsvoHm/FP7AytiuOPbvDD6KaqtcaljCQPubL5NYnXz4jX1VfVyOknqpnTSOc65LnG5ufugyfY9SyVOcY523DKeJz3nnoAt1ELX2xOi+XwSqxB7LOqJdxjvFrf8AzWwb3WysdGFu4CcBpqkATlLEWTkgSoE+6VL9kiANk2yckQNsmuCeU0oI3BY7tCoXV2UqyKNoL2NEgHLiskcFBKwPY5jhdrhYjxCSlzdFI6ORr43Fj2m7SDYgrqzZhnyixvIH9qYpUx08+HNEVdJIbC4GjvuPyuZ85YTJg2YKmkc20ZcXxnxaeCpR1lTHh0tDHUPbTTPa+WIHR5bwJ5XK4tTp4zV2WnDtfbR3m0RvEx2/Rt/aFtvrJp5aDKjY4aXdLTVyM/UffvaDw5rS000s8rpJpHPc9xc5zjckniSrGHYdWYlWxUdDTyVFRK7dZGxtySt45B2JRU3RV+apBNKLOFFGfob/AHz38gsN8Olr/u7dWms4pk38PyhiGxjZ23MdS7FcZhlbhUXZt6vTu8L+ULo7CKSjwyjZR4fSxUsDBYMjbYf+adTUkNPCyCGNkUTButYwWDR4AKYNAVPqNRbNbeez1+h4fi0ePlr1nxlJvIuCm8UWWh2hzrcFon4n8JkMuGY7G36d008pHceLVvUjx1WHbY8IGN7PsRp2NvLC0TxgeLf/ACXRpr8mWJcPEsHp9Levjtv9HM+R8TGB5vwfHJGvdHQVsNQ9rDZxax4JAPja6+teE4hT4lQ0uIUj+kp6uFk8Th3teA4H2K+PzX204DvC+jHwR5rdmDYTQU9XN0tTg88lATrcMH1R3J/hP4XonztvgqvV8Wp3zLLW1JSO/wBY6um74oK5CAFP0B73BL0B8wQJS6OdyVi6rn/VwXu1B00WM7QNomUMiYX/AGjmrGqfDIiCY45HXmlI7mRj6nHkEGWk24ryMy41hOB0LsSxrEqPDaKNpL56qYRsH3K5D2k/GbWGpdTZCy9DFC0kfOYqN57+UTSLDmb+i5kz9nzNee8XfieZsZqsSnLi5jZHfpxejGdVo5C6DtPaX8XWRcBMlJlOiqMzVbTbprmClB/vH6nfYWXN+0D4l9qeaulgZjQwOifcCnwtnRfSe4vN3HnotS4Lg2LY7XsosJoKrEKp/VjgjL3fjgt25E+GrH8QDKnNmIx4PCdfl4AJpzz13W/c39FlWlrdoYWvWveWi6utrK2pdVVdRLPM4/VLLIXuP+IklengGXcfzDOIcFwevxGQm1oIXOHvwXY+VNiGzrANyT+xP7TqG69NiEhk1/uizf5rY9DBBRUwpqOCGmgHCOBgjb7NsFvjTT4y0zqY/DDjvBfhx2iV7OkrYsOwkdzaqpBd7Nus9y/8L2GRdHJj2Z6qocNXxUVOGN5Bzjf8LowegsiwW2MFIaZz3lrPCthezChja12WzVub++qqnvJ52sFlNDkPJFC0CkyjgkQHD/VA4/8ANdZGEcFsitY7Q1ze095QU1HRU0IhpqOmhiHBkcLWtH2AVjedazXFoHcNAkS2WTExwJ6xJ8LlPbJI0WD3gejiiyE3FeopoKgETwQzA8RJG11/cLyMRyflbEGFldlzCJweO9RsB9wAvfskKhLBMT2QbNcSINTlKhY4C29Tl0R/BWEZk+GjJ1b0kmCYriWFSHqsfaeIH72dZbxKSywnHWe8M4yWjtLkrM/w0Zuo29JgmK4bi474y4wP/wCbQ+61PnDJeZ8pVfy2YMFq6F1rtc9l2OHo4aFfQ2yZU09PU07qapgingf1opWB7D/hOi1209Z7NldRaO75sxyStc1zSbtN2m+oPoe5bd2dfETtRyWyOmp8eOK0LBYUuJt6drR6OvvD3K6EzbsP2c5hLpf7HdhNS7jNhz+jF/Vhu0/ay0XtO+HrMmAB1blaV+YKAC7o2sDamPmy/wBQ9W3Wi2G0OiuelujojZb8XeUMfEVBnaiflusJA+ZYTLSOPqR9TPuLeq6JwzEMPxWgixDC62nraOZodHPTyCRjgeBBC+QdVBU0lQ6GoilgmYbOZI0tcD6grJcgbRM4ZFr21eWMercNcDd0cb7xP9HRn6T7X9VqbX1eKmpbfUuTtjnxdYZis1NhO0SjhwqofZgxSmv8uT3GRnGO/iLgd9l1LhNfSVtBFX0NVBWUk7Q6KankD2PB1BDhoUHpIUQmHe0pemb4FBDUD9UpgCndGZPrBABSdA/zNQRDiroVboHcd4J5nb3tKCUpHdQ8lF07fAo6ZrhugHXRAR8An6JGxkd4T913ogjm6n3UKmmB3dbcUzoz4oGX8U6DtAndGlaNxwKCZHHuTQ/xb+Ub/g38oEn7Iqt9lYeS8btrXTOhd5gghKfB2oT+gcf3BAjMbt8kEDwQT31RdRdM3wKOmb4FA+bsnKorDpBINwAgnxTRA7zNQQWUkPatT+gf5moEbo/rJBA8EFgJL6qHp2+BS9O3wKB0/ZOVVTmQSDcANz4pBA7zBBDZSU/ahOMDvMErIzG4OJBHDRBNeyVM3vRG8EDajs/uoFPKd5trd6jDD4j3QMIUlP1zySbh8QnRjcdc6oJxZCZv+hSdIB3FA2p4DmolK79U7o0trqk6F3mCCJTU/wC5HQm3WCGDoz9RGqCZBsEzeb4pd4cboIKrrN5KJWJGGUgtIsNE3oHeZqCFWafs/umdA7xanNIiG47noglJQmdK31R0reOqCCo7UqNTujMrt9pAB8Uny7h+5qCHmrkHZN5KHoH+ZoT2yCMBhBJGiCYpLqLp234FL07fAoK83bP5pqmdEZCXggB2uqPl3eZqCGyuQj9JvJQ9A7zNTxIIwGEEkIJbpVF0zPAo6ZvgUFeW3Su5pFMYXPO8CNdUnQOH7moIu5XI+zbyUHQO8zU/pA0bpBJGmiCVCj6ZvgUnTN8CghePrdzKapjC9zi64F9UdC7xaghVxh+gclCYHeLVIHgCx4jRBJdINSmb7UoezjdBTPWPNGpUvQPuTcapegf4tQQq93Kv0D/EKUSNOiCRCZvDxQXhBT7yfVKpegdfi1L0DvFqCJXG9UclCYHeLUvTtGm6dNEE3ehQ9O3ylJ07fKUFd3XdzSWKnMDybhzbHVHQPP7moIVdZ1G8lB0D/M1PEzWjdIOmiCbRIVEJ2+BR8w3ylBV70tlL8u+995qX5d/magiZ1xzCvKsIHtO9dumqeZ2+BQTXTJuydyTOnb4FI6VrxuAG7tEFZLf0U3y7vM1Hy7/M1A2m7UcirSrtYYT0jiCBpon/ADDPKUEygq+o3ml+YZ4OTXnpxut0trqgr9yFOKd/maj5d/magdSdV3NTqu0/Liztd7XRL8wzuaUEyrVPaDkpBO3wKa5pnO+3QDTVBAjVTfLu8zUfLu8zUFi5SoRp4IKdT2x5KNSVPbHTuUYQCuQdk3kqiuQdk3kgchKPVCClJ13c00BLJ2juaS6AHEc1fVAHUc1fQJomyX6N3JOTZB+m7kgp3Si6El0EsHahTSlhaS82a0XJ9FXgNpWrC9vOPzZX2O5txuDf6aHDZGwlvFr3jdadOFiboPnTt5zd/pptezJmGOR8lNPVujpS7/cx/Qy3gCG3t6rM/hgw2QjFsTdE3cduxB/fe97clpaQW77811JsHw/5HZtRPdGGPqnOmNr6i9gT7Li19+XFt5rngWHn1UW/t6s2AATggjVAFlRvblShInAIFCEIUgCQ6oJTbFQNPfE7K1uX8Ph6WzzK5255hoLrQmFRdNidLFYHelaLfddE/EfhmF1OVoa2rrfl66ncRTMv2oPWbb+q0XkSmNRmzD2N3Duyb5DjYEBXmgmJxQ8Px2JjVzM+UN/MYGta3wAH4Twow8klOurJRHX1SpoShAoRwQEEIEKaWp5QUHj5jy9huP0ggxCIks6kjTZzORWjc1YPLgGOT4c5xkaw3Y8ttvNPArom6xvPOWYMx4eWG0dXGCYZfA+B9FjMbsonZD8OPxDY/s1qKbA8VL8Vyo6X9SnOstIDxdC7w79w6HutdfQvLmM4Zj2C0eM4RXRVtBWxCWnnj1a9p/ke4jiCCF8iK+iqsNrZKSqidFNGbOaV0f8ABxt6pMhSPyXm2VzcArJ+kpawm7aGV2h3h/u3aXI6p1tqSsGbvxUZSeldfxU1LVRTQsmilZNHI0OY9hu1zTqCCOIUEjgZnc0CXSk3ShuiR2gQXmdUckWXk5gzJgOXKFlZmDGMPwqne4MbJWVDYWud4AuIuVhmLbd9keG4gKCqz7g/T724RHIZGtPq5oLR9yg2VfRUhqFzXmT4zMjUGMmjwjAMYxakZIWvq2lkTXC/WY1xuRz3VjOcPjTpI4mR5PydM+Qi75cVmDQ0+AZGTfu1uEHXBaUoFl8/q74vNrU9Q2SCXAaVjTfoo8Pu06cCXOJ9VUqPiy2wylxbi+FwXN7R4azT0FyUHX/xV1rqX4es4yMLd40TYxc+aVgP4XzILgRcjRbGz5tu2l52wmrwfMGZ5Z8Nq3NdLSRwRxxndNwButva/qtbOv3oOhsn0DcPyxh9KAA5sIc63e46levYhaEwfOmYsNAZDXukja0NDJQHAAeC29kXMDcw4K2peA2ojO5MALC/otkTv0YTD32lOCaAlClieEqaE5SF4JEI7lAEhslSH1QIU0pxTSgQppsSnFNKDXG2zDmOoKTFGg9Ix/ROsNLHVapB+oXJt3robN9A3FMuVlG4C7oy5no4ahc+bliQe7RYWhsq6q2U5QwfLGExVdGPmKuribI6peBvbpF90eAWcFznLXeyTMMD9ltHiGKzx08dFvU75ZHaEN4feyq5i215Ywu8VBBUYnMPKOjYPuf8l5y+LLkyTG28voWHU6XT6elt4rExvs2WSQUuvgVzvmHbtmGsj6PCqGkw0Hi/tX/nQLFo9p+dxIXOx6pdc3sQLfy4LbXh+WY3naHLk+0GlrO0bz/vvdYXsdU4OWkdne0PMuKSsppC7EHk63jBP4W6aMTPpY5J4uikIu5l72XPlw2xTtZYaXWY9VXmpunGqJKZk8T4ni7ZGlh5EWSAWPFSNeGrU6bRvDivMmHOwzMdfQSAgwVD2WPhfRdP/wDo8swNhzBmfLD3kfNU8dbC3uJjO6772K0dt/phS7TcQIAAnayUW9QvZ+EnMbctbecvVE8hZT1sjqGY91pRui/3svS4rc9It5vm+qx+izWp5TL6RtJur1Efpd9lU6N4NrajQqel3mh1/FbHOuXHG68fN2Z8Byngk2NZixWlwzD4R9U077AnwaOLie4C5K1D8QnxF5Z2ZiXB8P6PG8y2/wC5sk/SpieBmcOH9wa8uK4O2nbRs27RMddiuaMWlrJAT0MLfpgp2n9sbODR68T3koOlts/xfy1Mc+FbNaF9M0nd/tesYOkI8Y4j1fQu1/hXKGY8bxfMGKS4pjWJVWI10xvJPUymR59LngPQaBS5Ryzj2bMWZhmA4dPXVLtXBgs2MeZ7jo0epXTGzP4dcCwpsVdnKf8AtitFnfKROLKZh8Ces/8AA5rOmK1+zC+WtO7nTI+Qc150q+hy/hM9W0Gz5yNyGP8AvPOgXSGzX4csAwYR1ub5hjdaLH5aMltNGfX9z/wOa3hh9NS0FHHR0FLDS00QtHDCwMY0egGinJXVTBWvfq5L57W7dHn4Ng2EYLTmnwfC6LDoj1mU0Ij3udtT91eAt3JUtlu7NBLBLZKj7oBGiAlv6IERySoUhOaEWRyQKEvehJyQGiEvckUBCElk5IiQkISoUhtk1wupQlABUDFs5ZFytnGnMOYMHgq3EWbOBuTM5PGvvcLnzaN8M+MUIfWZKrP7Vp9SaOoIZUN/uu6r/wAH0XVhFk0vNrLC+Ot+7OmS1Oz5u4xhWI4LiElBilFUUNXEbPhnjLHN+xWX7KtrWd9m1a2XLWMyx0pdvS0E/wCpSy+N2HQE+LbH1XaGdsoZezlQGizDhUFa3dtHKRaWL1Y8ajlw9Fy9tU+H7MGXRNiWWulxvC2guMbW/wCswj1aOuPVvsFzZME16x1dWPPW3SejrPYV8RuUdpHQ4TXbmA5jcLfJTyAx1B/8F54/3TZ3Pit03JNrEL4/NbJDJxcxzDfwLSP5FdIbDfipzHlOKnwTOkcuY8HZZjajf/12nb/eOkoHg4g/xdy0N7vuG/RNT1jmQs5Zazrl2HG8sYtT4jRSaF0Zs6N3le06scPAhZE03QL3KkrvcqXegLJWddvNJdKw/W3TvQXUXSEaosgbLbcKj+6kl7MqLeFkC3KGkukATS5JF2oQWLIsjkj7oEtqE5If6p3cgRMn7IqQ2Uc3ZFBWRdCLIHw9q1WiqsI/VarXegEybsnJ5TJuycgqIQg2CB9P2oVtU6ftQriATZBoOacmyHQc0CAaJUBCBkujLjxUVypZ+z+6hBQOv6p8ZBd9lCpIOueSCUphF1J3JjkCQ6Su5BSqKHtX8gpggOCgqj1fupyoKvi1BEHaJd5M1QEFmnN2nmpCFFTdQ81MCgQcVXqO0+ys3Vao7X7II7pUiEFmDsgpPuo6fshonoFKqTdq5WuSqzdq5AxAQlQWouybyTuabF2beSfogSyqy9q7mrXeqkvau5oEuhIhBcjt0Y5JUkfZt5J1xwQCpyX6R3NXFUl7R3NA26EiXuQXGdUckW1SM6o5J2nigFTkNnnmraqP67uaADroumpUFwAWCEo6oQgQ8LKnexVzuVM3uUChxRdNShBcHAJbpBwCUIBUX9Y28VeVJ3XdzQNBQhCC83gEHikHVHJOQJZUn6PPNXlRf13c0CX8EIsjvQXu5ACUJCUA7qnkqN1ed1DyVFAXToe1bzTbap8Pat5oLeqVIShBHU9ieYVVWqnsTzVQIFBU9J1nclAp6TrO5IJ7IQlQVazrN5FQqes6zeRUCACtUvUPNVTxVql7I80EpQhGqCD5keQ+6PmR5D7qDghBMWGY9ICG37ikFOfMFLTdiPupO9BW+XdfrD2ThL0Q6MtuW96nVObtnc0EvzI8h90fMDyH3UCEE3QF31bwF9Uny5849lYZ1G8kuiCv8ueO8NPRO+ZHlPupjwPJUO9BZ+YHkPukMwf9G7be04qBOj7RvNBJ8u7zBHy58wVlCCv0fRDpCQQFoj43M7OytsWqaGkbGarH5v7O+sB27EWl0jgPHdFr9xIW+ay/QO5Lh/8A9IXj7KnM+W8qse0mjpZKydttQ6Vwa3Xk06IOVHyb+7p38F2dlo2y9hojjEbPlYrMH7fpGi5Byvhj8VzNh+GxtLjPO1pA8L6/hdmUzWRQshjFmRtDG8gLKq4laPVh6n7N45/iX8OkJBfvTkiUKrenKEqAhSgqS6Ci5QGhQHBqQpt/FQlpT4o5wYMLZu8A8g+Gq09ktj5M14Y1jiHGdvBbV+KOa9XhUAH0iJzr+pctVZMeWZrwxwJH+sN4K/0P8mrwfGZ31l/l+joOwBNvFOsjd1PNKu9TAJRyRohAuqVIEXsgCkKUppQBKS4SG6SxRLF9oeVYswUXzNKGtxCFv0H/AHg8p/otJVME1NUPp5mOjex1nscLEFdJyAtBN7LVu1p+ATxtliqYTijHAWi13m94dbhZY2jxZRPg2n8JXxBy5OqafJWc6t8mWpHblHVyauw9xPAniYif+HiNLrqnP22XZhkkXxrNlHJUvaHtpaE/MykHhoy4bfuLiAvl6HnuSF7lgydkZ2+NONu9BkvKN+IFRi0vsRHGf5uWnc2/E5tex9ro25kbhMLgQY8Np2w8f4jd35WocPw6uxCUR0dLNO49zGkrLMK2bY5Uua6qMNHGeO87ecPsE2N2P5hzLmHMVTHU49jWI4rNEC2N9ZUvmLATchu8TYX8F5gdI42BJJ7gtxYXszwOnj/1yWesk8d7caPsFkmGYBg2GAfJYbTxOH7tzed7lZRWWPM0EMLxNwDhh9UQ7gehdqvUosl5mqwHR4TO0Hvksz+a36C7xRqp5TmaYpdmuZJR+pHSw/35h/RWmbLMXPaV9EzkXH+i27qi105YRzS1KNltcOtitN9o3FKdl1eT9GK0xHqxwW2N1G6PBTywc0tZ0eyg3aanGAB+4RRa/lZ9gODUWCUDKKhYWxt1JPFx8SvQCcEiIhEzuBdKCgIUoKOKcPRNCVA5CQG6VSDuSFLZCgNKanO4pvFAhRZKl7kSifGHAgjQjVc9ZrojhuY62kLbBspLeR1C6ILgFpLa5SGDNsk+pZUMa8H14WWNk17pMqVrqnKtbh00sj4aR/zDIQCRdwsXW+yxKds9fWPfBDJI5x0a1pcfwth/DtVx0+e30cti2tpXxhpbcOIsbH2K6NosNoqU71PRU0B8WRNb/IKszar0F5jZ6PR8MnX4a3m+23Ts5JwnIubcTcwUuA1xa/g50Za33K2PlTYTXTOZNmKvjpY+JhgO88/fgFvsvcBa6YXFcl+IZLR06LXBwDT453tM2eRljK+C5ZpegwikbFfrSHV7uZXsb570gJKUNXFa02neV1SlaV5axtA3rprwSpA1PACxZ7udvieoTFmDC68NI6anLHO8S0/5LWuXa1+GYxQYjG8skpqqKZrhxG68Fb5+J+npnZTw6oeSJo6rdjHiCNVzo6QtsASLaghX+itzYYeD41jimrtMeO0vrq7G8Op8AGP4hXU1HQClbUzVE7xHHGwtDrknhxXHfxFfFTW4qZ8ubMqiahw43ZUYvulk1R6RA6xt/i6x7t3v03tg205q2h4ThOBVr30WD4fSwx/JxvNqiVjQDLIf3E20B0Hd4rBMsYDi+ZcagwjBqOWsrJj9EbOAHe5x4Bo7yV191TKm7p6ypsBJPPM/uu573E+5JK3fsq+HfGMZ6LEs4GXBsPNnNpR/3qUeo4Rjnr6LcOw7Y7g+Q4WYpiZhxLML26z7t46bxbED3+LuPhZbWeQSurHgjvZy5M/hV4eVcsYJlfCm4ZgOHQUNK3UtjGrz5nOOrj6lew1oTkh0XT7nKWyEDVKGlSAH0SotbXgkJPcHHkFAdb1SJrXdyf3KUEQlNiksoSVASIHqpQUnwQhCgGqAhCkGqEiOKgKk4oSoEShFl4+csx4blLLdXj+MTdHSUzbm3We49VjfEk6JM7J79Ho4rW0uG0bqusmbDE3vPf6DxWpM47cqDBhJ8hQRzbgJvNLYm3gAuetpe2HNOc8RlkNScOoLlsNLAbbre67uJPiteP35nb73Oe497jcrlvqPCrqpp/GzpXCvina6pDcUypanJ1dTVP1j/C4WPuty7PM/5az3RunwGvD5oxeallG5NFzb4eouFwYMJxD5F1f8nUfKscGum6M7gJ4C6sZdxnE8vYvBiuD1stHW07t6OWN1iPQ+IPeDoVjXPas9WdsFZjo+jIYQEodurXuxDadSbQ8smaRscGL0dmV1O06XPCRo8rvwdPBZ9v7y7KzzRvDjtHLO0tW7YNjeXM7skrqJkeEY5YkVMTP05j4StHH+8Nea5Gzzk7MGTMXOG49QPppTrHI3WKZvmY7gR+R3r6FbgKoZky5gmZsHlwnHcPhraSQaskGrT5mni13qFqyYYt1ju2481q9J7ODtmmfM0bPcwx43lfEpKKoBAlj60VQ0fskZwc38i+hB1X0K2AbeMs7UsOjpWdHheZI2XqcMkk1fbi+Enrt9OI7x3nizbjsWxPIzpMXwh0uI5fLtZN28tNfgJAOI/iGnjZanw2urMNxCCvoKqalq6d4khnhkLXxuHAgjUFcVqzWdpdlbRaN4fYP5thIG6dfVHQk/uHsuW/hj+JGlzXJRZTz7PHTY+5zYqXECN2KuPANfbRkp/wCFx8CbLqthbe1xveChkh+XPmCOhLRvFwIGqsXTZD+k7kgiM48h90fMDyn3VcG4SkIJ+k6T6A2xKDC7xCjg7VqtcEEPQu8wRuGM75IIHgpwo5+zKBvTjylJ0/8ACfdQoQTtk3zugWKk+rxCrwdqFZHFAgDvEJsgcGG50T02Xsygg3SUBhPgngXTrWQMa0sO8baJxn/hPukkP0lQEoJ+n/hPulMnSDcDSLqFounwi0gvogXoHeYJOgceLgpi5viPdKCPFBEyEsdvkg2Utz4JXdU6oPNAhKZK6zQSNAU4n1UU5/TKA6ceU+6OnHlPuoBqlt6oJ98SnctY8UdCfMPZMpx+qOStIIOgPmHsgDojvHW+imuo5+qOaAEl+5Bue5NYNVIEEesbt8672lgl6ceUoqeq0KBBP048pTXgzHTS3iowVLTcXIGiB/mCXoXW6wVhIUEIJhFj9V9dEdOPKfdJUX3hyUaCbphfqlI5plO+CAFErEHZ/dBH0DvMECF3mCsFCCAP6L6CCbI+YHlPumVHalMsUE/Tt8pSGMyHfBABUICsw9k3kgjNOfMPZHQO7nBTpbBBXbLuDcLSSNLp3Tg/tKhf2juaLeKCbpx3NKaYi879wLpisRD9NvJBF0DvEJOgd4hWUiCEShg3C0m2iXph5T7qJ/aO5oCCbpv4fymuiLnF1xrqhgBUgsgi6F3iEGFw7wpjZJdAzpWiwIOiDMPKVA7iUIJ+nb5SmmJzvqDgL6qPuVpnVbyQQdCfEJegceDgpylCCHpwNN06I6ceUqueJ5pR6oJ+nFuqUzoHcd4KNXBwQQCB3mCOhd3EKfRCCETjhulL0w8pVc8TzQgn+YHlKb0DjrvDXVRq2zqjkggEDvMEvQO8wU5Qgh6YD6S06aIM48pUMnXdzKQHRBOJxfqlNMLid7eGuqi4hXGD6RyQQCB3mCOgd5grFkqCA1AtbdKT5geRyrnii5QWPmA76d0i+iT5d3mCiZ128wryCt8u7zBHROj+u4IbqrFvVNm7J3JBF8wPIfdHzA8p91XSoJy/pv0wLE63SfLu8wSU3bDkVa5oKwp3eYJQDB9R+q+min5KKr6jeaBvzI8h90vzI8pVcoQTuBqNR9O74pPl3eYJ1J1Xc1Mgr/Lu8wSh/QfQ4b19bhWFVqu0HJA41I8h90fMjyH3VdCBwKRWPl/4rfZJ8v8Ax/hA+m7IfdSFQGQw/p7u9bvR8wfJ+UFhUpu2dzUvzB8v5QIuk/U3rX1sgg70cFOYD5/wj5c+f8IJmdQckoVfp936d29tOKX5n+D8oLB4FUO9T/Md25a/qgU/8f4QQH1To+0bzUvy/wDH+EGHc+revbXggnukuoPmCf2flKJz5PygfOf0XX4L5n/F5XVFd8Q+bDUF3+r1EdPG0nqsZEy1vcn7r6Wl3SjcI3QeOvcvlZt3xyozDtkzZitRIJDJik0bHC1tyN3Rstb+FgQev8OuECvz785I3eZRQOkv4OOgXSe7ZaW+FyOI0eMTtBMpcxjjfS3EfyW67Kh11t80x5PdcExxTSRPnvJoTwm2QLrkWx4QkB9EoKIKkukJCS6lIKa4EqQAJ7LAqBoD4ot75zCWngInH8rVuS272a8MH/jtW1vigkhfiVFEJR0kcAc5h8CdCFqzIzC/N2GhvdKDxsr/AEX8mrwPGP6y/wDvg6CJ+o28Uoso26kp/erBUHIsiyByUAQlSd6AJTUp4pO9EkcqmL4hFhmG1FfMC5kLC4gd6tlV8Qo6evopqOqZvQyt3Xi9tEGjMy5xxnGZpN+qkgpnE7sMZ3QB624rHoopZpWxxMc97jYNaLkrbs+zDCnYkyWOrmZSAfXDxcT/AHvBZPg+XsFwgh1Dh8TJBwkcN53uVhyyy3hp7A8j49ibwTSmli75Jxu+w4lZrhGzLDYXh+IVctUR+xg3G/5rYJ14puiy5YRzSr0NHTUMDYKSFkMbRYNaLKyEv3QApYlCOSAlCBLJe5HelQFkWSpbIG2S2CWyRAAXQl5IQHNCRKEC2SpAEqBw9EqaEqBUiEhUhCkQShQEKRKdUiBjxdat22UzhPQThp3d0tLu69+C2mQtf7a4z/YlJLY/TMRpyUW7Mq92KbIMSGFbRMIqnuYyN03RSOcNA1wsVuiv225Wp8WmozRYh0EchjNQACNDx3eNlzfh73/PU4Yd1xkaAb8DdXM34XiWDZgqqLFoiypD94n9rwdQ4HvBXBl02PLf1vJcaTiGfTYZjHHTf/H/AE7Bw7EKbEqKCuopRLTzsD43jvBVxjbjVct7I8/1mVcWjgrppZsHlO7LDe/R/wATfC3guosMraLEqCKuw6pjqaaVt2SMNwf8j6Kp1Gnthtt4PW6DiNNZj3jpaO8JN2yL2TimEXK53edvJCSeCAEvBBrP4jqcv2d9KQCY6phBtwXNBbd1yur9uDI6jZjiolB/SDZG8wVyhvg62V1w6f4W3veM+0MbamJ84/dmez7I2M5+zBT4ZhEbQBE11VUyA9HTsv1nHx8BxK7M2Z7Pcu5CwMYfhEW/PIAaqskaOlqHevg3waNAsW+HGho8P2Q4I6jlZK6ra+one1oB6QuILD47tu/xWz4rkBXeHHFY3eUzZJtO3gl3QEhShKuhoN1RcJSEm7dAu8BrdYDtZ2t5e2ewMgqmvr8WmZvw0MLgHbvc57v2t/J7lZ2wZ4o9n+UpcVnDZayW8VDTE6zS27/4RxJ/zXC+YMWxHHsXqsWxaokqa6qkMksrzqT/AEA4AdwWjNl5ekd27Di5us9m08zfEXtDxOeX+z6ukwando2Omp2uc0f33Am/qsAr89Z0r5zPVZrxqV5N7mseP5FS5HyLi+aXGWEClommzqmUHdJ8Gj9xWy6TYxgvQ7s+MV75bdZrGNbflYrVXHlyRvDfbJix9JYhlXbNtEy/KDFmSorYr6w1/wCuw/8AFqPsQumNie2PDNoMMlBVwx4djsDd51O1xLJm974766d7eI9Vy/tD2bYjlmmOIQ1Da7Dw7ddI1u66O/DeHh6hYlgWJ12C4xR4rh0roaujmbLE8HvBvbkeB9FEWvittYmlMtd6vo4JLpwK8vKeIxY9lnDMcgAbFX0sdQ1t+rvNuR9jovUIsu3o4tpgJU3klHNEFRdJ3pSUAjmhCgCLIQgEISG/gpBvbq5v+NnFakQ5awdryKaXpqmRnc5zbNaTyuV0iG+K0D8aOX3VOWcGzJDG5xoJnU05HBscmoJ/xAD7rVm9idm3D7cOacn4A/MeZ6TB4pWw9M4l7z+1oFyR4my6Ly3kXLWBwsFLhcUsoGs1QOke7110H2XNmXsYqMGxyjxWlF5aaUSAHg4DiDzC6iyzmHD8xYTFiOGSh8Tx9bCfqid3tcO4j8qNHFJ337stXN428nozx076V9JJTxPp3tLXRFg3SPAhc7bX8mMy1iUdbh4Iwyrcdxp16F/Esv4d4/8AJdGBm8sU2tYS3ENn+Jx9HvyQsE8foWm9/a66NRji9PfDRgyTW/uac2G5pflDaRheIiUto55BS1ovo6F5AJPLR32XeoiDe8H1HevmpvdEQR3G4X0RyRikmJ5KwLEJm7stTh1PK8eBMbbrk08ztMOrUVjpL2HaJhKdcFFgulzIZY2zRuilY2SN4LXMeLhwPEEHiFzptu+H5j2T5gyFThrtX1GFDge8uh/+D28F0gUlyOCxtSLxtKaXmk7w+bh6WlmLXCSKSN1iNWua4H8EFdbfDD8UFXDW0mUdplaJqWW0VHjUp/UiPBrJz+5vdvnUfuuNQu3zYtT5ubLmHLMMVPj4G9ND1Y63+gk9e/v8VyRW0tRQVk1LW074aiF5jkikaWuY4aEEeK4MmOaT1d+PJF46PsRE9sjQ5pBaRcEG4I8U94/TdyXDvwkfEU/BHUOQc91gfhRIiw3EpX60nlikJ4x9wd+3gdOHbbakSANABDuBBvoe9YNiECwSqfoP4vwj5f8Ai/CBkPatVruUHR9H9d727knzH8H5QTpk5/SKj+Y/gHujpOl/Tta/egiTgLqQQEfu/COit+78IEhH6gVhQ26Mb972VPFsbw7CaQ1mK1lLQUwNumqp2RMv4bziAg9G6bNrGbLQ+aPiv2S4NidRQQ1uI4uYYyenoKXehc8fsDnFtz62t6laHzj8Zed698sWWsAwjB4C79OSfeqZgL99yGf8qDupp8LnkFjGZdpGQ8tzMgx3N+CUE0hs2OWsZv8AG2oBJA9Svmrm/a5tLzc57cdzji9VC5290DJjFCD6MZZo4+Cw6kpqyvqRDSwzVE7zYMjYZHuPhYXJUTMQPopnv4odk+Wq6OijxapxyV3XOEwiaOMer3Oa08m3WtcS+NPBosQezD8iYhU0jSQyWevZE93HXdDHAd2lyue6TYFtZqaijibkzEB83CJo3PLGNY09zyT9Dv4Tr6LOsr/Cbn7EopJMZrsKwMtfutZK8zveLdYbmluZXHk4hpccb2yR9f2bIxXntDJcS+NXMrrf2ZkvBqfT6vmKiWX23S1Ylinxe7XKpwNK/AaC3+4w8O
  <p class="hero-sub" data-i18n="hero.sub">Miniminds acompaña a familias con niños neurodivergentes. Información clara, apoyo emocional y estrategias prácticas — cuando más lo necesitas.</p>
  <div class="hero-ctas">
    <?php if(auth()->guard()->check()): ?>
      <a href="<?php echo e(route('paciente.inicio')); ?>" class="btn-hero">Ir a mi panel</a>
    <?php else: ?>
      <a href="<?php echo e(route('register')); ?>" class="btn-hero">Comenzar gratis</a>
    <?php endif; ?>
    <button class="btn-hero" onclick="openChat()" data-i18n="hero.cta1" style="background:var(--lila)">Hablar con IA</button>
    <button class="btn-hero-out" onclick="document.getElementById('nosotros').scrollIntoView({behavior:'smooth'})" data-i18n="hero.cta2">Conocer más</button>
  </div>
</section>

<div class="checker"></div>

<!-- SCROLL STACK -->
<div class="scroll-stack" id="nosotros">
  <div class="stack-item">
    <div class="stack-card">
      <span class="stack-icon">🌱</span>
      <h2 data-i18n="s1.title">Cada niño tiene su<br><em>propio superpoder</em></h2>
      <p data-i18n="s1.text">El TEA, TDAH, dislexia, dispraxia y otras neurodivergencias no son limitaciones — son formas distintas de procesar el mundo. Miniminds te ayuda a entenderlas y a convertirlas en fortalezas con el acompañamiento correcto.</p>
    </div>
  </div>
  <div class="stack-item">
    <div class="stack-card">
      <span class="stack-icon">💜</span>
      <h2 data-i18n="s2.title">Apoyo cuando<br><em>más lo necesitas</em></h2>
      <p data-i18n="s2.text">Sabemos que recibir un diagnóstico puede ser abrumador. Nuestro equipo de mascotas especializadas está disponible 24/7 para responder tus dudas, darte estrategias concretas y acompañarte emocionalmente en cada etapa.</p>
    </div>
  </div>
  <div class="stack-item">
    <div class="stack-card">
      <span class="stack-icon">🚀</span>
      <h2 data-i18n="s3.title">Información clara,<br><em>sin tecnicismos</em></h2>
      <p data-i18n="s3.text">Nuestros especialistas virtuales traducen la información médica y psicológica a un lenguaje que toda la familia puede entender. Desde qué es el TDAH hasta cómo ayudar a tu hijo con la tarea, tenemos la respuesta.</p>
    </div>
  </div>
</div>

<div class="checker"></div>

<!-- MASCOTAS -->
<section class="mascotas-section" id="equipo">
  <h2 class="section-title" data-i18n="team.title">Conoce a tu equipo</h2>
  <p class="section-intro" data-i18n="team.intro">Cuatro especialistas virtuales, cada uno experto en su área. Siempre listos para ayudarte.</p>
  <div class="mascotas-grid">
    <div class="mascota-card">
      <span class="mascota-emoji">🦭</span>
      <h3>Nilo</h3>
      <span class="mascota-role role-nilo" data-i18n="team.nilo.role">Información</span>
      <p data-i18n="team.nilo.desc">El explorador curioso. Experto en diagnósticos, condiciones del neurodesarrollo y todo lo que necesitas saber sobre TEA, TDAH, dislexia y más.</p>
    </div>
    <div class="mascota-card">
      <span class="mascota-emoji">🦇</span>
      <h3>Kairo</h3>
      <span class="mascota-role role-kairo" data-i18n="team.kairo.role">Apoyo emocional</span>
      <p data-i18n="team.kairo.desc">El héroe protector. Especializado en manejo de crisis, apoyo emocional y situaciones de riesgo. Siempre tranquilo, siempre presente.</p>
    </div>
    <div class="mascota-card">
      <span class="mascota-emoji">🐦</span>
      <h3>Pipo</h3>
      <span class="mascota-role role-pipo" data-i18n="team.pipo.role">Estrategias</span>
      <p data-i18n="team.pipo.desc">El inventor creativo. Convierte cada desafío en una aventura con estrategias prácticas y actividades paso a paso para el hogar y la escuela.</p>
    </div>
    <div class="mascota-card">
      <span class="mascota-emoji">🐶</span>
      <h3>Luma</h3>
      <span class="mascota-role role-luma" data-i18n="team.luma.role">Motivación</span>
      <p data-i18n="team.luma.desc">La guardiana de las estrellas. Celebra cada logro, por pequeño que sea, y recuerda a cada familia lo lejos que ha llegado.</p>
    </div>
  </div>
</section>

<div class="checker"></div>

<!-- TESTIMONIOS -->
<section class="testimonios-section" id="testimonios">
  <h2 class="section-title" data-i18n="fam.title">Lo que dicen las familias</h2>
  <p class="section-intro" data-i18n="fam.intro">Familias reales que encontraron apoyo cuando más lo necesitaban.</p>
  <div class="testimonios-grid">
    <div class="testimonio-card">
      <div class="testimonio-avatar">👩</div>
      <h4>María G.</h4>
      <div class="t-rol">Mamá de Sebastián, 7 años · TEA</div>
      <div class="t-stars">★★★★★</div>
      <p data-i18n="fam.t1">"Nilo me explicó el diagnóstico de mi hijo de una forma que finalmente pude entender. Por primera vez no me sentí sola en esto."</p>
    </div>
    <div class="testimonio-card">
      <div class="testimonio-avatar">👨</div>
      <h4>Carlos M.</h4>
      <div class="t-rol">Papá de Valentina, 9 años · TDAH</div>
      <div class="t-stars">★★★★★</div>
      <p data-i18n="fam.t2">"Pipo me dio una rutina de estudio que realmente funciona. En dos semanas mejoró la concentración de mi hija increíblemente."</p>
    </div>
    <div class="testimonio-card">
      <div class="testimonio-avatar">👩</div>
      <h4>Lucía R.</h4>
      <div class="t-rol">Mamá de Mateo, 11 años · Dislexia</div>
      <div class="t-stars">★★★★★</div>
      <p data-i18n="fam.t3">"Kairo me ayudó cuando Mateo estaba en crisis emocional fuerte. Su calma y sus consejos marcaron la diferencia."</p>
    </div>
    <div class="testimonio-card">
      <div class="testimonio-avatar">👩</div>
      <h4>Ana P.</h4>
      <div class="t-rol">Mamá de Isabella, 6 años · Dispraxia</div>
      <div class="t-stars">★★★★★</div>
      <p data-i18n="fam.t4">"Luma me recuerda cada semana los avances de mi hija. A veces olvidamos lo lejos que hemos llegado."</p>
    </div>
  </div>
</section>

<div class="checker"></div>

<!-- COMO -->
<section class="como-section" id="como">
  <h2 class="section-title" data-i18n="how.title">Cómo funciona</h2>
  <p class="section-intro" data-i18n="how.intro">Tres pasos simples para empezar.</p>
  <div class="pasos-grid">
    <div class="paso-card">
      <div class="paso-num">1</div>
      <h3 data-i18n="how.s1.title">Abre el chat</h3>
      <p data-i18n="how.s1.text">Haz clic en la mascota flotante o en el botón de "Hablar con IA". Sin registro, sin espera.</p>
    </div>
    <div class="paso-card">
      <div class="paso-num">2</div>
      <h3 data-i18n="how.s2.title">Cuéntanos qué pasa</h3>
      <p data-i18n="how.s2.text">Escribe con tus propias palabras. El sistema detecta qué especialista puede ayudarte mejor.</p>
    </div>
    <div class="paso-card">
      <div class="paso-num">3</div>
      <h3 data-i18n="how.s3.title">Recibe apoyo real</h3>
      <p data-i18n="how.s3.text">La mascota correcta responde con información, estrategias o apoyo emocional — según lo que necesites.</p>
    </div>
  </div>
  <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:8px">
    <button class="btn-hero" onclick="openChat()" data-i18n="how.cta">Hablar con IA</button>
    <?php if(auth()->guard()->check()): ?>
      <a href="<?php echo e(route('paciente.inicio')); ?>" class="btn-hero-out">Ir a mi panel →</a>
    <?php else: ?>
      <a href="<?php echo e(route('register')); ?>" class="btn-hero" style="background:var(--peach)">Crear cuenta gratis</a>
    <?php endif; ?>
  </div>
</section>

<!-- FOOTER -->
<footer id="contacto">
  <div class="footer-grid">
    <div class="footer-brand">
      <h3>Miniminds!</h3>
      <p data-i18n="footer.desc">Apoyo al desarrollo de mentes sanas y adaptativas. Acompañamos a familias con niños neurodivergentes en cada paso.</p>
    </div>
    <div class="footer-col">
      <h4 data-i18n="footer.platform">Plataforma</h4>
      <ul>
        <li><a href="#nosotros">Nosotros</a></li>
        <li><a href="#equipo">Equipo</a></li>
        <li><a href="#como">Cómo funciona</a></li>
        <li><a href="#testimonios">Familias</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4 data-i18n="footer.resources">Recursos</h4>
      <ul>
        <li><a href="#">Guía TEA</a></li>
        <li><a href="#">Guía TDAH</a></li>
        <li><a href="#">Guía dislexia</a></li>
        <li><a href="#">Blog</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Legal</h4>
      <ul>
        <li><a href="<?php echo e(route('juegos.index')); ?>">Juegos terapéuticos</a></li>
        <li><a href="#">Términos</a></li>
        <li><a href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2026 Miniminds. Hecho con 💜</p>
    <div class="footer-socials">
      <a class="social-btn" href="#">ig</a>
      <a class="social-btn" href="#">tk</a>
      <a class="social-btn" href="#">yt</a>
    </div>
  </div>
</footer>

<!-- CHAT FAB -->
<button class="chat-fab" id="chatFab" onclick="openChat()">🦭</button>
<div class="chat-tooltip" data-i18n="fab.tooltip">¡Hola! ¿En qué te ayudo?</div>

<!-- OVERLAY -->
<div class="overlay" id="overlay" onclick="closeChat()"></div>

<!-- CHAT PANEL -->
<div class="chat-panel" id="chat-panel">
  <div class="chat-panel-header">
    <div class="chat-panel-header-top">
      <div>
        <div class="chat-panel-title">🧠 Miniminds</div>
        <div class="chat-panel-sub" data-i18n="chat.sub">Tu equipo de apoyo siempre disponible</div>
      </div>
      <button class="chat-close" onclick="closeChat()">✕</button>
    </div>
    <div class="mascots-pills">
      <div class="m-pill" id="pill-nilo">🦭 Nilo</div>
      <div class="m-pill" id="pill-kairo">🦇 Kairo</div>
      <div class="m-pill" id="pill-pipo">🐦 Pipo</div>
      <div class="m-pill" id="pill-luma">🐶 Luma</div>
    </div>
  </div>
  <div class="chat-messages" id="chat-messages">
    <div class="cmsg bot">
      <div class="cmsg-label equipo">🌟 Equipo Miniminds</div>
      <div class="cbubble equipo">¡Hola! Bienvenid@ a Miniminds 🌟 Somos Nilo 🦭, Kairo 🦇, Pipo 🐦 y Luma 🐶. ¿En qué te podemos ayudar hoy?</div>
    </div>
  </div>
  <div class="ctyping" id="ctyping"><span></span><span></span><span></span></div>
  <div class="chat-input-area">
    <textarea id="cinput" placeholder="Escribe tu pregunta..." rows="1" autocomplete="off"></textarea>
    <button class="csend-btn" id="csendBtn">
      <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
    </button>
  </div>
</div>

<script>

const cloudLayer = document.getElementById('cloudsLayer');
const NUM_CLOUDS = 9;
for(let i=0;i<NUM_CLOUDS;i++){
  const c = document.createElement('div');
  c.className = 'cloud';
  const size = 120 + Math.random()*180;
  const top = Math.random()*100;
  const speed = 28 + Math.random()*40;
  const delay = -Math.random()*speed;
  const opacity = 0.3 + Math.random()*0.4;
  c.style.cssText = `top:${top}%;left:-${size+40}px;width:${size}px;opacity:${opacity}`;
  c.innerHTML = `<svg width="${size}" height="${size*0.55}" viewBox="0 0 200 110" xmlns="http://www.w3.org/2000/svg">
    <path d="M30 80 Q10 80 10 60 Q10 42 28 40 Q28 18 50 18 Q62 8 76 18 Q88 8 104 20 Q120 10 136 22 Q152 14 164 28 Q180 28 180 46 Q188 50 188 64 Q188 80 168 80 Z" fill="white"/>
  </svg>`;
  c.style.animation = `drift ${speed}s ${delay}s linear infinite`;
  cloudLayer.appendChild(c);
}
const styleEl = document.createElement('style');
styleEl.textContent = `@keyframes  drift{from{transform:translateX(0)}to{transform:translateX(calc(100vw + 400px))}}`;
document.head.appendChild(styleEl);

const darkBtn = document.getElementById('darkBtn');
function toggleDark(){
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme')==='dark';
  html.setAttribute('data-theme', isDark?'light':'dark');
  darkBtn.textContent = isDark ? '🌙' : '☀️';
  localStorage.setItem('mm-theme', isDark?'light':'dark');
}
(function(){
  const saved = localStorage.getItem('mm-theme');
  if(saved==='dark'){
    document.documentElement.setAttribute('data-theme','dark');
    darkBtn.textContent='☀️';
  }
})();

const langBtn = document.getElementById('langBtn');
const langDropdown = document.getElementById('langDropdown');
let currentLang = 'es';
const i18n = {
  es:{
    'nav.about':'Nosotros','nav.team':'Nuestro equipo','nav.families':'Familias',
    'nav.how':'Cómo funciona','nav.contact':'Contacto','nav.chat':'Hablar con IA','nav.register':'Registrarse',
    'hero.badge':'✨ NUEVO · IA especializada en neurodivergencia infantil',
    'hero.sub':'Miniminds acompaña a familias con niños neurodivergentes. Información clara, apoyo emocional y estrategias prácticas — cuando más lo necesitas.',
    'hero.cta1':'Hablar con nuestro equipo IA','hero.cta2':'Conocer más',
    's1.title':'Cada niño tiene su <em>propio superpoder</em>',
    's1.text':'El TEA, TDAH, dislexia, dispraxia y otras neurodivergencias no son limitaciones — son formas distintas de procesar el mundo. Miniminds te ayuda a entenderlas y a convertirlas en fortalezas.',
    's2.title':'Apoyo cuando <em>más lo necesitas</em>',
    's2.text':'Sabemos que recibir un diagnóstico puede ser abrumador. Nuestro equipo está disponible 24/7 para responder tus dudas y acompañarte en cada etapa.',
    's3.title':'Información clara, <em>sin tecnicismos</em>',
    's3.text':'Nuestros especialistas virtuales traducen la información médica a un lenguaje que toda la familia puede entender.',
    'team.title':'Conoce a tu equipo','team.intro':'Cuatro especialistas virtuales, cada uno experto en su área.',
    'team.nilo.role':'Información','team.nilo.desc':'El explorador curioso. Experto en diagnósticos y condiciones del neurodesarrollo.',
    'team.kairo.role':'Apoyo emocional','team.kairo.desc':'El héroe protector. Especializado en manejo de crisis y apoyo emocional.',
    'team.pipo.role':'Estrategias','team.pipo.desc':'El inventor creativo. Estrategias prácticas y actividades para el hogar y la escuela.',
    'team.luma.role':'Motivación','team.luma.desc':'La guardiana de las estrellas. Celebra cada logro, por pequeño que sea.',
    'fam.title':'Lo que dicen las familias','fam.intro':'Familias reales que encontraron apoyo cuando más lo necesitaban.',
    'fam.t1':'"Nilo me explicó el diagnóstico de mi hijo de una forma que finalmente pude entender."',
    'fam.t2':'"Pipo me dio una rutina de estudio que realmente funciona para mi hija."',
    'fam.t3':'"Kairo me ayudó cuando Mateo estaba en crisis. Su calma marcó la diferencia."',
    'fam.t4':'"Luma me recuerda cada semana los avances de mi hija."',
    'how.title':'Cómo funciona','how.intro':'Tres pasos simples para empezar.',
    'how.s1.title':'Abre el chat','how.s1.text':'Haz clic en la mascota flotante. Sin registro, sin espera.',
    'how.s2.title':'Cuéntanos qué pasa','how.s2.text':'Escribe con tus propias palabras. El sistema detecta quién puede ayudarte.',
    'how.s3.title':'Recibe apoyo real','how.s3.text':'La mascota correcta responde con lo que necesitas.',
    'how.cta':'Empezar ahora — es gratis',
    'footer.desc':'Apoyo al desarrollo de mentes sanas y adaptativas.','footer.platform':'Plataforma','footer.resources':'Recursos',
    'fab.tooltip':'¡Hola! ¿En qué te ayudo?','chat.sub':'Tu equipo de apoyo siempre disponible'
  },
  en:{
    'nav.about':'About','nav.team':'Our team','nav.families':'Families',
    'nav.how':'How it works','nav.contact':'Contact','nav.chat':'Talk to AI','nav.register':'Sign up',
    'hero.badge':'✨ NEW · AI specialized in childhood neurodivergence',
    'hero.sub':'Miniminds supports families with neurodivergent children. Clear information, emotional support and practical strategies — when you need them most.',
    'hero.cta1':'Talk to our AI team','hero.cta2':'Learn more',
    's1.title':'Every child has their <em>own superpower</em>',
    's1.text':'ASD, ADHD, dyslexia, dyspraxia and other neurodivergences are not limitations — they are different ways of processing the world.',
    's2.title':'Support when <em>you need it most</em>',
    's2.text':'We know a diagnosis can feel overwhelming. Our team is available 24/7 to answer your questions and guide you at every stage.',
    's3.title':'Clear information, <em>no jargon</em>',
    's3.text':'Our virtual specialists translate medical and psychological information into language the whole family can understand.',
    'team.title':'Meet your team','team.intro':'Four virtual specialists, each an expert in their area. Always ready to help.',
    'team.nilo.role':'Information','team.nilo.desc':'The curious explorer. Expert in diagnoses and neurodevelopmental conditions.',
    'team.kairo.role':'Emotional support','team.kairo.desc':'The brave protector. Specialized in crisis management and emotional support.',
    'team.pipo.role':'Strategies','team.pipo.desc':'The creative inventor. Practical strategies and activities for home and school.',
    'team.luma.role':'Motivation','team.luma.desc':'The star guardian. Celebrates every achievement, no matter how small.',
    'fam.title':'What families say','fam.intro':'Real families who found support when they needed it most.',
    'fam.t1':'"Nilo explained my son\'s diagnosis in a way I could finally understand."',
    'fam.t2':'"Pipo gave me a study routine that really works for my daughter."',
    'fam.t3':'"Kairo helped me when Mateo was in an emotional crisis. His calm made the difference."',
    'fam.t4':'"Luma reminds me every week of my daughter\'s progress."',
    'how.title':'How it works','how.intro':'Three simple steps to get started.',
    'how.s1.title':'Open the chat','how.s1.text':'Click the floating mascot. No registration, no waiting.',
    'how.s2.title':'Tell us what\'s happening','how.s2.text':'Write in your own words. The system detects who can help you best.',
    'how.s3.title':'Get real support','how.s3.text':'The right mascot responds with what you need.',
    'how.cta':'Start now — it\'s free',
    'footer.desc':'Supporting healthy and adaptive mind development.','footer.platform':'Platform','footer.resources':'Resources',
    'fab.tooltip':'Hi! How can I help?','chat.sub':'Your support team always available'
  }
};

function toggleLang(){
  langDropdown.classList.toggle('open');
}
document.addEventListener('click', e=>{
  if(!e.target.closest('.lang-wrap')) langDropdown.classList.remove('open');
});
function setLang(lang){
  currentLang = lang;
  langBtn.textContent = lang.toUpperCase();
  langDropdown.classList.remove('open');
  document.querySelectorAll('.lang-opt').forEach(b=>b.classList.toggle('active', b.textContent.includes(lang==='es'?'Español':'English')));
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(i18n[lang][key]) el.innerHTML = i18n[lang][key];
  });
  document.getElementById('cinput').placeholder = lang==='es'?'Escribe tu pregunta...':'Write your question...';
}

window.addEventListener('scroll',()=>{
  document.getElementById('nav').classList.toggle('scrolled',window.scrollY>20);
});

const fabs=['🦭','🦇','🐦','🐶'];
let fi=0;
setInterval(()=>{fi=(fi+1)%fabs.length;document.getElementById('chatFab').textContent=fabs[fi];},2000);

function openChat(){
  document.getElementById('chat-panel').classList.add('open');
  document.getElementById('overlay').classList.add('visible');
  setTimeout(()=>document.getElementById('cinput').focus(),400);
}
function closeChat(){
  document.getElementById('chat-panel').classList.remove('open');
  document.getElementById('overlay').classList.remove('visible');
}

const API='http://127.0.0.1:5000/chat';
const SESSION_ID='session_'+Math.random().toString(36).slice(2,9);
let mascotaActual=null, enviando=false;
const messagesEl=document.getElementById('chat-messages');
const inputEl=document.getElementById('cinput');
const sendBtn=document.getElementById('csendBtn');
const typingEl=document.getElementById('ctyping');

inputEl.addEventListener('input',()=>{inputEl.style.height='auto';inputEl.style.height=Math.min(inputEl.scrollHeight,90)+'px';});
inputEl.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();enviar();}});
sendBtn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();enviar();});

function scrollAbajo(){messagesEl.scrollTop=messagesEl.scrollHeight;}
function actualizarPill(m){
  document.querySelectorAll('.m-pill').forEach(p=>p.classList.remove('active'));
  if(m&&m!=='equipo'){const p=document.getElementById('pill-'+m);if(p)p.classList.add('active');}
}
function agregarMensaje(texto,tipo,mascota,esCrisis){
  mascota=mascota||'equipo';
  const N={nilo:'🦭 Nilo',kairo:'🦇 Kairo',pipo:'🐦 Pipo',luma:'🐶 Luma',equipo:'🌟 Equipo Miniminds'};
  const msg=document.createElement('div');
  msg.className='cmsg '+tipo;
  if(tipo==='bot'){
    const lbl=document.createElement('div');
    lbl.className='cmsg-label '+mascota;
    lbl.textContent=N[mascota]||'🌟 Equipo';
    msg.appendChild(lbl);
  }
  const bub=document.createElement('div');
  bub.className='cbubble '+(tipo==='user'?'':(esCrisis?'crisis':mascota));
  bub.textContent=texto;
  msg.appendChild(bub);
  messagesEl.appendChild(msg);
  scrollAbajo();
}
async function enviar(){
  const texto=inputEl.value.trim();
  if(!texto||enviando)return;
  enviando=true;
  inputEl.value='';inputEl.style.height='auto';sendBtn.disabled=true;
  agregarMensaje(texto,'user');
  messagesEl.appendChild(typingEl);
  typingEl.classList.add('visible');
  scrollAbajo();
  try{
    const res=await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({mensaje:texto,rol:'padre',mascota_actual:mascotaActual,session_id:SESSION_ID})});
    if(!res.ok)throw new Error('Error '+res.status);
    const data=await res.json();
    mascotaActual=data.mascota;
    actualizarPill(mascotaActual);
    agregarMensaje(data.respuesta,'bot',data.mascota,data.es_crisis||false);
  }catch(err){
    agregarMensaje('No pude conectarme. Asegúrate de que app.py esté corriendo en http://127.0.0.1:5000 🔌','bot','equipo',false);
  }finally{
    typingEl.classList.remove('visible');sendBtn.disabled=false;enviando=false;inputEl.focus();
  }
}
</script>
</body>
</html><?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/home.blade.php ENDPATH**/ ?>