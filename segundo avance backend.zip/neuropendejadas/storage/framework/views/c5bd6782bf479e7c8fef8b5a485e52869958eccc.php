<?php $__env->startSection('title','Ritmo Zen — Miniminds'); ?>
<?php $__env->startSection('extra_styles'); ?>
<style>
*{margin:0;padding:0;box-sizing:border-box}
#rz-wrap{position:relative;width:100%;height:calc(100vh - 60px);overflow:hidden;background:#0a0015;font-family:'Segoe UI',sans-serif}
#rz-canvas{position:absolute;inset:0;width:100%;height:100%}

#rz-ui{position:absolute;inset:0;pointer-events:none;display:flex;flex-direction:column;align-items:center}
#rz-header{width:100%;display:flex;justify-content:space-between;align-items:center;padding:18px 28px;pointer-events:auto}
#rz-score-box{background:rgba(255,255,255,.1);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.2);border-radius:14px;padding:10px 22px;color:#fff;text-align:center}
#rz-score-box .label{font-size:11px;opacity:.7;text-transform:uppercase;letter-spacing:1px}
#rz-score-box .value{font-size:24px;font-weight:800;color:#b8a0ff}
#rz-level-box{background:rgba(255,255,255,.1);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.2);border-radius:14px;padding:10px 22px;color:#fff;text-align:center}
#rz-streak{background:rgba(255,200,100,.15);border:1px solid rgba(255,200,100,.3);border-radius:14px;padding:10px 22px;color:#ffd080;text-align:center}

#rz-lane-area{position:relative;width:540px;flex:1;display:flex;flex-direction:column;justify-content:flex-end;padding-bottom:90px;pointer-events:none}
.rz-lane{position:absolute;bottom:0;width:100%;height:100%;display:flex}
.rz-col{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding-bottom:90px;position:relative}
.rz-hit-zone{width:68px;height:68px;border-radius:50%;border:3px solid rgba(255,255,255,.3);background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;font-size:20px;transition:all .1s;pointer-events:auto;cursor:pointer;position:relative}
.rz-hit-zone.hit{transform:scale(1.15);border-color:#fff;background:rgba(255,255,255,.2)}
.rz-key-label{position:absolute;bottom:-24px;font-size:12px;color:rgba(255,255,255,.5);font-weight:700}

.rz-note{position:absolute;width:58px;height:58px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;transform:translateX(-50%);transition:background .1s;pointer-events:none;box-shadow:0 0 20px currentColor}
.rz-note.col0{color:#ff6b9d;background:rgba(255,107,157,.25);border:2px solid #ff6b9d;left:12.5%}
.rz-note.col1{color:#a78bfa;background:rgba(167,139,250,.25);border:2px solid #a78bfa;left:37.5%}
.rz-note.col2{color:#34d399;background:rgba(52,211,153,.25);border:2px solid #34d399;left:62.5%}
.rz-note.col3{color:#fbbf24;background:rgba(251,191,36,.25);border:2px solid #fbbf24;left:87.5%}

#rz-feedback{position:absolute;font-size:32px;font-weight:900;opacity:0;transition:all .3s;top:45%;left:50%;transform:translate(-50%,-50%);pointer-events:none;text-shadow:0 0 30px currentColor}
#rz-feedback.show{opacity:1;top:40%}

#rz-breath-panel{position:absolute;inset:0;background:rgba(5,0,20,.92);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;z-index:50;pointer-events:auto}
#rz-breath-panel h2{font-size:28px;font-weight:800;margin-bottom:8px;color:#b8a0ff}
#rz-breath-panel p{font-size:15px;opacity:.7;margin-bottom:36px}
#rz-breath-circle{width:120px;height:120px;border-radius:50%;background:radial-gradient(circle,#6d28d9,#1e0050);box-shadow:0 0 60px #6d28d9;transition:all 4s ease-in-out;margin-bottom:20px}
#rz-breath-text{font-size:18px;font-weight:700;color:#b8a0ff;margin-bottom:36px;min-height:28px}
#rz-breath-btn{padding:14px 36px;border-radius:50px;border:none;background:linear-gradient(135deg,#6d28d9,#a78bfa);color:#fff;font-size:16px;font-weight:700;cursor:pointer}

#rz-start-panel{position:absolute;inset:0;background:rgba(5,0,20,.95);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;z-index:60;pointer-events:auto}
#rz-start-panel h1{font-size:42px;font-weight:900;background:linear-gradient(135deg,#b8a0ff,#ff6b9d);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:12px}
#rz-start-panel p{font-size:16px;opacity:.7;margin-bottom:8px;text-align:center;max-width:420px}
.rz-key-preview{display:flex;gap:16px;margin:28px 0}
.rz-kp{display:flex;flex-direction:column;align-items:center;gap:8px}
.rz-kp .circle{width:54px;height:54px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;border:2px solid}
.rz-kp span{font-size:11px;opacity:.6}
.rz-start-btn{padding:16px 48px;border-radius:50px;border:none;background:linear-gradient(135deg,#6d28d9,#a78bfa);color:#fff;font-size:18px;font-weight:800;cursor:pointer;margin-top:8px;box-shadow:0 8px 32px rgba(109,40,217,.4)}

#rz-end-panel{position:absolute;inset:0;background:rgba(5,0,20,.95);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;z-index:60;pointer-events:auto;display:none}
#rz-end-panel h2{font-size:36px;font-weight:900;color:#b8a0ff;margin-bottom:20px}
.rz-stat{font-size:18px;margin:6px 0;opacity:.8}
.rz-stat span{font-weight:800;color:#fbbf24}
.rz-btns{display:flex;gap:14px;margin-top:28px}
.rz-btns button{padding:14px 32px;border-radius:50px;border:none;font-size:15px;font-weight:700;cursor:pointer}
.rz-btn-replay{background:linear-gradient(135deg,#6d28d9,#a78bfa);color:#fff}
.rz-btn-back{background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2)}

#rz-combo-bar{position:absolute;bottom:170px;left:50%;transform:translateX(-50%);width:300px;height:6px;background:rgba(255,255,255,.1);border-radius:6px;overflow:hidden}
#rz-combo-fill{height:100%;width:0;background:linear-gradient(90deg,#6d28d9,#ff6b9d);border-radius:6px;transition:width .3s}

.rz-particle{position:absolute;pointer-events:none;border-radius:50%;animation:rz-pop .6s ease-out forwards}
@keyframes  rz-pop{0%{transform:translate(-50%,-50%) scale(1);opacity:1}100%{transform:translate(calc(-50% + var(--dx)),calc(-50% + var(--dy))) scale(0);opacity:0}}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="rz-wrap">
  <canvas id="rz-canvas"></canvas>

  <div id="rz-start-panel">
    <h1>🎵 Ritmo Zen</h1>
    <p>Sigue el ritmo y aprende técnicas de relajación.<br>Presiona las teclas o toca los círculos cuando las notas lleguen.</p>
    <div class="rz-key-preview">
      <div class="rz-kp"><div class="circle" style="color:#ff6b9d;border-color:#ff6b9d;background:rgba(255,107,157,.15)">D</div><span>Rosa</span></div>
      <div class="rz-kp"><div class="circle" style="color:#a78bfa;border-color:#a78bfa;background:rgba(167,139,250,.15)">F</div><span>Lila</span></div>
      <div class="rz-kp"><div class="circle" style="color:#34d399;border-color:#34d399;background:rgba(52,211,153,.15)">J</div><span>Verde</span></div>
      <div class="rz-kp"><div class="circle" style="color:#fbbf24;border-color:#fbbf24;background:rgba(251,191,36,.15)">K</div><span>Dorado</span></div>
    </div>
    <button class="rz-start-btn" onclick="rzStart()">¡Empezar a relajarme!</button>
  </div>

  <div id="rz-breath-panel" style="display:none">
    <h2 id="rz-breath-title">Pausa de respiración 🌬️</h2>
    <p id="rz-breath-desc">Tomemos un momento para calmarnos</p>
    <div id="rz-breath-circle"></div>
    <div id="rz-breath-text">Inhala...</div>
    <button id="rz-breath-btn" onclick="rzEndBreath()">Continuar jugando →</button>
  </div>

  <div id="rz-end-panel">
    <h2>¡Sesión completada! 🌟</h2>
    <div class="rz-stat">Puntuación: <span id="rz-end-score">0</span></div>
    <div class="rz-stat">Precisión: <span id="rz-end-acc">0%</span></div>
    <div class="rz-stat">Combo máximo: <span id="rz-end-combo">0</span></div>
    <div class="rz-stat" style="color:#7dd3fc;font-style:italic;margin-top:12px" id="rz-end-msg"></div>
    <div class="rz-btns">
      <button class="rz-btns rz-btn-replay" onclick="rzReset()">Volver a jugar</button>
      <button class="rz-btns rz-btn-back" onclick="location.href='<?php echo e(route('juegos.index')); ?>'">Otros juegos</button>
    </div>
  </div>

  <div id="rz-ui">
    <div id="rz-header">
      <div id="rz-score-box"><div class="label">Puntos</div><div class="value" id="rz-score">0</div></div>
      <div id="rz-level-box" style="color:#fff;text-align:center"><div style="font-size:11px;opacity:.7">NIVEL</div><div style="font-size:20px;font-weight:800;color:#34d399" id="rz-level">1</div></div>
      <div id="rz-streak"><div class="label">Combo</div><div class="value" id="rz-combo-disp" style="font-size:24px;font-weight:800">0x</div></div>
    </div>

    <div id="rz-lane-area">
      <div class="rz-lane" id="rz-notes-layer"></div>
      <div style="display:flex;width:540px;gap:0;pointer-events:auto">
        <div class="rz-col"><div class="rz-hit-zone" id="hz0" onclick="rzTap(0)"><span>D</span><span class="rz-key-label" style="color:#ff6b9d">♥</span></div></div>
        <div class="rz-col"><div class="rz-hit-zone" id="hz1" onclick="rzTap(1)"><span>F</span><span class="rz-key-label" style="color:#a78bfa">✦</span></div></div>
        <div class="rz-col"><div class="rz-hit-zone" id="hz2" onclick="rzTap(2)"><span>J</span><span class="rz-key-label" style="color:#34d399">✿</span></div></div>
        <div class="rz-col"><div class="rz-hit-zone" id="hz3" onclick="rzTap(3)"><span>K</span><span class="rz-key-label" style="color:#fbbf24">★</span></div></div>
      </div>
      <div id="rz-combo-bar"><div id="rz-combo-fill"></div></div>
    </div>

    <div id="rz-feedback"></div>
  </div>
</div>

<script>


const LEVELS = [
  {name:"Brisa suave",bpm:28,notes:12,breath:"Respira profundo 3 veces",breathDetail:"Inhala por la nariz 4 segundos, sostén 4, exhala 6."},
  {name:"Lluvia tranquila",bpm:35,notes:16,breath:"Técnica 4-7-8",breathDetail:"Inhala 4 seg, sostén 7 seg, exhala por la boca 8 seg."},
  {name:"Viento entre árboles",bpm:42,notes:18,breath:"Respiración cuadrada",breathDetail:"Inhala 4, sostén 4, exhala 4, sostén 4. Repite 3 veces."},
  {name:"Océano en calma",bpm:50,notes:20,breath:"Respiración diafragmática",breathDetail:"Pon la mano en el vientre. Respira inflando el vientre, no el pecho."},
];

let state = {
  running:false, score:0, combo:0, maxCombo:0,
  totalNotes:0, hitNotes:0, level:0,
  notes:[], noteId:0, lastBeat:0, beatIndex:0,
  pattern:[], notesFired:0,
};

const canvas = document.getElementById('rz-canvas');
const ctx3 = canvas.getContext('2d');
let particles3D = [];

function resize3D(){
  canvas.width = canvas.offsetWidth;
  canvas.height = canvas.offsetHeight;
}
resize3D();
window.addEventListener('resize', resize3D);

function rnd(a,b){return a+Math.random()*(b-a)}

function init3D(){
  particles3D = [];
  for(let i=0;i<120;i++){
    particles3D.push({
      x: rnd(0,canvas.width), y: rnd(0,canvas.height),
      z: rnd(0.1,1), vx:rnd(-0.3,0.3), vy:rnd(-0.5,-0.1),
      size:rnd(1,4), hue:rnd(220,300), alpha:rnd(0.3,0.9),
      pulse:rnd(0,Math.PI*2), pulseSpeed:rnd(0.01,0.04)
    });
  }
}
init3D();

let wave = 0;
function draw3D(){
  const W=canvas.width, H=canvas.height;
  ctx3.clearRect(0,0,W,H);

  
  const grd = ctx3.createRadialGradient(W/2,H/2,0,W/2,H/2,Math.max(W,H)*0.7);
  grd.addColorStop(0,'#1a0035');
  grd.addColorStop(0.5,'#0d0025');
  grd.addColorStop(1,'#050010');
  ctx3.fillStyle = grd;
  ctx3.fillRect(0,0,W,H);

  wave += 0.015;

  
  for(let r=0;r<4;r++){
    ctx3.beginPath();
    const hue = 260 + r*25;
    ctx3.strokeStyle = `hsla(${hue},80%,60%,${0.06+r*0.02})`;
    ctx3.lineWidth = 2;
    for(let x=0;x<=W;x+=4){
      const y = H*0.5 + Math.sin(x*0.008 + wave + r*0.8)*80 + Math.sin(x*0.015 - wave*0.7)*40;
      x===0?ctx3.moveTo(x,y):ctx3.lineTo(x,y);
    }
    ctx3.stroke();
  }

  
  particles3D.forEach(p=>{
    p.x += p.vx * p.z;
    p.y += p.vy * p.z;
    p.pulse += p.pulseSpeed;
    if(p.y < -10) p.y = H+10;
    if(p.x<0) p.x=W; if(p.x>W) p.x=0;
    const s = p.size * p.z * (1 + Math.sin(p.pulse)*0.3);
    const a = p.alpha * p.z;
    ctx3.beginPath();
    ctx3.arc(p.x, p.y, s, 0, Math.PI*2);
    ctx3.fillStyle = `hsla(${p.hue},80%,70%,${a})`;
    ctx3.fill();
    
    ctx3.beginPath();
    ctx3.arc(p.x, p.y, s*2.5, 0, Math.PI*2);
    ctx3.fillStyle = `hsla(${p.hue},80%,70%,${a*0.1})`;
    ctx3.fill();
  });

  
  const laneX = [canvas.width/2-270+67, canvas.width/2-270+202, canvas.width/2-270+337, canvas.width/2-270+472];
  laneX.forEach((x,i)=>{
    const colors=['#ff6b9d','#a78bfa','#34d399','#fbbf24'];
    ctx3.beginPath();
    ctx3.moveTo(x, H);
    ctx3.lineTo(x, 0);
    ctx3.strokeStyle = colors[i]+'20';
    ctx3.lineWidth = 60;
    ctx3.stroke();
    ctx3.beginPath();
    ctx3.moveTo(x, H);
    ctx3.lineTo(x, 0);
    ctx3.strokeStyle = colors[i]+'08';
    ctx3.lineWidth = 2;
    ctx3.stroke();
  });
}

const COLS = [0,1,2,3];
const COLORS = ['col0','col1','col2','col3'];
const EMOJIS = ['♥','✦','✿','★'];

function generatePattern(n){
  const pat=[];
  for(let i=0;i<n;i++) pat.push(Math.floor(Math.random()*4));
  return pat;
}

function rzStart(){
  document.getElementById('rz-start-panel').style.display='none';
  state.level=0;
  rzStartLevel();
}

function rzStartLevel(){
  const lv = LEVELS[state.level];
  document.getElementById('rz-level').textContent = state.level+1;
  state.pattern = generatePattern(lv.notes);
  state.notesFired=0; state.notes=[]; state.beatIndex=0;
  state.running=true;
  document.getElementById('rz-notes-layer').innerHTML='';
  document.getElementById('rz-level-box').querySelector('div:last-child').textContent = state.level+1;
  state.lastBeat = performance.now();
  requestAnimationFrame(gameLoop);
}

let animFrame;
function gameLoop(ts){
  draw3D();
  if(!state.running){animFrame=requestAnimationFrame(gameLoop);return;}
  const lv = LEVELS[state.level];
  const beatMs = 60000/lv.bpm;

  
  if(state.notesFired < state.pattern.length && ts - state.lastBeat >= beatMs){
    const col = state.pattern[state.notesFired];
    spawnNote(col);
    state.notesFired++;
    state.lastBeat = ts;
    state.totalNotes++;
  }

  
  const layer = document.getElementById('rz-lane-area');
  const laneH = layer.offsetHeight - 160;
  state.notes.forEach(n=>{
    if(n.dead) return;
    const el = document.getElementById('note-'+n.id);
    if(!el) return;
    n.y += n.speed;
    el.style.top = n.y+'px';
    if(n.y > laneH){
      n.dead=true;
      el.remove();
      missNote();
    }
  });

  
  if(state.notesFired >= state.pattern.length && state.notes.filter(n=>!n.dead).length===0){
    state.running=false;
    setTimeout(()=>showBreath(lv), 400);
  }

  animFrame=requestAnimationFrame(gameLoop);
}

function spawnNote(col){
  const id = state.noteId++;
  const el = document.createElement('div');
  el.className = `rz-note ${COLORS[col]}`;
  el.id = 'note-'+id;
  el.textContent = EMOJIS[col];
  const lane = document.getElementById('rz-notes-layer');
  lane.appendChild(el);
  const lv = LEVELS[state.level];
  state.notes.push({id, col, y:0, speed: 0.6 + lv.bpm/120, dead:false});
}

function rzTap(col){
  if(!state.running) return;
  
  const laneH = document.getElementById('rz-lane-area').offsetHeight - 160;
  const closest = state.notes
    .filter(n=>!n.dead && n.col===col)
    .sort((a,b)=>b.y-a.y)[0];
  if(!closest) return missNote();

  const dist = Math.abs(closest.y - (laneH - 40));
  if(dist < 80){
    hitNote(closest, dist);
  } else {
    missNote();
  }

  
  const hz = document.getElementById('hz'+col);
  hz.classList.add('hit');
  setTimeout(()=>hz.classList.remove('hit'),120);
}

function hitNote(n, dist){
  n.dead=true;
  const el=document.getElementById('note-'+n.id);
  if(el) el.remove();
  state.hitNotes++;
  state.combo++;
  if(state.combo>state.maxCombo) state.maxCombo=state.combo;
  const pts = dist<30?150:dist<60?100:70;
  state.score += pts * Math.max(1, Math.floor(state.combo/5));
  document.getElementById('rz-score').textContent = state.score;
  document.getElementById('rz-combo-disp').textContent = state.combo+'x';
  document.getElementById('rz-combo-fill').style.width = Math.min(100, state.combo*5)+'%';
  const msgs = dist<30?['¡PERFECTO! ✨','¡GENIAL! 💫']:['¡BIEN! 🎵','¡COOL! 🌊'];
  showFeedback(msgs[Math.floor(Math.random()*msgs.length)], '#b8a0ff');
  spawnParticles(n.col);
}

function missNote(){
  state.combo=0;
  document.getElementById('rz-combo-disp').textContent='0x';
  document.getElementById('rz-combo-fill').style.width='0%';
  showFeedback('...', '#ffffff66');
}

function showFeedback(txt,color){
  const el=document.getElementById('rz-feedback');
  el.textContent=txt; el.style.color=color;
  el.classList.add('show');
  setTimeout(()=>el.classList.remove('show'),600);
}

function spawnParticles(col){
  const colors=['#ff6b9d','#a78bfa','#34d399','#fbbf24'];
  const c = colors[col];
  const wrap = document.getElementById('rz-wrap');
  for(let i=0;i<8;i++){
    const p=document.createElement('div');
    const dx=(Math.random()-0.5)*100, dy=(Math.random()-1)*100;
    p.style.cssText=`position:absolute;width:8px;height:8px;border-radius:50%;background:${c};left:50%;top:55%;--dx:${dx}px;--dy:${dy}px`;
    p.classList.add('rz-particle');
    wrap.appendChild(p);
    setTimeout(()=>p.remove(),600);
  }
}

let breathTimer, breathPhase=0;
function showBreath(lv){
  document.getElementById('rz-breath-panel').style.display='flex';
  document.getElementById('rz-breath-title').textContent=lv.breath;
  document.getElementById('rz-breath-desc').textContent=lv.breathDetail;
  animateBreath();
}

function animateBreath(){
  const circle=document.getElementById('rz-breath-circle');
  const txt=document.getElementById('rz-breath-text');
  const phases=[
    {scale:'120px',shadow:'0 0 80px #6d28d9',text:'Inhala... 😮‍💨',dur:4000},
    {scale:'80px',shadow:'0 0 30px #6d28d9',text:'Sostén... 😤',dur:4000},
    {scale:'60px',shadow:'0 0 15px #3b0764',text:'Exhala... 😮‍💨',dur:6000},
  ];
  let i=0;
  function step(){
    const ph=phases[i%3];
    circle.style.width=ph.scale; circle.style.height=ph.scale;
    circle.style.boxShadow=ph.shadow; txt.textContent=ph.text;
    i++;
    breathTimer=setTimeout(step, ph.dur);
  }
  step();
}

function rzEndBreath(){
  clearTimeout(breathTimer);
  document.getElementById('rz-breath-panel').style.display='none';
  state.level++;
  if(state.level >= LEVELS.length){
    rzEndGame();
  } else {
    rzStartLevel();
  }
}

function rzEndGame(){
  const acc = state.totalNotes>0?Math.round(state.hitNotes/state.totalNotes*100):0;
  document.getElementById('rz-end-score').textContent=state.score;
  document.getElementById('rz-end-acc').textContent=acc+'%';
  document.getElementById('rz-end-combo').textContent=state.maxCombo;
  const msgs = acc>80?'¡Increíble! Eres un maestro de la calma. 🌟':
                acc>50?'¡Muy bien! La práctica te llevará más lejos. 🎵':
                '¡Sigue intentando! Cada vez te relajas más. 🌊';
  document.getElementById('rz-end-msg').textContent=msgs;
  document.getElementById('rz-end-panel').style.display='flex';
}

function rzReset(){
  document.getElementById('rz-end-panel').style.display='none';
  state={running:false,score:0,combo:0,maxCombo:0,totalNotes:0,hitNotes:0,level:0,notes:[],noteId:0,lastBeat:0,beatIndex:0,pattern:[],notesFired:0};
  document.getElementById('rz-score').textContent='0';
  document.getElementById('rz-combo-disp').textContent='0x';
  document.getElementById('rz-notes-layer').innerHTML='';
  document.getElementById('rz-start-panel').style.display='flex';
}

document.addEventListener('keydown',e=>{
  if(!state.running) return;
  const map={d:0,f:1,j:2,k:3};
  if(map[e.key.toLowerCase()]!==undefined) rzTap(map[e.key.toLowerCase()]);
});

requestAnimationFrame(function loop(){draw3D();if(!state.running)requestAnimationFrame(loop);});


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paciente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/juegos/ritmo_zen.blade.php ENDPATH**/ ?>