<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Miniminds'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #C4B5E8 0%, #D8D0F0 50%, #E8D5F0 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            color: #4A4063;
            margin: 0;
        }

        
        .pt-topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 28px;
            background: rgba(255,255,255,0.35);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .pt-topbar .brand { font-weight: 800; font-size: 19px; color: #4A4063; text-decoration: none; }
        .pt-topbar .greeting { font-size: 14px; color: #6b6280; }
        .pt-topbar .icons { display: flex; align-items: center; gap: 16px; font-size: 16px; color: #6b6280; }
        .pt-topbar .icons a { color: #6b6280; text-decoration: none; }
        .pt-topbar .icons img.avatar {
            width: 30px; height: 30px; border-radius: 50%; object-fit: cover;
            border: 2px solid #fff;
        }

        .notif-dot {
            position: absolute; top: -4px; right: -6px; background: #E0576B; color: #fff;
            font-size: 10px; font-weight: 700; border-radius: 50%; width: 16px; height: 16px;
            display: flex; align-items: center; justify-content: center;
        }
        .notif-dropdown {
            display: none; position: absolute; right: 0; top: 34px; width: 320px;
            background: #fff; border-radius: 14px; box-shadow: 0 8px 30px rgba(0,0,0,.15);
            z-index: 200; max-height: 360px; overflow-y: auto;
        }
        .notif-dropdown.open { display: block; }
        .notif-item { display: block; padding: 12px 16px; border-bottom: 1px solid #f0f0f0; text-decoration: none; color: #4A4063; }
        .notif-item:hover { background: #f7f3fd; }
        .notif-item .titulo { font-weight: 700; font-size: 13px; }
        .notif-item .msg { font-size: 12px; color: #6b6280; }
        .notif-empty { padding: 18px; text-align: center; color: #9a8fb8; font-size: 13px; }

        
        .pt-shell {
            display: flex;
            min-height: calc(100vh - 60px);
        }

        
        .pt-sidebar {
            width: 210px;
            flex-shrink: 0;
            background: rgba(255,255,255,0.28);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255,255,255,0.4);
            padding: 22px 0;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .pt-sidebar a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 24px;
            color: #6b6280;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
            border-left: 3px solid transparent;
            transition: background 0.15s, color 0.15s;
        }
        .pt-sidebar a i { width: 18px; text-align: center; }
        .pt-sidebar a:hover { background: rgba(255,255,255,0.4); color: #4A4063; }
        .pt-sidebar a.active {
            background: rgba(255,255,255,0.55);
            color: #4A4063;
            border-left-color: #F5A623;
            font-weight: 700;
        }
        .pt-sidebar .pt-sidebar-section {
            margin-top: 18px;
            padding: 0 24px 6px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #9a8fb8;
        }
        .pt-sidebar .badge-pill {
            background: #E0576B; color: #fff; font-size: 10px; font-weight: 700;
            border-radius: 10px; padding: 1px 7px; margin-left: auto;
        }

        
        .pt-main {
            flex: 1;
            padding: 32px 36px;
        }

        
        .pt-card {
            background: rgba(255,255,255,0.65);
            backdrop-filter: blur(10px);
            border: none;
            border-radius: 18px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        .btn-acento {
            background-color: #F5A623;
            color: white;
            border: none;
            border-radius: 20px;
            padding: 8px 22px;
            font-weight: 600;
        }
        .btn-acento:hover { background-color: #e09520; color: white; }

        @media (max-width: 768px) {
            .pt-sidebar { display: none; }
        }
    </style>
    <?php echo $__env->yieldContent('extra_styles'); ?>
</head>
<body>

    <div class="pt-topbar">
        <a class="brand" href="<?php echo e(route('paciente.inicio')); ?>">Miniminds!</a>
        <span class="greeting">¡Bienvenido/a, <?php echo e(auth()->check() ? auth()->user()->name : 'invitado'); ?>!</span>
        <div class="icons">
            <div style="position:relative">
                <a href="#" onclick="event.preventDefault(); document.getElementById('notif-dropdown').classList.toggle('open')">
                    <i class="fas fa-bell"></i>
                    <?php if(auth()->check() && auth()->user()->unreadNotifications->count()): ?>
                        <span class="notif-dot"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                    <?php endif; ?>
                </a>
                <div class="notif-dropdown" id="notif-dropdown">
                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications()->latest()->limit(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('paciente.avisos.index')); ?>" class="notif-item" style="<?php echo e($n->read_at ? 'opacity:.55' : ''); ?>">
                            <div class="titulo"><?php echo e($n->data['titulo'] ?? 'Notificación'); ?></div>
                            <div class="msg"><?php echo e($n->data['mensaje'] ?? ''); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="notif-empty">No tienes notificaciones.</div>
                    <?php endif; ?>
                </div>
            </div>
            <a href="#"><i class="fas fa-cog"></i></a>
            <a href="<?php echo e(route('paciente.perfil')); ?>">
                <?php if(auth()->check() && auth()->user()->foto): ?>
                    <img class="avatar" src="<?php echo e(asset('storage/' . auth()->user()->foto)); ?>" alt="Foto de perfil">
                <?php else: ?>
                    <i class="fas fa-user-circle fa-lg"></i>
                <?php endif; ?>
            </a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin:0">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background:none;border:none;color:#6b6280;font-size:16px;cursor:pointer" title="Cerrar sesión"><i class="fas fa-right-from-bracket"></i></button>
            </form>
        </div>
    </div>

    <div class="pt-shell">
        <div class="pt-sidebar">
            <a href="<?php echo e(route('paciente.inicio')); ?>" class="<?php echo e(request()->routeIs('paciente.inicio') ? 'active' : ''); ?>">
                <i class="fas fa-house"></i> Inicio
            </a>
            <a href="<?php echo e(route('paciente.citas')); ?>" class="<?php echo e(request()->routeIs('paciente.citas') ? 'active' : ''); ?>">
                <i class="fas fa-calendar-check"></i> Citas
            </a>
            <a href="<?php echo e(route('paciente.calendario')); ?>" class="<?php echo e(request()->routeIs('paciente.calendario') ? 'active' : ''); ?>">
                <i class="fas fa-calendar-days"></i> Calendario
            </a>
            <a href="<?php echo e(route('paciente.agenda')); ?>" class="<?php echo e(request()->routeIs('paciente.agenda') ? 'active' : ''); ?>">
                <i class="fas fa-list-check"></i> Agenda
            </a>

            <div class="pt-sidebar-section">Comunidad</div>
            <a href="<?php echo e(route('experiencias.index')); ?>" class="<?php echo e(request()->routeIs('experiencias.*') ? 'active' : ''); ?>">
                <i class="fas fa-comments"></i> Experiencias
            </a>
            <a href="<?php echo e(route('paciente.avisos.index')); ?>" class="<?php echo e(request()->routeIs('paciente.avisos.*') ? 'active' : ''); ?>">
                <i class="fas fa-envelope"></i> Mis avisos
                <?php if(auth()->check() && auth()->user()->unreadNotifications->count()): ?>
                    <span class="badge-pill"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                <?php endif; ?>
            </a>

            <div class="pt-sidebar-section">Recursos</div>
            <a href="<?php echo e(route('juegos.index')); ?>" class="<?php echo e(request()->routeIs('juegos.*') ? 'active' : ''); ?>">
                <i class="fas fa-gamepad"></i> Juegos
            </a>
            <a href="<?php echo e(route('paciente.cerebro')); ?>" class="<?php echo e(request()->routeIs('paciente.cerebro') ? 'active' : ''); ?>">
                <i class="fas fa-brain"></i> Mi Cerebro 3D
            </a>
            <a href="<?php echo e(route('paciente.recursos')); ?>" class="<?php echo e(request()->routeIs('paciente.recursos') ? 'active' : ''); ?>">
                <i class="fas fa-book-open"></i> Recursos
            </a>

            <div class="pt-sidebar-section">Mi cuenta</div>
            <a href="<?php echo e(route('paciente.solicitudes.index')); ?>" class="<?php echo e(request()->routeIs('paciente.solicitudes.*') ? 'active' : ''); ?>">
                <i class="fas fa-file-medical"></i> Mis solicitudes
            </a>
            <a href="<?php echo e(route('paciente.solicitud_especialista.index')); ?>" class="<?php echo e(request()->routeIs('paciente.solicitud_especialista.*') ? 'active' : ''); ?>">
                <i class="fas fa-user-graduate"></i> Ser especialista
            </a>
        </div>

        <div class="pt-main">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('extra_scripts'); ?>
</body>
</html><?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/layouts/paciente.blade.php ENDPATH**/ ?>