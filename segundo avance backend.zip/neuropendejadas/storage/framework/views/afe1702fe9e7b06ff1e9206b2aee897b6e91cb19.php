<?php $__env->startSection('title','El Gran Orden — Miniminds'); ?>
<?php $__env->startSection('extra_styles'); ?>
<style>
*{margin:0;padding:0;box-sizing:border-box}
#go-wrap{min-height:calc(100vh - 60px);background:linear-gradient(160deg,#0f172a 0%,#1e1b4b 50%,#0f172a 100%);font-family:'Segoe UI',sans-serif;color:#fff;display:flex;flex-direction:column;align-items:center;padding:24px 16px}

.go-screen{width:100%;max-width:780px;display:none;flex-direction:column;align-items:center;gap:20px;animation:goFade .35s ease}
.go-screen.active{display:flex}
@keyframes  goFade{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}

#go-intro h1{font-size:40px;font-weight:900;text-align:center;background:linear-gradient(135deg,#818cf8,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
#go-intro p{text-align:center;font-size:15px;opacity:.75;max-width:480px;line-height:1.7}
.go-preview{display:flex;gap:14px;flex-wrap:wrap;justify-content:center;margin:10px 0}
.go-preview-card{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:14px;padding:14px 20px;text-align:center;font-size:13px;opacity:.8}
.go-preview-card .ico{font-size:28px;margin-bottom:4px}
.go-start-btn{padding:16px 48px;border-radius:50px;border:none;background:linear-gradient(135deg,#4f46e5,#818cf8);color:#fff;font-size:17px;font-weight:800;cursor:pointer;box-shadow:0 8px 32px rgba(79,70,229,.4);transition:transform .1s}
.go-start-btn:hover{transform:scale(1.04)}

.go-hud{width:100%;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
.go-hud-box{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:14px;padding:10px 20px;text-align:center;min-width:90px}
.go-hud-box .lbl{font-size:11px;opacity:.6;text-transform:uppercase;letter-spacing:.5px}
.go-hud-box .val{font-size:22px;font-weight:800;color:#818cf8}
#go-timer-val{color:#38bdf8}
#go-timer-val.warn{color:#fbbf24;animation:blink .5s infinite}
@keyframes  blink{0%,100%{opacity:1}50%{opacity:.4}}

.go-scene{width:100%;background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.12);border-radius:22px;padding:20px;position:relative;min-height:280px}
.go-scene-title{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;opacity:.55;margin-bottom:14px;display:flex;align-items:center;gap:8px}

.go-chaos-zone{display:flex;flex-wrap:wrap;gap:12px;min-height:120px;padding:12px;border-radius:14px;border:2px dashed rgba(255,255,255,.15);background:rgba(0,0,0,.15);position:relative;transition:border-color .2s}
.go-chaos-zone.drag-over{border-color:#818cf8;background:rgba(129,140,248,.06)}

.go-zones{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;width:100%}
.go-drop-zone{border-radius:16px;border:2px dashed rgba(255,255,255,.2);background:rgba(255,255,255,.04);padding:12px;min-height:110px;transition:all .25s;display:flex;flex-direction:column;gap:8px}
.go-drop-zone .dz-label{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;opacity:.6;display:flex;align-items:center;gap:6px;margin-bottom:4px}
.go-drop-zone.drag-over{border-color:#818cf8;background:rgba(129,140,248,.1);transform:scale(1.02)}
.go-drop-zone.complete{border-color:#34d399;background:rgba(52,211,153,.08)}

.go-item{display:inline-flex;align-items:center;gap:8px;padding:9px 14px;border-radius:12px;font-size:13px;font-weight:700;cursor:grab;user-select:none;transition:transform .15s,box-shadow .15s;border:1.5px solid rgba(255,255,255,.15);white-space:nowrap}
.go-item:hover{transform:scale(1.06);box-shadow:0 6px 24px rgba(0,0,0,.3)}
.go-item.dragging{opacity:.45;transform:scale(.95)}
.go-item.correct{animation:correctPop .4s ease;border-color:#34d399!important}
.go-item.wrong{animation:wrongShake .4s ease}
@keyframes  correctPop{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}
@keyframes  wrongShake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}

.go-float{position:fixed;top:40%;left:50%;transform:translate(-50%,-50%);font-size:28px;font-weight:900;pointer-events:none;opacity:0;transition:all .3s;z-index:999;text-shadow:0 0 30px currentColor}
.go-float.show{opacity:1;top:36%}

.go-level-complete{background:rgba(52,211,153,.1);border:1.5px solid #34d399;border-radius:18px;padding:24px 32px;text-align:center;width:100%;display:none}
.go-level-complete h3{font-size:22px;font-weight:800;color:#34d399;margin-bottom:8px}
.go-level-complete p{opacity:.75;font-size:14px;margin-bottom:16px}
.go-next-btn{padding:12px 32px;border-radius:50px;border:none;background:linear-gradient(135deg,#4f46e5,#818cf8);color:#fff;font-size:15px;font-weight:700;cursor:pointer}

#go-end h2{font-size:34px;font-weight:900;text-align:center;background:linear-gradient(135deg,#818cf8,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.go-stats{display:flex;gap:16px;flex-wrap:wrap;justify-content:center}
.go-stat{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.13);border-radius:16px;padding:16px 24px;text-align:center}
.go-stat .sv{font-size:26px;font-weight:900;color:#818cf8}
.go-stat .sl{font-size:12px;opacity:.6;text-transform:uppercase;letter-spacing:.4px}
.go-tip{background:rgba(56,189,248,.08);border:1.5px solid #38bdf8;border-radius:14px;padding:16px 22px;font-size:14px;color:#7dd3fc;line-height:1.6;max-width:520px;text-align:center}
.go-end-btns{display:flex;gap:12px;flex-wrap:wrap;justify-content:center}
.go-end-btns button{padding:13px 28px;border-radius:50px;border:none;font-size:14px;font-weight:700;cursor:pointer}
.go-btn-replay{background:linear-gradient(135deg,#4f46e5,#818cf8);color:#fff}
.go-btn-back{background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2)!important}

.go-level-dots{display:flex;gap:8px;justify-content:center}
.go-ld{width:10px;height:10px;border-radius:50%;background:rgba(255,255,255,.2);transition:background .3s}
.go-ld.done{background:#34d399}
.go-ld.active{background:#818cf8}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="go-wrap">

  
  <div class="go-screen active" id="go-intro">
    <div style="font-size:60px;text-align:center">🧩</div>
    <h1>El Gran Orden</h1>
    <p>Todo está mezclado y necesitas encontrar el lugar correcto de cada cosa.<br>
    Arrastra cada objeto a donde pertenece antes de que se acabe el tiempo.</p>
    <div class="go-preview">
      <div class="go-preview-card"><div class="ico">🎒</div>Mochila escolar</div>
      <div class="go-preview-card"><div class="ico">🛏️</div>Cuarto</div>
      <div class="go-preview-card"><div class="ico">🍽️</div>Cocina</div>
      <div class="go-preview-card"><div class="ico">🛁</div>Baño</div>
    </div>
    <p style="font-size:13px;opacity:.55">Tip: Puedes arrastrar o hacer clic para seleccionar y luego clic en la zona destino</p>
    <button class="go-start-btn" onclick="goStart()">¡A ordenar todo!</button>
  </div>

  
  <div class="go-screen" id="go-game">
    <div class="go-hud">
      <div class="go-hud-box"><div class="lbl">Nivel</div><div class="val" id="go-level-val">1</div></div>
      <div class="go-hud-box"><div class="lbl">Puntos</div><div class="val" id="go-score-val">0</div></div>
      <div class="go-hud-box"><div class="lbl">Tiempo</div><div class="val" id="go-timer-val">60</div></div>
      <div class="go-hud-box"><div class="lbl">Correctos</div><div class="val" id="go-correct-val" style="color:#34d399">0</div></div>
    </div>

    <div class="go-level-dots" id="go-dots"></div>

    <div class="go-scene">
      <div class="go-scene-title">🌀 Todo mezclado — arrastra cada cosa a donde pertenece</div>
      <div class="go-chaos-zone" id="go-chaos"></div>
    </div>

    <div class="go-zones" id="go-zones"></div>

    <div class="go-level-complete" id="go-lvl-complete">
      <h3 id="go-lvl-msg">¡Nivel completado! 🎉</h3>
      <p id="go-lvl-sub">Muy bien organizado</p>
      <button class="go-next-btn" onclick="goNextLevel()">Siguiente nivel →</button>
    </div>
  </div>

  
  <div class="go-screen" id="go-end">
    <div style="font-size:64px;text-align:center">🏆</div>
    <h2>¡Todo ordenado!</h2>
    <div class="go-stats">
      <div class="go-stat"><div class="sv" id="go-end-score">0</div><div class="sl">Puntos</div></div>
      <div class="go-stat"><div class="sv" id="go-end-correct">0</div><div class="sl">Correctos</div></div>
      <div class="go-stat"><div class="sv" id="go-end-lvls">0</div><div class="sl">Niveles</div></div>
    </div>
    <div class="go-tip" id="go-end-tip"></div>
    <div class="go-end-btns">
      <button class="go-btn-replay" onclick="goStart()">Volver a jugar</button>
      <button class="go-btn-back" onclick="location.href='<?php echo e(route('juegos.index')); ?>'">Otros juegos</button>
    </div>
  </div>

</div>

<div class="go-float" id="go-float"></div>

<script>
const LEVELS = [
  {
    name: 'La mochila escolar',
    time: 60,
    tip: 'Organizar tu mochila cada noche te ayuda a sentirte más tranquilo/a por la mañana.',
    zones: [
      {id:'libros', label:'📚 Libros y cuadernos', color:'#818cf8'},
      {id:'utiles', label:'✏️ Útiles', color:'#38bdf8'},
      {id:'lonchera', label:'🥪 Lonchera', color:'#34d399'},
    ],
    items: [
      {id:'cuaderno',   emoji:'📓', label:'Cuaderno',    zone:'libros'},
      {id:'libro',      emoji:'📕', label:'Libro',       zone:'libros'},
      {id:'lapiz',      emoji:'✏️',  label:'Lápiz',       zone:'utiles'},
      {id:'regla',      emoji:'📏', label:'Regla',       zone:'utiles'},
      {id:'tijeras',    emoji:'✂️',  label:'Tijeras',     zone:'utiles'},
      {id:'sandwich',   emoji:'🥪', label:'Sandwich',    zone:'lonchera'},
      {id:'manzana',    emoji:'🍎', label:'Manzana',     zone:'lonchera'},
      {id:'borrador',   emoji:'🧹', label:'Borrador',    zone:'utiles'},
      {id:'colores',    emoji:'🖍️', label:'Colores',     zone:'utiles'},
    ]
  },
  {
    name: 'El cuarto',
    time: 70,
    tip: 'Un cuarto ordenado ayuda al cerebro a calmarse y concentrarse mejor antes de dormir.',
    zones: [
      {id:'cama',     label:'🛏️ En la cama',      color:'#a78bfa'},
      {id:'closet',   label:'👕 En el closet',    color:'#f9a8d4'},
      {id:'escritorio', label:'🖥️ Escritorio',   color:'#fbbf24'},
      {id:'juguetes', label:'🧸 Juguetes',        color:'#34d399'},
    ],
    items: [
      {id:'almohada',   emoji:'🛌', label:'Almohada',   zone:'cama'},
      {id:'cobija',     emoji:'🧣', label:'Cobija',     zone:'cama'},
      {id:'camisa',     emoji:'👕', label:'Camisa',     zone:'closet'},
      {id:'zapatos',    emoji:'👟', label:'Zapatos',    zone:'closet'},
      {id:'lapicero',   emoji:'🖊️', label:'Lapicero',   zone:'escritorio'},
      {id:'tarea',      emoji:'📄', label:'Tarea',      zone:'escritorio'},
      {id:'osito',      emoji:'🧸', label:'Osito',      zone:'juguetes'},
      {id:'lego',       emoji:'🧱', label:'Legos',      zone:'juguetes'},
      {id:'rompecabezas',emoji:'🧩',label:'Puzzle',     zone:'juguetes'},
      {id:'pantalon',   emoji:'👖', label:'Pantalón',   zone:'closet'},
    ]
  },
  {
    name: 'La cocina',
    time: 75,
    tip: 'Ayudar en casa a ordenar nos hace sentir útiles y parte del equipo familiar.',
    zones: [
      {id:'nevera',   label:'🧊 Nevera',         color:'#38bdf8'},
      {id:'alacena',  label:'🫙 Alacena',        color:'#f97316'},
      {id:'fregadero',label:'🚿 Fregadero',      color:'#34d399'},
      {id:'mesa',     label:'🍽️ Mesa',           color:'#fbbf24'},
    ],
    items: [
      {id:'leche',    emoji:'🥛', label:'Leche',        zone:'nevera'},
      {id:'jugo',     emoji:'🧃', label:'Jugo',         zone:'nevera'},
      {id:'queso',    emoji:'🧀', label:'Queso',        zone:'nevera'},
      {id:'arroz',    emoji:'🍚', label:'Arroz',        zone:'alacena'},
      {id:'frijoles', emoji:'🫘', label:'Frijoles',     zone:'alacena'},
      {id:'vaso',     emoji:'🥤', label:'Vaso sucio',   zone:'fregadero'},
      {id:'plato',    emoji:'🍽️', label:'Plato sucio',  zone:'fregadero'},
      {id:'tenedor',  emoji:'🍴', label:'Tenedor',      zone:'mesa'},
      {id:'sal',      emoji:'🧂', label:'Sal',          zone:'alacena'},
      {id:'manzana2', emoji:'🍎', label:'Manzana',      zone:'nevera'},
    ]
  },
  {
    name: 'El baño',
    time: 65,
    tip: 'Mantener el baño ordenado es un acto de cuidado hacia ti mismo/a y tu familia.',
    zones: [
      {id:'ducha',    label:'🚿 Ducha',          color:'#38bdf8'},
      {id:'lavabo',   label:'🪥 Lavabo',         color:'#818cf8'},
      {id:'botiquin', label:'💊 Botiquín',       color:'#f87171'},
      {id:'toallero', label:'🧺 Toallero',       color:'#34d399'},
    ],
    items: [
      {id:'shampoo',  emoji:'🧴', label:'Shampoo',      zone:'ducha'},
      {id:'esponja',  emoji:'🧽', label:'Esponja',      zone:'ducha'},
      {id:'jabon',    emoji:'🧼', label:'Jabón',        zone:'lavabo'},
      {id:'cepillo',  emoji:'🪥', label:'Cepillo',      zone:'lavabo'},
      {id:'pasta',    emoji:'🦷', label:'Pasta dental', zone:'lavabo'},
      {id:'curitas',  emoji:'🩹', label:'Curitas',      zone:'botiquin'},
      {id:'medicina', emoji:'💊', label:'Medicina',     zone:'botiquin'},
      {id:'toalla1',  emoji:'🧻', label:'Toalla',       zone:'toallero'},
      {id:'toalla2',  emoji:'🧣', label:'Paño de manos',zone:'toallero'},
    ]
  },
];

const TIPS_GENERAL = [
  'Ordenar un poco cada día evita que el desorden se acumule y abrume.',
  'Cuando todo tiene su lugar, es más fácil encontrar las cosas y sentirse tranquilo/a.',
  'El orden externo ayuda a crear orden interno — ¡tu mente lo agradece!',
];

let gState = {
  level:0, score:0, correctTotal:0, levelsCompleted:0,
  timer:60, timerInterval:null,
  correctInLevel:0, totalInLevel:0,
  dragItem:null, selectedItem:null,
};

function goStart(){
  gState={level:0,score:0,correctTotal:0,levelsCompleted:0,timer:60,timerInterval:null,correctInLevel:0,totalInLevel:0,dragItem:null,selectedItem:null};
  document.getElementById('go-score-val').textContent='0';
  document.getElementById('go-correct-val').textContent='0';
  showGoScreen('go-game');
  buildLevelDots();
  loadLevel();
}

function buildLevelDots(){
  const c=document.getElementById('go-dots');
  c.innerHTML='';
  LEVELS.forEach((_,i)=>{
    const d=document.createElement('div');
    d.className='go-ld'+(i===0?' active':'');
    d.id='gd-'+i;
    c.appendChild(d);
  });
}

function updateDots(){
  LEVELS.forEach((_,i)=>{
    const d=document.getElementById('gd-'+i);
    if(!d) return;
    d.className='go-ld'+(i<gState.level?' done':i===gState.level?' active':'');
  });
}

function loadLevel(){
  const lv=LEVELS[gState.level];
  document.getElementById('go-level-val').textContent=gState.level+1;
  document.getElementById('go-lvl-complete').style.display='none';
  gState.correctInLevel=0;
  gState.totalInLevel=lv.items.length;
  gState.timer=lv.time;
  updateTimerDisplay();
  updateDots();

  
  const chaos=document.getElementById('go-chaos');
  chaos.innerHTML='';
  const shuffled=[...lv.items].sort(()=>Math.random()-.5);
  shuffled.forEach(item=>chaos.appendChild(buildItem(item, lv)));

  
  const zones=document.getElementById('go-zones');
  zones.innerHTML='';
  lv.zones.forEach(z=>{
    const div=document.createElement('div');
    div.className='go-drop-zone';
    div.id='zone-'+z.id;
    div.innerHTML=`<div class="dz-label" style="color:${z.color}">${z.label}</div>`;
    div.style.borderColor=z.color+'44';

    div.addEventListener('dragover',e=>{e.preventDefault();div.classList.add('drag-over')});
    div.addEventListener('dragleave',()=>div.classList.remove('drag-over'));
    div.addEventListener('drop',e=>{
      e.preventDefault();
      div.classList.remove('drag-over');
      if(gState.dragItem) dropItem(gState.dragItem, z.id);
    });
    div.addEventListener('click',()=>{
      if(gState.selectedItem) dropItem(gState.selectedItem, z.id);
    });
    zones.appendChild(div);
  });

  
  chaos.addEventListener('dragover',e=>{e.preventDefault();chaos.classList.add('drag-over')});
  chaos.addEventListener('dragleave',()=>chaos.classList.remove('drag-over'));
  chaos.addEventListener('drop',e=>{e.preventDefault();chaos.classList.remove('drag-over')});

  startTimer();
}

function buildItem(item, lv){
  const el=document.createElement('div');
  el.className='go-item';
  el.id='item-'+item.id;
  el.draggable=true;
  const zone=lv.zones.find(z=>z.id===item.zone);
  el.style.background=zone?zone.color+'22':'rgba(255,255,255,.08)';
  el.style.borderColor=zone?zone.color+'55':'rgba(255,255,255,.15)';
  el.innerHTML=`<span style="font-size:20px">${item.emoji}</span><span>${item.label}</span>`;
  el.dataset.zone=item.zone;
  el.dataset.id=item.id;

  el.addEventListener('dragstart',()=>{
    gState.dragItem=item;
    el.classList.add('dragging');
    if(gState.selectedItem===item){gState.selectedItem=null;el.style.outline=''}
  });
  el.addEventListener('dragend',()=>{
    el.classList.remove('dragging');
    gState.dragItem=null;
  });
  el.addEventListener('click',()=>{
    if(gState.selectedItem===item){
      gState.selectedItem=null;
      el.style.outline='';
    } else {
      if(gState.selectedItem){
        const prev=document.getElementById('item-'+gState.selectedItem.id);
        if(prev) prev.style.outline='';
      }
      gState.selectedItem=item;
      el.style.outline='2px solid #818cf8';
      el.style.outlineOffset='2px';
    }
  });
  return el;
}

function dropItem(item, zoneId){
  const el=document.getElementById('item-'+item.id);
  if(!el) return;
  if(item.zone===zoneId){
    
    const zone=document.getElementById('zone-'+zoneId);
    el.classList.add('correct');
    el.style.outline='';
    el.draggable=false;
    el.style.cursor='default';
    el.onclick=null;
    zone.appendChild(el);
    gState.correctInLevel++;
    gState.correctTotal++;
    gState.score+=80+Math.floor(gState.timer*0.5);
    document.getElementById('go-score-val').textContent=gState.score;
    document.getElementById('go-correct-val').textContent=gState.correctTotal;
    showFloat('¡Correcto! ✨','#34d399');
    if(zone.querySelectorAll('.go-item').length===LEVELS[gState.level].items.filter(i=>i.zone===zoneId).length){
      zone.classList.add('complete');
    }
    if(gState.correctInLevel>=gState.totalInLevel) setTimeout(showLevelComplete,400);
  } else {
    el.classList.add('wrong');
    showFloat('Intenta otra vez 🤔','#fbbf24');
    setTimeout(()=>el.classList.remove('wrong'),400);
    gState.score=Math.max(0,gState.score-10);
    document.getElementById('go-score-val').textContent=gState.score;
  }
  gState.selectedItem=null;
  if(el) el.style.outline='';
  gState.dragItem=null;
}

function showLevelComplete(){
  clearInterval(gState.timerInterval);
  gState.levelsCompleted++;
  const lv=LEVELS[gState.level];
  const compl=document.getElementById('go-lvl-complete');
  const isLast=gState.level>=LEVELS.length-1;
  compl.querySelector('h3').textContent=isLast?'🏆 ¡Completaste todos los niveles!':'🎉 ¡Nivel completado!';
  compl.querySelector('p').textContent=lv.tip;
  compl.querySelector('button').textContent=isLast?'Ver mi resultado':'Siguiente nivel →';
  compl.querySelector('button').onclick=isLast?goEnd:goNextLevel;
  compl.style.display='block';
  compl.scrollIntoView({behavior:'smooth',block:'center'});
}

function goNextLevel(){
  gState.level++;
  if(gState.level>=LEVELS.length){goEnd();return;}
  document.getElementById('go-lvl-complete').style.display='none';
  loadLevel();
  window.scrollTo({top:0,behavior:'smooth'});
}

function goEnd(){
  clearInterval(gState.timerInterval);
  document.getElementById('go-end-score').textContent=gState.score;
  document.getElementById('go-end-correct').textContent=gState.correctTotal;
  document.getElementById('go-end-lvls').textContent=gState.levelsCompleted;
  const tip=gState.correctTotal>25?TIPS_GENERAL[2]:gState.correctTotal>15?TIPS_GENERAL[1]:TIPS_GENERAL[0];
  document.getElementById('go-end-tip').textContent='💡 '+tip;
  showGoScreen('go-end');
}

function startTimer(){
  clearInterval(gState.timerInterval);
  gState.timerInterval=setInterval(()=>{
    gState.timer--;
    updateTimerDisplay();
    if(gState.timer<=10) document.getElementById('go-timer-val').classList.add('warn');
    else document.getElementById('go-timer-val').classList.remove('warn');
    if(gState.timer<=0){
      clearInterval(gState.timerInterval);
      
      showFloat('⏰ ¡Tiempo!','#f87171');
      setTimeout(()=>{
        gState.score=Math.max(0,gState.score-30);
        document.getElementById('go-score-val').textContent=gState.score;
        showLevelComplete();
      },800);
    }
  },1000);
}

function updateTimerDisplay(){
  document.getElementById('go-timer-val').textContent=gState.timer;
}

let floatTimer;
function showFloat(txt,color){
  const el=document.getElementById('go-float');
  el.textContent=txt; el.style.color=color;
  el.classList.add('show');
  clearTimeout(floatTimer);
  floatTimer=setTimeout(()=>el.classList.remove('show'),700);
}

function showGoScreen(id){
  document.querySelectorAll('.go-screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.paciente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/juegos/el_gran_orden.blade.php ENDPATH**/ ?>