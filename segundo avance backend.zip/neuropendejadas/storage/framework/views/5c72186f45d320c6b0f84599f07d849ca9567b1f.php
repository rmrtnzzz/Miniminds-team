<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contáctanos — Miniminds</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{
            font-family:'Nunito',sans-serif;
            background:linear-gradient(135deg,#C4B5E8 0%,#D8D0F0 50%,#E8D5F0 100%);
            min-height:100vh;
            color:#4A4063;
        }
        nav{
            display:flex;align-items:center;justify-content:space-between;
            padding:16px 40px;background:rgba(255,255,255,0.55);backdrop-filter:blur(10px);
            border-bottom:1px solid rgba(255,255,255,0.5);
        }
        nav a.brand{font-weight:900;font-size:1.3rem;color:#4A4063;text-decoration:none}
        nav .nav-actions a{
            text-decoration:none;font-weight:700;font-size:.85rem;
            padding:9px 20px;border-radius:20px;margin-left:8px;
        }
        nav .btn-ghost{color:#6b6280}
        nav .btn-solid{background:#7C5CBF;color:#fff}

        .wrap{max-width:960px;margin:0 auto;padding:56px 24px 80px}
        .header-block{text-align:center;margin-bottom:40px}
        .header-block h1{font-size:2.2rem;font-weight:900;margin-bottom:10px}
        .header-block p{color:#6b6280;font-size:1.05rem}

        .grid{display:grid;grid-template-columns:1fr 1fr;gap:28px}
        @media (max-width:800px){.grid{grid-template-columns:1fr}}

        .card{
            background:rgba(255,255,255,0.7);backdrop-filter:blur(10px);
            border-radius:20px;padding:32px;box-shadow:0 8px 30px rgba(0,0,0,0.08);
        }
        .card h3{font-weight:800;margin-bottom:18px;font-size:1.15rem}

        label{font-size:12px;font-weight:700;color:#9a8fb8;text-transform:uppercase;
            letter-spacing:.04em;display:block;margin-bottom:6px;margin-top:14px}
        label:first-of-type{margin-top:0}
        input,textarea{
            width:100%;padding:12px 14px;border:1.5px solid #e2d8f5;border-radius:12px;
            font-size:14px;color:#4A4063;background:#faf8ff;outline:none;font-family:inherit;
        }
        input:focus,textarea:focus{border-color:#C4B5E8}
        textarea{resize:vertical;min-height:120px}

        .btn-acento{
            margin-top:20px;background:#F5A623;color:#fff;border:none;border-radius:22px;
            padding:12px 30px;font-weight:700;font-size:14px;cursor:pointer;width:100%;
        }
        .btn-acento:hover{background:#e09520}

        .alert{padding:12px 18px;border-radius:12px;margin-bottom:18px;font-weight:600;font-size:14px}
        .alert-success{background:#DDF3E4;color:#1F9254}
        .alert-error{background:#FBDDE3;color:#C23A52}

        .info-item{display:flex;gap:14px;align-items:flex-start;margin-bottom:22px}
        .info-item i{
            width:38px;height:38px;flex-shrink:0;border-radius:50%;background:#EDE8F8;
            color:#7C5CBF;display:flex;align-items:center;justify-content:center;
        }
        .info-item div span{display:block;font-size:12px;color:#9a8fb8;font-weight:700;
            text-transform:uppercase;letter-spacing:.03em;margin-bottom:2px}
        .info-item div p{font-size:14px;color:#4A4063}

        footer{text-align:center;padding:24px;color:#6b6280;font-size:13px}
        footer a{color:#7C5CBF;text-decoration:none;font-weight:700}
    </style>
</head>
<body>

<nav>
    <a class="brand" href="<?php echo e(route('home')); ?>">Miniminds!</a>
    <div class="nav-actions">
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('paciente.inicio')); ?>" class="btn-solid">Mi Panel</a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn-ghost">Iniciar sesión</a>
            <a href="<?php echo e(route('register')); ?>" class="btn-solid">Registrarse</a>
        <?php endif; ?>
    </div>
</nav>

<div class="wrap">
    <div class="header-block">
        <h1>📬 Contáctanos</h1>
        <p>¿Tienes dudas o quieres saber más sobre Miniminds? Escríbenos, te responderemos pronto.</p>
    </div>

    <div class="grid">
        <div class="card">
            <h3>Envíanos un mensaje</h3>

            <?php if(session('success')): ?>
                <div class="alert alert-success">✅ <?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-error">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div>• <?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('contacto.enviar')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div style="display:flex;gap:14px">
                    <div style="flex:1">
                        <label>Nombre</label>
                        <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" required>
                    </div>
                    <div style="flex:1">
                        <label>Apellido</label>
                        <input type="text" name="apellido" value="<?php echo e(old('apellido')); ?>" required>
                    </div>
                </div>

                <label>Correo electrónico</label>
                <input type="email" name="correo" value="<?php echo e(old('correo')); ?>" required>

                <label>Teléfono (opcional)</label>
                <input type="text" name="telefono" value="<?php echo e(old('telefono')); ?>">

                <label>Mensaje</label>
                <textarea name="mensaje" required><?php echo e(old('mensaje')); ?></textarea>

                <button type="submit" class="btn-acento">Enviar mensaje</button>
            </form>
        </div>

        <div class="card">
            <h3>Información de contacto</h3>

            <div class="info-item">
                <i class="fas fa-envelope"></i>
                <div>
                    <span>Correo</span>
                    <p>minimindssv@gmail.com</p>
                </div>
            </div>

            <div class="info-item">
                <i class="fas fa-map-marker-alt"></i>
                <div>
                    <span>Ubicación</span>
                    <p>San Salvador, El Salvador</p>
                </div>
            </div>

            <div class="info-item">
                <i class="fas fa-clock"></i>
                <div>
                    <span>Horario de atención</span>
                    <p>Lunes a viernes, 8:00 a.m. — 5:00 p.m.</p>
                </div>
            </div>

            <div class="info-item">
                <i class="fas fa-gamepad"></i>
                <div>
                    <span>¿Sabías que...?</span>
                    <p>También puedes explorar nuestros <a href="<?php echo e(route('juegos.index')); ?>" style="color:#7C5CBF;font-weight:700">juegos gratuitos</a> sin necesidad de crear una cuenta.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<footer>
    Miniminds — Apoyo a infancias adaptativas · <a href="<?php echo e(route('home')); ?>">Volver al inicio</a>
</footer>

</body>
</html>
<?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/contacto.blade.php ENDPATH**/ ?>