<?php $__env->startSection('title','Juegos Terapéuticos — Miniminds'); ?>
<?php $__env->startSection('extra_styles'); ?>
<style>
.jg-header{text-align:center;margin-bottom:32px}
.jg-header h2{font-size:30px;font-weight:900;color:#4A4063;margin-bottom:6px}
.jg-header p{color:#9a8fb8;font-size:15px}
.jg-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:22px}
.jg-card{border-radius:22px;overflow:hidden;text-decoration:none;color:inherit;display:flex;flex-direction:column;transition:transform .2s,box-shadow .2s;background:#fff;box-shadow:0 4px 20px rgba(0,0,0,.07)}
.jg-card:hover{transform:translateY(-5px);box-shadow:0 12px 40px rgba(0,0,0,.13)}
.jg-card-img{height:150px;display:flex;align-items:center;justify-content:center;font-size:70px;position:relative}
.jg-card-body{padding:18px 20px 22px}
.jg-card-body h3{font-size:17px;font-weight:800;color:#3b3063;margin-bottom:6px}
.jg-card-body p{font-size:13px;color:#9a8fb8;line-height:1.5;margin-bottom:12px}
.jg-badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;margin-right:4px;margin-bottom:4px}
.jg-play-btn{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border-radius:50px;font-size:13px;font-weight:700;color:#fff;text-decoration:none;margin-top:6px;transition:opacity .15s}
.jg-play-btn:hover{opacity:.85;color:#fff}
.jg-age{position:absolute;top:12px;right:12px;background:rgba(0,0,0,.35);color:#fff;font-size:11px;font-weight:700;padding:4px 10px;border-radius:20px;backdrop-filter:blur(6px)}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="jg-header">
  <h2>🎮 Juegos Terapéuticos</h2>
  <p>Explora, juega y aprende sobre tus emociones. Diseñados para niños de 9 a 12 años.</p>
</div>

<div class="jg-grid">

  <a href="<?php echo e(route('juegos.el_gran_orden')); ?>" class="jg-card">
    <div class="jg-card-img" style="background:linear-gradient(135deg,#1e1b4b,#312e81)">
      🧩<div class="jg-age">9–12 años</div>
    </div>
    <div class="jg-card-body">
      <h3>El Gran Orden</h3>
      <p>Ordena objetos en su lugar correcto antes de que se acabe el tiempo. 4 escenas con drag & drop.</p>
      <div>
        <span class="jg-badge" style="background:#e0daf5;color:#5b4b9a">Ansiedad</span>
        <span class="jg-badge" style="background:#dbeafe;color:#1d4ed8">Atención</span>
      </div>
      <span class="jg-play-btn" style="background:linear-gradient(135deg,#4f46e5,#818cf8)">▶ Jugar ahora</span>
    </div>
  </a>

  <a href="<?php echo e(route('juegos.volcan_interior')); ?>" class="jg-card">
    <div class="jg-card-img" style="background:linear-gradient(135deg,#2d0050,#7c3aed)">
      🌋<div class="jg-age">9–12 años</div>
    </div>
    <div class="jg-card-body">
      <h3>Mi Volcán Interior</h3>
      <p>Aprende a manejar emociones difíciles. 6 situaciones reales + módulo de dibujo libre.</p>
      <div>
        <span class="jg-badge" style="background:#fce7f3;color:#be185d">Emociones</span>
        <span class="jg-badge" style="background:#d1fae5;color:#065f46">Autocuidado</span>
        <span class="jg-badge" style="background:#e0daf5;color:#5b4b9a">Bloqueo</span>
      </div>
      <span class="jg-play-btn" style="background:linear-gradient(135deg,#7c3aed,#a78bfa)">▶ Jugar ahora</span>
    </div>
  </a>

  <a href="<?php echo e(route('juegos.ritmo_zen')); ?>" class="jg-card">
    <div class="jg-card-img" style="background:linear-gradient(135deg,#0a0015,#1a0035)">
      🎵<div class="jg-age">9–12 años</div>
    </div>
    <div class="jg-card-body">
      <h3>Ritmo Zen</h3>
      <p>Sigue el ritmo y aprende técnicas de respiración entre niveles. Fondo 3D inmersivo.</p>
      <div>
        <span class="jg-badge" style="background:#fef3c7;color:#92400e">Relajación</span>
        <span class="jg-badge" style="background:#dbeafe;color:#1d4ed8">Respiración</span>
      </div>
      <span class="jg-play-btn" style="background:linear-gradient(135deg,#6d28d9,#a78bfa)">▶ Jugar ahora</span>
    </div>
  </a>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.paciente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/juegos/index.blade.php ENDPATH**/ ?>