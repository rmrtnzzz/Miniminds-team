<?php $__env->startSection('title','Inbox — Miniminds Admin'); ?>
<?php $__env->startSection('extra_styles'); ?>
<style>
.inbox-tabs{display:flex;gap:6px;margin-bottom:24px;flex-wrap:wrap}
.inbox-tab{padding:10px 20px;border-radius:50px;border:1.5px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#cdc3e6;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;display:flex;align-items:center;gap:8px}
.inbox-tab.active{background:rgba(245,166,35,.2);border-color:#F5A623;color:#F5A623}
.inbox-tab .badge{background:#E0576B;color:#fff;font-size:10px;border-radius:10px;padding:2px 7px;font-weight:800}
.inbox-panel{display:none}.inbox-panel.active{display:block}
.ib-table{width:100%;border-collapse:collapse}
.ib-table th{text-align:left;font-size:11px;color:#9a8fb8;text-transform:uppercase;letter-spacing:.5px;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.08)}
.ib-table td{padding:13px 14px;font-size:13px;border-bottom:1px solid rgba(255,255,255,.05);vertical-align:middle}
.pill{display:inline-block;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700}
.pill-pend{background:rgba(251,191,36,.15);color:#fbbf24}
.pill-ok{background:rgba(52,211,153,.15);color:#34d399}
.pill-bad{background:rgba(248,113,113,.12);color:#f87171}
.btn-sm{padding:5px 14px;border-radius:20px;border:none;font-size:12px;font-weight:700;cursor:pointer;margin-right:4px}
.btn-ok{background:#34d399;color:#064e3b}
.btn-bad{background:#f87171;color:#fff}
.puntaje-bar{height:6px;background:rgba(255,255,255,.1);border-radius:6px;overflow:hidden;width:80px;display:inline-block;vertical-align:middle;margin-left:6px}
.puntaje-fill{height:100%;border-radius:6px}
.inf-row{display:flex;align-items:center;gap:10px;padding:13px 14px;border-bottom:1px solid rgba(255,255,255,.05)}
.inf-avatar{width:36px;height:36px;border-radius:50%;background:rgba(245,166,35,.2);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:1000;align-items:center;justify-content:center}
.modal-overlay.open{display:flex}
.modal-box{background:#2D2040;border:1px solid rgba(255,255,255,.15);border-radius:18px;padding:28px;width:100%;max-width:440px}
.modal-box h4{font-weight:800;margin:0 0 16px;color:#ECE7FA}
.modal-box textarea,.modal-box input{width:100%;padding:10px 14px;border:1.5px solid rgba(255,255,255,.15);border-radius:10px;background:rgba(255,255,255,.06);color:#ECE7FA;font-size:13px;outline:none;margin-bottom:14px}
.modal-box textarea:focus{border-color:#F5A623}
.modal-btns{display:flex;gap:10px;justify-content:flex-end}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:22px">
  <h2 style="font-weight:900;margin:0">📬 Inbox</h2>
</div>

<?php if(session('success')): ?>
  <div style="background:rgba(52,211,153,.15);border:1px solid #34d399;border-radius:10px;padding:12px 16px;color:#a7f3d0;margin-bottom:16px;font-size:13px;font-weight:600">✅ <?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="inbox-tabs">
  <div class="inbox-tab active" onclick="showTab('tab-pacientes')">
    📋 Solicitudes pacientes
    <?php if($solicitudesPaciente->where('estado','pendiente')->count()): ?>
      <span class="badge"><?php echo e($solicitudesPaciente->where('estado','pendiente')->count()); ?></span>
    <?php endif; ?>
  </div>
  <div class="inbox-tab" onclick="showTab('tab-especialistas')">
    🎓 Solicitudes especialista
    <?php if($solicitudesEspecialista->where('estado','pendiente')->count()): ?>
      <span class="badge"><?php echo e($solicitudesEspecialista->where('estado','pendiente')->count()); ?></span>
    <?php endif; ?>
  </div>
  <div class="inbox-tab" onclick="showTab('tab-desbaneo')">
    🔓 Desbaneos
    <?php if($solicitudesDesbaneo->where('estado','pendiente')->count()): ?>
      <span class="badge"><?php echo e($solicitudesDesbaneo->where('estado','pendiente')->count()); ?></span>
    <?php endif; ?>
  </div>
  <div class="inbox-tab" onclick="showTab('tab-infracciones')">
    ⚠️ Infracciones
    <?php if($infracciones->where('baneado',true)->count()): ?>
      <span class="badge"><?php echo e($infracciones->where('baneado',true)->count()); ?></span>
    <?php endif; ?>
  </div>
</div>

<div class="inbox-panel active pt-card" id="tab-pacientes">
  <table class="ib-table">
    <thead><tr><th>Paciente</th><th>Solicitado por</th><th>Estado</th><th>Revisado por</th><th>Fecha</th></tr></thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $solicitudesPaciente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><b><?php echo e($s->nombre); ?> <?php echo e($s->apellido); ?></b></td>
          <td><?php echo e($s->user->name ?? '—'); ?></td>
          <td><span class="pill <?php echo e($s->estado==='pendiente'?'pill-pend':($s->estado==='aprobada'?'pill-ok':'pill-bad')); ?>"><?php echo e(ucfirst($s->estado)); ?></span></td>
          <td><?php echo e($s->profesional->nombre ?? '—'); ?></td>
          <td><?php echo e($s->created_at->format('d/m/Y')); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5" style="text-align:center;opacity:.5;padding:24px">No hay solicitudes.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<div class="inbox-panel pt-card" id="tab-especialistas">
  <table class="ib-table">
    <thead><tr><th>Usuario</th><th>Especialidad</th><th>Exp.</th><th>Puntaje test</th><th>Estado</th><th>Acciones</th></tr></thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $solicitudesEspecialista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><b><?php echo e($s->user->name ?? '—'); ?></b><br><span style="font-size:11px;opacity:.6"><?php echo e($s->titulo_profesional); ?></span></td>
          <td><?php echo e($s->especialidad); ?></td>
          <td><?php echo e($s->anios_experiencia); ?> años</td>
          <td>
            <b style="color:<?php echo e($s->puntaje_test>=70?'#34d399':'#fbbf24'); ?>"><?php echo e($s->puntaje_test); ?>/100</b>
            <span class="puntaje-bar"><span class="puntaje-fill" style="width:<?php echo e($s->puntaje_test); ?>%;background:<?php echo e($s->puntaje_test>=70?'#34d399':'#fbbf24'); ?>"></span></span>
          </td>
          <td><span class="pill <?php echo e($s->estado==='pendiente'?'pill-pend':($s->estado==='aprobada'?'pill-ok':'pill-bad')); ?>"><?php echo e(ucfirst($s->estado)); ?></span></td>
          <td>
            <?php if($s->estado==='pendiente'): ?>
              <form method="POST" action="<?php echo e(route('admin.inbox.especialista.aprobar',$s)); ?>" style="display:inline"><?php echo csrf_field(); ?>
                <button class="btn-sm btn-ok">✓ Aprobar</button>
              </form>
              <button class="btn-sm btn-bad" onclick="openModal('modal-rechazar-esp-<?php echo e($s->id); ?>')">✕ Rechazar</button>
            <?php else: ?>
              <?php if($s->notas_admin): ?><span style="font-size:11px;opacity:.6"><?php echo e(Str::limit($s->notas_admin,40)); ?></span><?php endif; ?>
            <?php endif; ?>
          </td>
        </tr>
        <?php if($s->estado==='pendiente'): ?>
        <div class="modal-overlay" id="modal-rechazar-esp-<?php echo e($s->id); ?>">
          <div class="modal-box">
            <h4>Rechazar solicitud de <?php echo e($s->user->name); ?></h4>
            <form method="POST" action="<?php echo e(route('admin.inbox.especialista.rechazar',$s)); ?>"><?php echo csrf_field(); ?>
              <textarea name="notas_admin" rows="3" placeholder="Motivo del rechazo (opcional)..."></textarea>
              <div class="modal-btns">
                <button type="button" class="btn-sm" style="background:rgba(255,255,255,.1);color:#ECE7FA" onclick="closeModal('modal-rechazar-esp-<?php echo e($s->id); ?>')">Cancelar</button>
                <button type="submit" class="btn-sm btn-bad">Confirmar rechazo</button>
              </div>
            </form>
          </div>
        </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" style="text-align:center;opacity:.5;padding:24px">No hay solicitudes de especialista.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<div class="inbox-panel pt-card" id="tab-desbaneo">
  <table class="ib-table">
    <thead><tr><th>Usuario</th><th>Justificación</th><th>Fecha</th><th>Estado</th><th>Acciones</th></tr></thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $solicitudesDesbaneo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><b><?php echo e($s->user->name ?? '—'); ?></b><br><span style="font-size:11px;opacity:.6"><?php echo e($s->user->email ?? ''); ?></span></td>
          <td style="max-width:240px"><?php echo e(Str::limit($s->justificacion, 80)); ?></td>
          <td><?php echo e($s->fecha_solicitud->format('d/m/Y')); ?></td>
          <td><span class="pill <?php echo e($s->estado==='pendiente'?'pill-pend':($s->estado==='aprobada'?'pill-ok':'pill-bad')); ?>"><?php echo e(ucfirst($s->estado)); ?></span></td>
          <td>
            <?php if($s->estado==='pendiente'): ?>
              <form method="POST" action="<?php echo e(route('admin.inbox.desbaneo.aprobar',$s)); ?>" style="display:inline"><?php echo csrf_field(); ?>
                <button class="btn-sm btn-ok">✓ Desbanear</button>
              </form>
              <button class="btn-sm btn-bad" onclick="openModal('modal-rechazar-desb-<?php echo e($s->id); ?>')">✕ Rechazar</button>
            <?php else: ?>
              <span style="font-size:11px;opacity:.6"><?php echo e(Str::limit($s->respuesta_admin,40)); ?></span>
            <?php endif; ?>
          </td>
        </tr>
        <?php if($s->estado==='pendiente'): ?>
        <div class="modal-overlay" id="modal-rechazar-desb-<?php echo e($s->id); ?>">
          <div class="modal-box">
            <h4>Rechazar desbaneo de <?php echo e($s->user->name ?? ''); ?></h4>
            <p style="font-size:13px;opacity:.7;margin-bottom:14px">Justificación del usuario: <?php echo e($s->justificacion); ?></p>
            <form method="POST" action="<?php echo e(route('admin.inbox.desbaneo.rechazar',$s)); ?>"><?php echo csrf_field(); ?>
              <textarea name="respuesta_admin" rows="2" placeholder="Respuesta al usuario (opcional)..."></textarea>
              <div class="modal-btns">
                <button type="button" class="btn-sm" style="background:rgba(255,255,255,.1);color:#ECE7FA" onclick="closeModal('modal-rechazar-desb-<?php echo e($s->id); ?>')">Cancelar</button>
                <button type="submit" class="btn-sm btn-bad">Confirmar rechazo</button>
              </div>
            </form>
          </div>
        </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5" style="text-align:center;opacity:.5;padding:24px">No hay solicitudes de desbaneo.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<div class="inbox-panel pt-card" id="tab-infracciones">
  <?php $__empty_1 = true; $__currentLoopData = $infracciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="inf-row">
      <div class="inf-avatar"><?php echo e(strtoupper(substr($u->name,0,1))); ?></div>
      <div style="flex:1">
        <div style="font-weight:700;font-size:14px"><?php echo e($u->name); ?></div>
        <div style="font-size:12px;opacity:.6"><?php echo e($u->email); ?></div>
        <?php if($u->motivo_baneo): ?><div style="font-size:12px;color:#fca5a5;margin-top:2px">Motivo: <?php echo e($u->motivo_baneo); ?></div><?php endif; ?>
      </div>
      <div style="text-align:center;min-width:80px">
        <div style="font-size:11px;opacity:.6">Advertencias</div>
        <div style="font-size:20px;font-weight:900;color:#fbbf24"><?php echo e($u->advertencias); ?></div>
      </div>
      <div style="text-align:center;min-width:100px">
        <?php if($u->baneado): ?>
          <span class="pill pill-bad"><?php echo e($u->tipo_baneo === 'permanente' ? '🔒 Permanente' : '⏰ Temporal'); ?></span>
          <?php if($u->baneado_hasta): ?><div style="font-size:11px;opacity:.6;margin-top:4px">hasta <?php echo e($u->baneado_hasta->format('d/m H:i')); ?></div><?php endif; ?>
        <?php else: ?>
          <span class="pill pill-ok">Activo</span>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div style="text-align:center;opacity:.5;padding:32px">No hay infracciones registradas.</div>
  <?php endif; ?>
</div>

<script>
function showTab(id){
  document.querySelectorAll('.inbox-tab').forEach((t,i)=>{
    const panels=['tab-pacientes','tab-especialistas','tab-desbaneo','tab-infracciones'];
    t.classList.toggle('active', panels[i]===id);
    document.getElementById(panels[i]).classList.toggle('active', panels[i]===id);
  });
}
function openModal(id){document.getElementById(id).classList.add('open')}
function closeModal(id){document.getElementById(id).classList.remove('open')}
document.querySelectorAll('.modal-overlay').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('open')}));
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abc\Desktop\neuropendejadas\resources\views/admin/inbox.blade.php ENDPATH**/ ?>