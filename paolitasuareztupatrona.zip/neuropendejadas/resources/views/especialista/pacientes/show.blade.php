@extends('layouts.especialista')
@section('title', $paciente->nombre.' — Ficha del paciente')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="font-weight:800;margin:0">{{ $paciente->nombre }} {{ $paciente->apellido }}</h2>
    <a href="{{ route('especialista.pacientes.edit', $paciente->id) }}" class="btn btn-acento btn-sm">Editar datos</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="pt-card p-4">
            <div style="font-size:12px;color:#4a7d6f;text-transform:uppercase;font-weight:700">Tutor</div>
            <div style="font-size:15px">{{ $paciente->user->name ?? '—' }}</div>
            <div style="font-size:12px;color:#4a7d6f">{{ $paciente->user->email ?? '' }}</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pt-card p-4">
            <div style="font-size:12px;color:#4a7d6f;text-transform:uppercase;font-weight:700">Edad / Género</div>
            <div style="font-size:15px">{{ $paciente->edad ?? '—' }} años · {{ ucfirst($paciente->genero ?? '—') }}</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="pt-card p-4">
            <div style="font-size:12px;color:#4a7d6f;text-transform:uppercase;font-weight:700">Fecha de nacimiento</div>
            <div style="font-size:15px">{{ optional($paciente->fecha_nacimiento)->format('d/m/Y') ?? '—' }}</div>
        </div>
    </div>
</div>

<h6 style="font-weight:700;margin-bottom:10px">Historial de citas</h6>
<div class="pt-card p-3 mb-3">
    <table class="table mb-0" style="font-size:14px">
        <thead>
            <tr style="color:#4a7d6f;font-size:12px;text-transform:uppercase">
                <th>Fecha</th><th>Hora</th><th>Estado</th><th>Notas</th>
            </tr>
        </thead>
        <tbody>
            @forelse($paciente->citas as $c)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($c->fecha)->format('d/m/Y') }}</td>
                    <td>{{ \Carbon\Carbon::parse($c->hora)->format('H:i') }}</td>
                    <td>{{ ucfirst($c->estado) }}</td>
                    <td style="color:#7c9d92">{{ $c->notas ?? '—' }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="text-center py-3" style="color:#7c9d92">Sin citas registradas todavía.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<a href="{{ route('especialista.citas.index') }}" class="btn btn-acento btn-sm">+ Agendar una cita para este paciente</a>
@endsection
