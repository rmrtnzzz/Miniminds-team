@extends('layouts.especialista')
@section('title', 'Mi perfil — Miniminds')

@section('content')
<h2 style="font-weight:800;margin-bottom:24px">Mi perfil profesional</h2>

@if(!$profesional)
    <div class="alert alert-warning">
        Todavía no tienes una ficha profesional asociada. Contacta a un administrador.
    </div>
@else
<div class="pt-card p-4" style="max-width:640px">
    <div class="d-flex align-items-center gap-3 mb-4">
        <img src="{{ $profesional->foto ? asset('storage/'.$profesional->foto) : 'https://via.placeholder.com/80' }}"
             class="rounded-circle" width="80" height="80" style="object-fit:cover;border:3px solid #fff">
        <div>
            <div style="font-weight:800;font-size:18px">{{ $profesional->nombre }} {{ $profesional->apellido }}</div>
            <div style="font-size:13px;color:#4a7d6f">{{ $profesional->especialidad ?? 'Especialista' }}</div>
            <div style="font-size:12px;color:#7c9d92">Miembro desde: {{ $profesional->created_at->format('d/m/Y') }}</div>
        </div>
    </div>

    <div style="font-size:14px">
        <div class="d-flex justify-content-between border-bottom py-2">
            <span style="color:#4a7d6f;font-weight:700">Correo</span>
            <span>{{ $profesional->user->email ?? '—' }}</span>
        </div>
        <div class="d-flex justify-content-between border-bottom py-2">
            <span style="color:#4a7d6f;font-weight:700">Teléfono</span>
            <span>{{ $profesional->telefono ?? '—' }}</span>
        </div>
        <div class="d-flex justify-content-between border-bottom py-2">
            <span style="color:#4a7d6f;font-weight:700">Fecha de nacimiento</span>
            <span>{{ $profesional->fecha_nacimiento ?? '—' }}</span>
        </div>
        <div class="d-flex justify-content-between py-2">
            <span style="color:#4a7d6f;font-weight:700">Género</span>
            <span>{{ ucfirst($profesional->genero ?? '—') }}</span>
        </div>
    </div>

    <a href="{{ route('especialista.perfil.editar') }}" class="btn btn-acento mt-3">Editar perfil</a>
</div>
@endif
@endsection
