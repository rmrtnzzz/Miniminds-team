@extends('layouts.paciente')
@section('title','Mi Volcán Interior — Miniminds')
@section('extra_styles')
<style>
*{margin:0;padding:0;box-sizing:border-box}
#vi-wrap{min-height:calc(100vh - 60px);background:linear-gradient(160deg,#1a0035 0%,#2d0050 50%,#1a0020 100%);font-family:'Segoe UI',sans-serif;color:#fff;display:flex;flex-direction:column;align-items:center;padding:30px 20px}

.vi-screen{width:100%;max-width:700px;display:none;flex-direction:column;align-items:center;gap:20px;animation:fadeIn .4s ease}
.vi-screen.active{display:flex}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}

#vi-intro h1{font-size:38px;font-weight:900;background:linear-gradient(135deg,#ff6b6b,#fbbf24);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center}
#vi-intro p{text-align:center;font-size:15px;opacity:.75;max-width:480px;line-height:1.6}
.vi-start-btn{padding:16px 48px;border-radius:50px;border:none;background:linear-gradient(135deg,#dc2626,#f97316);color:#fff;font-size:17px;font-weight:800;cursor:pointer;box-shadow:0 8px 32px rgba(220,38,38,.4);transition:transform .1s}
.vi-start-btn:hover{transform:scale(1.04)}

.vi-volcano-wrap{position:relative;width:220px;height:200px;margin:10px auto}
.vi-mountain{width:0;height:0;border-left:110px solid transparent;border-right:110px solid transparent;border-bottom:180px solid #7c3aed;filter:drop-shadow(0 0 30px #7c3aed88);position:absolute;bottom:0;left:0}
.vi-mountain::after{content:'';position:absolute;width:0;height:0;border-left:80px solid transparent;border-right:80px solid transparent;border-bottom:130px solid #6d28d9;top:50px;left:-80px}
.vi-lava{position:absolute;bottom:178px;left:50%;transform:translateX(-50%);width:40px;background:linear-gradient(#fbbf24,#ef4444);border-radius:4px 4px 12px 12px;transition:height .6s ease,opacity .4s;opacity:0}
.vi-particles{position:absolute;bottom:178px;left:50%;transform:translateX(-50%);pointer-events:none}
.vi-spark{position:absolute;width:6px;height:6px;border-radius:50%;background:#fbbf24;animation:spark 1s ease-out infinite}
@keyframes spark{0%{transform:translate(0,0);opacity:1}100%{transform:translate(var(--sx),var(--sy));opacity:0}}

.vi-stress-bar-wrap{width:100%;max-width:500px}
.vi-stress-label{display:flex;justify-content:space-between;font-size:13px;opacity:.7;margin-bottom:6px}
.vi-stress-track{width:100%;height:18px;background:rgba(255,255,255,.1);border-radius:12px;overflow:hidden;border:1px solid rgba(255,255,255,.15)}
.vi-stress-fill{height:100%;border-radius:12px;transition:width .5s ease,background .5s}

.vi-card{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:20px;padding:28px;width:100%;max-width:600px;backdrop-filter:blur(8px)}
.vi-situation-emoji{font-size:52px;text-align:center;margin-bottom:8px}
.vi-situation-text{font-size:17px;font-weight:600;text-align:center;line-height:1.5;margin-bottom:20px}
.vi-options{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.vi-opt{padding:14px 16px;border-radius:14px;border:2px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s;text-align:left;display:flex;align-items:center;gap:10px}
.vi-opt:hover{background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.35);transform:translateY(-2px)}
.vi-opt.good{border-color:#34d399;background:rgba(52,211,153,.12)}
.vi-opt.bad{border-color:#f87171;background:rgba(248,113,113,.1)}
.vi-opt.selected-good{background:#34d399;border-color:#34d399;color:#064e3b;animation:pulse-good .4s}
.vi-opt.selected-bad{background:#ef4444;border-color:#ef4444;color:#fff;animation:shake .4s}
@keyframes pulse-good{0%,100%{transform:scale(1)}50%{transform:scale(1.04)}}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}

.vi-feedback-box{padding:16px 20px;border-radius:14px;font-size:14px;line-height:1.6;width:100%;max-width:600px;display:none}
.vi-feedback-box.good{background:rgba(52,211,153,.15);border:1.5px solid #34d399;color:#a7f3d0}
.vi-feedback-box.bad{background:rgba(248,113,113,.12);border:1.5px solid #f87171;color:#fca5a5}
.vi-next-btn{padding:13px 36px;border-radius:50px;border:none;background:linear-gradient(135deg,#6d28d9,#a78bfa);color:#fff;font-size:15px;font-weight:700;cursor:pointer;display:none}

#vi-draw-screen h2{font-size:26px;font-weight:800;background:linear-gradient(135deg,#a78bfa,#34d399);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center}
#vi-draw-screen p{text-align:center;font-size:14px;opacity:.7;max-width:480px}
#vi-draw-canvas{border-radius:16px;border:2px solid rgba(255,255,255,.2);cursor:crosshair;touch-action:none;background:#fff}
.vi-draw-tools{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;align-items:center}
.vi-color-btn{width:32px;height:32px;border-radius:50%;border:3px solid transparent;cursor:pointer;transition:transform .15s}
.vi-color-btn.active{border-color:#fff;transform:scale(1.2)}
.vi-size-btn{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:#fff;padding:6px 14px;border-radius:20px;cursor:pointer;font-size:13px;font-weight:600}
.vi-size-btn.active{background:#6d28d9;border-color:#a78bfa}
.vi-tool-btn{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff;padding:8px 18px;border-radius:20px;cursor:pointer;font-size:13px;font-weight:600;transition:background .15s}
.vi-tool-btn:hover{background:rgba(255,255,255,.2)}
.vi-draw-msg{font-size:13px;opacity:.6;text-align:center}

#vi-end-screen h2{font-size:32px;font-weight:900;text-align:center;background:linear-gradient(135deg,#fbbf24,#f97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.vi-stats{display:flex;gap:20px;flex-wrap:wrap;justify-content:center}
.vi-stat-box{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:16px;padding:18px 28px;text-align:center;min-width:120px}
.vi-stat-box .sv{font-size:28px;font-weight:900;color:#fbbf24}
.vi-stat-box .sl{font-size:12px;opacity:.65;text-transform:uppercase;letter-spacing:.5px}
.vi-msg-box{background:rgba(167,139,250,.12);border:1.5px solid #a78bfa;border-radius:14px;padding:18px 24px;text-align:center;font-size:15px;color:#c4b5fd;max-width:500px;line-height:1.6}
.vi-end-btns{display:flex;gap:12px;flex-wrap:wrap;justify-content:center}
.vi-end-btns button{padding:13px 28px;border-radius:50px;border:none;font-size:14px;font-weight:700;cursor:pointer}
.vi-btn-replay{background:linear-gradient(135deg,#dc2626,#f97316);color:#fff}
.vi-btn-draw{background:linear-gradient(135deg,#6d28d9,#a78bfa);color:#fff}
.vi-btn-back{background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2)!important}

.vi-progress{display:flex;gap:8px;justify-content:center}
.vi-prog-dot{width:10px;height:10px;border-radius:50%;background:rgba(255,255,255,.2);transition:background .3s}
.vi-prog-dot.done{background:#34d399}
.vi-prog-dot.current{background:#fbbf24}
</style>
@endsection

@section('content')
<div id="vi-wrap">

  
  <div class="vi-screen active" id="vi-intro">
    <h1>🌋 Mi Volcán Interior</h1>
    <p>Cuando las emociones se acumulan, el volcán puede explotar.<br>Aprende a calmarte eligiendo respuestas saludables ante situaciones difíciles.</p>
    <div class="vi-volcano-wrap">
      <div class="vi-mountain"></div>
      <div class="vi-lava" id="vi-lava-demo"></div>
    </div>
    <button class="vi-start-btn" onclick="viStart()">¡Explorar mis emociones!</button>
  </div>

  
  <div class="vi-screen" id="vi-game">
    <div class="vi-progress" id="vi-progress"></div>

    <div class="vi-volcano-wrap">
      <div class="vi-mountain"></div>
      <div class="vi-lava" id="vi-lava"></div>
      <div class="vi-particles" id="vi-sparks"></div>
    </div>

    <div class="vi-stress-bar-wrap">
      <div class="vi-stress-label"><span>😌 Tranquilo</span><span id="vi-stress-pct">0%</span><span>😤 Volcán</span></div>
      <div class="vi-stress-track"><div class="vi-stress-fill" id="vi-stress-fill" style="width:20%;background:#34d399"></div></div>
    </div>

    <div class="vi-card" id="vi-situation-card">
      <div class="vi-situation-emoji" id="vi-emoji">🤔</div>
      <div class="vi-situation-text" id="vi-situation-text">Cargando...</div>
      <div class="vi-options" id="vi-options"></div>
    </div>

    <div class="vi-feedback-box" id="vi-feedback-box"></div>
    <button class="vi-next-btn" id="vi-next-btn" onclick="viNext()">Siguiente situación →</button>
  </div>

  
  <div class="vi-screen" id="vi-draw-screen">
    <h2>🎨 Espacio libre de expresión</h2>
    <p>¡Lo hiciste muy bien! Ahora dibuja cómo te sientes.<br>No hay nada correcto ni incorrecto — este espacio es tuyo.</p>
    <canvas id="vi-draw-canvas" width="580" height="340"></canvas>
    <div class="vi-draw-tools">
      <div id="vi-colors" style="display:flex;gap:8px">
        <div class="vi-color-btn active" style="background:#ef4444" onclick="viSetColor('#ef4444',this)"></div>
        <div class="vi-color-btn" style="background:#f97316" onclick="viSetColor('#f97316',this)"></div>
        <div class="vi-color-btn" style="background:#fbbf24" onclick="viSetColor('#fbbf24',this)"></div>
        <div class="vi-color-btn" style="background:#34d399" onclick="viSetColor('#34d399',this)"></div>
        <div class="vi-color-btn" style="background:#60a5fa" onclick="viSetColor('#60a5fa',this)"></div>
        <div class="vi-color-btn" style="background:#a78bfa" onclick="viSetColor('#a78bfa',this)"></div>
        <div class="vi-color-btn" style="background:#f9a8d4" onclick="viSetColor('#f9a8d4',this)"></div>
        <div class="vi-color-btn" style="background:#1e1e1e" onclick="viSetColor('#1e1e1e',this)"></div>
        <div class="vi-color-btn" style="background:#ffffff;border:1px solid rgba(255,255,255,.3)" onclick="viSetColor('#ffffff',this)"></div>
      </div>
      <button class="vi-size-btn active" onclick="viSetSize(4,this)" id="sz-s">S</button>
      <button class="vi-size-btn" onclick="viSetSize(10,this)" id="sz-m">M</button>
      <button class="vi-size-btn" onclick="viSetSize(22,this)" id="sz-l">L</button>
      <button class="vi-tool-btn" onclick="viToggleEraser(this)" id="vi-eraser-btn">🧹 Borrador</button>
      <button class="vi-tool-btn" onclick="viClearCanvas()">🗑️ Limpiar</button>
    </div>
    <div class="vi-draw-msg">Dibuja lo que sientes — tus emociones merecen un lugar seguro 💜</div>
    <button class="vi-start-btn" style="background:linear-gradient(135deg,#6d28d9,#a78bfa);box-shadow:0 8px 32px rgba(109,40,217,.4)" onclick="viShowEnd()">Ver mi resultado 🌟</button>
  </div>

  
  <div class="vi-screen" id="vi-end-screen">
    <div style="font-size:60px;text-align:center">🌟</div>
    <h2>¡Increíble trabajo!</h2>
    <div class="vi-stats">
      <div class="vi-stat-box"><div class="sv" id="vi-end-good">0</div><div class="sl">Elecciones saludables</div></div>
      <div class="vi-stat-box"><div class="sv" id="vi-end-pts">0</div><div class="sl">Puntos</div></div>
      <div class="vi-stat-box"><div class="sv" id="vi-end-stress">0%</div><div class="sl">Nivel de calma final</div></div>
    </div>
    <div class="vi-msg-box" id="vi-end-msg"></div>
    <div class="vi-end-btns">
      <button class="vi-btn-replay" onclick="viReset()">Volver a jugar</button>
      <button class="vi-btn-draw" onclick="viGoToDraw()">🎨 Seguir dibujando</button>
      <button class="vi-btn-back" onclick="location.href='{{ route('juegos.index') }}'">Otros juegos</button>
    </div>
  </div>

</div>

<script>
const SITUATIONS = [
  {
    emoji:'😤', text:'Tu amigo/a rompió tu juguete favorito sin querer y no te pidió disculpas.',
    options:[
      {text:'🤬 Empujarlo y gritarle',good:false,feedback:'Lastimar a alguien nunca resuelve el problema. Puede hacerlo sentir peor y alejarte de tu amigo.'},
      {text:'🗣️ Decirle cómo me siento',good:true,feedback:'¡Genial! Hablar de tus emociones es muy valiente. Puedes decir: "Me sentí triste porque ese juguete era especial para mí."'},
      {text:'😤 Romper algo de él',good:false,feedback:'Hacer daño a cambio de daño no te hará sentir mejor. Busca una forma de expresar lo que sientes sin hacerle daño a nadie.'},
      {text:'🧘 Respirar y esperar',good:true,feedback:'¡Excelente! Calmarte antes de actuar es una habilidad muy importante. Así puedes pensar con claridad.'},
    ]
  },
  {
    emoji:'😟', text:'Sacaste mala nota en un examen y sientes que no sirves para nada.',
    options:[
      {text:'📚 Pedir ayuda al profe',good:true,feedback:'¡Muy inteligente! Pedir ayuda cuando la necesitas es señal de fortaleza, no de debilidad.'},
      {text:'✏️ Rayar y romper el examen',good:false,feedback:'Destruir cosas cuando estamos frustrados no nos ayuda a mejorar. Mejor guarda esa energía para estudiar más.'},
      {text:'😴 Esconderme y no hablar',good:false,feedback:'Guardar todo por dentro puede hacerte sentir peor con el tiempo. Hablar con alguien de confianza siempre ayuda.'},
      {text:'💪 Intentarlo de nuevo',good:true,feedback:'¡Eso es! Una mala nota no define quién eres. Cada error es una oportunidad de aprender algo nuevo.'},
    ]
  },
  {
    emoji:'😔', text:'Alguien en el recreo se burló de ti y te sientes muy mal por dentro.',
    options:[
      {text:'👊 Pelearme con esa persona',good:false,feedback:'Pelear puede lastimarte a ti también y traer consecuencias. Hay formas más seguras de protegerte.'},
      {text:'🧑‍🏫 Contarle a un adulto de confianza',good:true,feedback:'¡Muy bien! Pedir apoyo a un adulto cuando alguien nos hace daño es lo correcto y lo más valiente.'},
      {text:'🎨 Dibujar cómo me siento',good:true,feedback:'¡Excelente! El arte es una forma poderosa de sacar las emociones difíciles de forma segura y creativa.'},
      {text:'😶 No decirle a nadie',good:false,feedback:'Cargar eso solo puede ser muy pesado. Mereces apoyo y nadie debería aguantar el bullying en silencio.'},
    ]
  },
  {
    emoji:'😠', text:'Estás muy enojado/a y sientes que quieres hacer algo que te pueda lastimar.',
    options:[
      {text:'🌬️ Respirar profundo 10 veces',good:true,feedback:'¡Perfecto! La respiración profunda activa tu sistema de calma. Inhala por la nariz, exhala despacio por la boca.'},
      {text:'🆘 Buscar a alguien en quien confíe',good:true,feedback:'¡Muy bien! Cuando las emociones se sienten muy grandes, hablar con alguien de confianza siempre es la mejor opción.'},
      {text:'🤕 Lastimar mi cuerpo',good:false,feedback:'Tu cuerpo es precioso y merece cuidado. Lastimarte nunca resuelve el dolor — existe ayuda y siempre hay alguien dispuesto a escucharte.'},
      {text:'🏃 Correr o moverme',good:true,feedback:'¡Excelente! El movimiento libera tensión de forma segura. Caminar, saltar o bailar ayuda al cerebro a calmarse.'},
    ]
  },
  {
    emoji:'😰', text:'Tienes que hablar en clase y el corazón te late muy rápido de los nervios.',
    options:[
      {text:'🙈 Fingir que estoy enfermo',good:false,feedback:'Evitar las cosas que nos dan miedo hace que el miedo crezca. Enfrentarlo poco a poco, con apoyo, es lo que funciona.'},
      {text:'💨 Respirar y recordar que puedo',good:true,feedback:'¡Eso es! Recordarte a ti mismo que has superado cosas difíciles antes te da fuerza. ¡Tú puedes!'},
      {text:'🧑‍🤝‍🧑 Pedirle apoyo a un amigo',good:true,feedback:'¡Muy bien! Apoyarnos en los demás en momentos difíciles es inteligente y valiente.'},
      {text:'😤 Enojarme con todos',good:false,feedback:'El enojo no suele venir solo — a veces esconde miedo o tristeza. Trata de identificar qué sientes realmente.'},
    ]
  },
  {
    emoji:'😢', text:'Extrañas mucho a alguien y sientes un hueco grande en el pecho.',
    options:[
      {text:'✍️ Escribir o dibujar lo que siento',good:true,feedback:'¡Genial! Expresar el dolor a través del arte o la escritura es una de las formas más saludables de procesarlo.'},
      {text:'📵 No comer ni dormir',good:false,feedback:'Cuando estamos tristes, el cuerpo necesita aún más cuidado. Dormir, comer y moverse ayudan al cerebro a sanar.'},
      {text:'🤗 Hablar con alguien de confianza',good:true,feedback:'¡Exacto! Compartir la tristeza con alguien que te quiere la hace más liviana. No tienes que sentirla solo/a.'},
      {text:'😤 Encerrarme y no salir',good:false,feedback:'El aislamiento puede intensificar la tristeza. Un pequeño paseo o una conversación pueden hacer una gran diferencia.'},
    ]
  },
];

let viState = {
  idx:0, score:0, good:0, stress:20,
  answered:false
};

function viStart(){
  viState={idx:0,score:0,good:0,stress:20,answered:false};
  buildProgress();
  showScreen('vi-game');
  loadSituation();
  updateVolcan();
}

function buildProgress(){
  const p=document.getElementById('vi-progress');
  p.innerHTML='';
  SITUATIONS.forEach((_,i)=>{
    const d=document.createElement('div');
    d.className='vi-prog-dot'+(i===0?' current':'');
    d.id='pd-'+i;
    p.appendChild(d);
  });
}

function loadSituation(){
  const s=SITUATIONS[viState.idx];
  document.getElementById('vi-emoji').textContent=s.emoji;
  document.getElementById('vi-situation-text').textContent=s.text;
  const opts=document.getElementById('vi-options');
  opts.innerHTML='';
  
  const shuffled=[...s.options].sort(()=>Math.random()-.5);
  shuffled.forEach((o,i)=>{
    const btn=document.createElement('button');
    btn.className='vi-opt';
    btn.textContent=o.text;
    btn.onclick=()=>viAnswer(o,btn);
    opts.appendChild(btn);
  });
  document.getElementById('vi-feedback-box').style.display='none';
  document.getElementById('vi-next-btn').style.display='none';
  viState.answered=false;
}

function viAnswer(opt,btn){
  if(viState.answered) return;
  viState.answered=true;

  const fb=document.getElementById('vi-feedback-box');
  if(opt.good){
    btn.classList.add('selected-good');
    fb.className='vi-feedback-box good';
    fb.innerHTML='✅ '+opt.feedback;
    viState.good++;
    viState.score+=100;
    viState.stress=Math.max(5, viState.stress-12);
  } else {
    btn.classList.add('selected-bad');
    fb.className='vi-feedback-box bad';
    fb.innerHTML='⚠️ '+opt.feedback;
    viState.stress=Math.min(95, viState.stress+18);
  }
  fb.style.display='block';
  document.getElementById('vi-next-btn').style.display='block';
  updateVolcan();
  updateProgress();
}

function updateVolcan(){
  const pct=viState.stress;
  const fill=document.getElementById('vi-stress-fill');
  fill.style.width=pct+'%';
  fill.style.background=pct<40?'#34d399':pct<70?'#fbbf24':'#ef4444';
  document.getElementById('vi-stress-pct').textContent=Math.round(pct)+'%';

  const lava=document.getElementById('vi-lava');
  const h=Math.max(0,(pct-30)*1.2);
  lava.style.height=h+'px';
  lava.style.opacity=pct>30?1:0;

  const sparks=document.getElementById('vi-sparks');
  sparks.innerHTML='';
  if(pct>60){
    for(let i=0;i<6;i++){
      const sp=document.createElement('div');
      sp.className='vi-spark';
      const ang=Math.random()*Math.PI*2;
      const r=20+Math.random()*40;
      sp.style.cssText=`--sx:${Math.cos(ang)*r}px;--sy:${-Math.sin(ang)*r-20}px;animation-delay:${Math.random()*.8}s;background:${Math.random()>.5?'#fbbf24':'#f97316'}`;
      sparks.appendChild(sp);
    }
  }
}

function updateProgress(){
  SITUATIONS.forEach((_,i)=>{
    const d=document.getElementById('pd-'+i);
    if(!d) return;
    d.className='vi-prog-dot'+(i<viState.idx?'done':i===viState.idx?'current':'');
  });
}

function viNext(){
  viState.idx++;
  if(viState.idx >= SITUATIONS.length){
    showScreen('vi-draw-screen');
  } else {
    updateProgress();
    loadSituation();
  }
}

function viGoToDraw(){
  showScreen('vi-draw-screen');
}

function viShowEnd(){
  const calma = Math.round(100 - viState.stress);
  document.getElementById('vi-end-good').textContent=viState.good;
  document.getElementById('vi-end-pts').textContent=viState.score;
  document.getElementById('vi-end-stress').textContent=calma+'%';
  const msgs=[
    [5,'¡Eres un/a experto/a en manejar emociones! Tu volcán está casi apagado. Sigues aprendiendo cosas increíbles sobre ti mismo/a. 🌟'],
    [3,'¡Muy bien! Estás aprendiendo a cuidarte. Cada vez que eliges una respuesta saludable, tu cerebro se fortalece. 💜'],
    [0,'Aprender a manejar emociones lleva tiempo. Lo importante es que lo estás intentando. ¡Sigue practicando! 🌱'],
  ];
  for(const[min,msg] of msgs){
    if(viState.good>=min){document.getElementById('vi-end-msg').textContent=msg;break;}
  }
  showScreen('vi-end-screen');
}

function viReset(){
  viStart();
}

let drawing=false, drawColor='#ef4444', drawSize=4, erasing=false;
const dc=document.getElementById('vi-draw-canvas');
const dctx=dc.getContext('2d');

function getPos(e,canvas){
  const r=canvas.getBoundingClientRect();
  const src=e.touches?e.touches[0]:e;
  return{x:src.clientX-r.left,y:src.clientY-r.top};
}

dc.addEventListener('mousedown',e=>{drawing=true;const p=getPos(e,dc);dctx.beginPath();dctx.moveTo(p.x,p.y)});
dc.addEventListener('mousemove',e=>{
  if(!drawing)return;
  const p=getPos(e,dc);
  dctx.lineTo(p.x,p.y);
  dctx.strokeStyle=erasing?'#ffffff':drawColor;
  dctx.lineWidth=erasing?drawSize*3:drawSize;
  dctx.lineCap='round';dctx.lineJoin='round';
  dctx.stroke();
  dctx.beginPath();dctx.moveTo(p.x,p.y);
});
dc.addEventListener('mouseup',()=>drawing=false);
dc.addEventListener('mouseleave',()=>drawing=false);

dc.addEventListener('touchstart',e=>{e.preventDefault();drawing=true;const p=getPos(e,dc);dctx.beginPath();dctx.moveTo(p.x,p.y)},{passive:false});
dc.addEventListener('touchmove',e=>{
  e.preventDefault();if(!drawing)return;
  const p=getPos(e,dc);
  dctx.lineTo(p.x,p.y);
  dctx.strokeStyle=erasing?'#ffffff':drawColor;
  dctx.lineWidth=erasing?drawSize*3:drawSize;
  dctx.lineCap='round';dctx.lineJoin='round';
  dctx.stroke();dctx.beginPath();dctx.moveTo(p.x,p.y);
},{passive:false});
dc.addEventListener('touchend',()=>drawing=false);

function viSetColor(c,el){
  drawColor=c; erasing=false;
  document.querySelectorAll('.vi-color-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('vi-eraser-btn').textContent='🧹 Borrador';
}
function viSetSize(s,el){
  drawSize=s;
  document.querySelectorAll('.vi-size-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
}
function viToggleEraser(el){
  erasing=!erasing;
  el.textContent=erasing?'✏️ Pincel':'🧹 Borrador';
  el.style.background=erasing?'#6d28d9':'rgba(255,255,255,.1)';
}
function viClearCanvas(){
  dctx.clearRect(0,0,dc.width,dc.height);
}

function showScreen(id){
  document.querySelectorAll('.vi-screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
}

const lavaDemoEl=document.getElementById('vi-lava-demo');
let demoDir=1, demoH=0;
setInterval(()=>{
  demoH+=demoDir*2;
  if(demoH>60)demoDir=-1;
  if(demoH<0)demoDir=1;
  lavaDemoEl.style.height=demoH+'px';
  lavaDemoEl.style.opacity=demoH>0?1:0;
},50);
</script>
@endsection
