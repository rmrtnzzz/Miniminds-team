<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Acceso restringido - Miniminds</title>
    <style>
        body {
            margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center;
            background: linear-gradient(135deg, #C4B5E8 0%, #D8D0F0 50%, #E8D5F0 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .card {
            background: #fff; border-radius: 24px; padding: 40px; max-width: 420px;
            text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .icon { font-size: 56px; margin-bottom: 8px; }
        h1 { color: #4A4063; font-size: 22px; margin: 0 0 12px; }
        p { color: #555; line-height: 1.6; }
        .badge {
            display: inline-block; margin-bottom: 16px; padding: 6px 16px; border-radius: 999px;
            background: #F3EEFC; color: #7C5FBF; font-weight: 700; font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">🚫</div>
        <span class="badge">Acceso restringido</span>

        @if ($tipo === 'permanente')
            <h1>Cuenta baneada permanentemente</h1>
            <p>Tu acceso a Miniminds fue bloqueado de forma permanente por incumplir las normas de la comunidad, incluyendo el acceso desde esta red.</p>
        @else
            <h1>Cuenta suspendida temporalmente</h1>
            <p>
                Tu cuenta está suspendida
                @isset($hasta)
                    hasta el <strong>{{ \Illuminate\Support\Carbon::parse($hasta)->format('d/m/Y H:i') }}</strong>.
                @endisset
                @isset($motivo)
                    <br>Motivo: {{ $motivo }}
                @endisset
            </p>
        @endif
    </div>
</body>
</html>
