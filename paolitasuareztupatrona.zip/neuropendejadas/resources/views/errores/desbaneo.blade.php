<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cuenta suspendida — Miniminds</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;background:linear-gradient(160deg,#1a0035,#2d0050,#1a0020);display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',sans-serif;color:#fff;padding:20px}
.box{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:24px;padding:40px 36px;max-width:520px;width:100%;text-align:center;backdrop-filter:blur(10px)}
.box .ico{font-size:60px;margin-bottom:16px}
.box h1{font-size:26px;font-weight:900;margin-bottom:8px;color:#f87171}
.box p{font-size:14px;opacity:.75;line-height:1.7;margin-bottom:6px}
.box .motivo{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.3);border-radius:12px;padding:14px 18px;margin:18px 0;font-size:13px;color:#fca5a5;text-align:left}
.box .limite{font-size:13px;color:#fbbf24;margin-bottom:20px}
textarea{width:100%;padding:12px 14px;border-radius:12px;border:1.5px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:#fff;font-size:14px;resize:vertical;min-height:100px;outline:none;margin-bottom:14px}
textarea::placeholder{color:rgba(255,255,255,.4)}
textarea:focus{border-color:#a78bfa}
.btn{width:100%;padding:14px;border-radius:50px;border:none;background:linear-gradient(135deg,#6d28d9,#a78bfa);color:#fff;font-size:15px;font-weight:700;cursor:pointer}
.btn:disabled{opacity:.4;cursor:not-allowed}
.alert-ok{background:rgba(52,211,153,.15);border:1px solid #34d399;border-radius:12px;padding:12px 16px;color:#a7f3d0;font-size:13px;margin-bottom:16px}
.alert-err{background:rgba(248,113,113,.12);border:1px solid #f87171;border-radius:12px;padding:12px 16px;color:#fca5a5;font-size:13px;margin-bottom:16px}
</style>
</head>
<body>
<div class="box">
  <div class="ico">🚫</div>
  <h1>Cuenta suspendida</h1>
  <p>Tu cuenta ha sido suspendida por infracción a las normas de la comunidad Miniminds.</p>

  @php $motivo = $motivo ?? session('motivo'); $hasta = $hasta ?? session('hasta'); @endphp
  @if(isset($motivo) && $motivo)
    <div class="motivo"><b>Motivo:</b> {{ $motivo }}</div>
  @endif

  @if(isset($hasta) && $hasta)
    <p class="limite">⏰ Suspensión hasta: <b>{{ \Carbon\Carbon::parse($hasta)->format('d/m/Y H:i') }}</b></p>
  @else
    <p class="limite" style="color:#f87171">🔒 Esta suspensión es <b>permanente</b>.</p>
  @endif

  @if(session('success'))
    <div class="alert-ok">✅ {{ session('success') }}</div>
  @endif
  @if(session('error'))
    <div class="alert-err">⚠️ {{ session('error') }}</div>
  @endif

  @if($yaEnvioHoy ?? false)
    <div class="alert-err">Ya enviaste una solicitud hoy. Puedes intentarlo nuevamente mañana.</div>
  @else
    <p style="margin-bottom:14px;font-size:14px;opacity:.8">Puedes enviar <b>1 solicitud de desbaneo por día</b>. Explica al equipo por qué mereces una segunda oportunidad.</p>
    <form method="POST" action="{{ route('desbaneo.store') }}">
      @csrf
      <textarea name="justificacion" placeholder="Explica qué sucedió y por qué mereces que se levante la suspensión (mínimo 30 caracteres)..." required minlength="30"></textarea>
      @error('justificacion')<div class="alert-err" style="margin-bottom:10px">{{ $message }}</div>@enderror
      <button type="submit" class="btn">Enviar solicitud de desbaneo</button>
    </form>
  @endif

  <p style="margin-top:20px;font-size:12px;opacity:.45">Miniminds · Seguridad de la comunidad</p>
</div>
</body>
</html>
