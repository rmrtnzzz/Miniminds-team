@extends('layouts.paciente')

@section('title', 'Tu perfil — Miniminds')

@section('extra_styles')
<style>
    .perfil-tabs {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    .perfil-tab-btn {
        background: rgba(255,255,255,0.5);
        border: none;
        border-radius: 12px;
        padding: 14px 16px;
        text-align: left;
        font-size: 13px;
        font-weight: 600;
        color: #6b6280;
        cursor: pointer;
        transition: background 0.15s, color 0.15s;
    }
    .perfil-tab-btn:hover { background: rgba(255,255,255,0.75); }
    .perfil-tab-btn.activo { background: #fff; color: #4A4063; box-shadow: 0 2px 10px rgba(0,0,0,0.06); }

    .foto-container { position: relative; width: 70px; height: 70px; flex-shrink: 0; }
    .foto-container img {
        width: 70px; height: 70px; border-radius: 50%; object-fit: cover; border: 3px solid #fff;
    }
    .foto-edit-btn {
        position: absolute; bottom: -2px; right: -2px;
        background: #F5A623; color: #fff; border: 2px solid #fff;
        width: 24px; height: 24px; border-radius: 50%;
        font-size: 11px; display: flex; align-items: center; justify-content: center;
        cursor: pointer;
    }

    .campo-perfil {
        display: flex;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid rgba(0,0,0,0.06);
        gap: 10px;
    }
    .campo-perfil:last-of-type { border-bottom: none; }
    .campo-label {
        width: 200px;
        font-size: 12px;
        font-weight: 700;
        color: #9a8fb8;
        letter-spacing: 0.03em;
        flex-shrink: 0;
    }
    .campo-valor {
        flex: 1;
        font-size: 14px;
        color: #4A4063;
    }
    .campo-valor input, .campo-valor select {
        border: none;
        border-bottom: 1px solid #C4B5E8;
        background: transparent;
        width: 100%;
        font-size: 14px;
        padding: 2px 0;
        color: #4A4063;
    }
    .campo-valor input:focus, .campo-valor select:focus { outline: none; border-bottom-color: #F5A623; }
    .campo-edit {
        cursor: pointer;
        color: #b8aed6;
        font-size: 13px;
    }
    .campo-edit:hover { color: #F5A623; }

    .estado-pill{display:inline-block;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700}
    .estado-pendiente{background:#FCEFD0;color:#B8860B}
    .estado-aprobada{background:#DDF3E4;color:#1F9254}
    .estado-rechazada{background:#FBDDE3;color:#C23A52}
</style>
@endsection

@section('content')
<h2 style="font-weight:800; margin-bottom:24px;">Tu perfil</h2>

@if(session('success'))
    <div style="background:#DDF3E4;color:#1F9254;padding:12px 18px;border-radius:10px;margin-bottom:16px;font-weight:600">
        ✅ {{ session('success') }}
    </div>
@endif

<div class="row g-4">
    <div class="col-md-3">
        <div class="perfil-tabs">
            <button class="perfil-tab-btn activo" onclick="mostrarTab('cuenta', this)">Información de la cuenta</button>
            <button class="perfil-tab-btn" onclick="mostrarTab('paciente', this)">Mis pacientes</button>
            <button class="perfil-tab-btn" onclick="mostrarTab('solicitudes', this)">Mis solicitudes</button>
        </div>
    </div>

    <div class="col-md-9">

        
        <div id="seccion-cuenta" class="pt-card p-4">
            <h5 style="font-weight:700; margin-bottom:18px;">Información de la cuenta</h5>

            <form action="{{ route('paciente.update.cuenta') }}" method="POST" enctype="multipart/form-data">
                @csrf @method('PUT')

                <div class="d-flex align-items-center gap-3 mb-4">
                    <div class="foto-container">
                        <img src="{{ auth()->user()->foto ? asset('storage/'.auth()->user()->foto) : 'https://via.placeholder.com/70' }}" alt="Foto">
                        <label class="foto-edit-btn" for="foto-input">✏️</label>
                        <input type="file" id="foto-input" name="foto" accept="image/*" style="display:none;" onchange="this.form.submit()">
                    </div>
                    <span style="font-size:12px; color:#9a8fb8;">
                        Miembro desde: {{ auth()->user()->created_at->format('d/m/Y') }}
                    </span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">NOMBRE</span>
                    <span class="campo-valor" data-static>{{ auth()->user()->name }}</span>
                    <input type="text" name="name" value="{{ auth()->user()->name }}" class="campo-valor d-none" data-input>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">APELLIDO</span>
                    <span class="campo-valor" data-static>{{ auth()->user()->apellido ?? '—' }}</span>
                    <input type="text" name="apellido" value="{{ auth()->user()->apellido }}" class="campo-valor d-none" data-input>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">CORREO ELECTRÓNICO</span>
                    <span class="campo-valor" data-static>{{ auth()->user()->email }}</span>
                    <input type="email" name="email" value="{{ auth()->user()->email }}" class="campo-valor d-none" data-input>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">CONTRASEÑA</span>
                    <span class="campo-valor" data-static>••••••••</span>
                    <input type="password" name="password" placeholder="Nueva contraseña" class="campo-valor d-none" data-input>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">NÚMERO DE TELÉFONO</span>
                    <span class="campo-valor" data-static>{{ auth()->user()->telefono ?? '—' }}</span>
                    <input type="text" name="telefono" value="{{ auth()->user()->telefono }}" class="campo-valor d-none" data-input>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">FECHA DE NACIMIENTO</span>
                    <span class="campo-valor" data-static>{{ optional(auth()->user()->fecha_nacimiento)->format('d/m/Y') ?? '—' }}</span>
                    <input type="date" name="fecha_nacimiento" value="{{ auth()->user()->fecha_nacimiento }}" class="campo-valor d-none" data-input>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <div class="campo-perfil">
                    <span class="campo-label">GÉNERO</span>
                    <span class="campo-valor" data-static>{{ ucfirst(auth()->user()->genero ?? '—') }}</span>
                    <select name="genero" class="campo-valor d-none" data-input>
                        <option value="femenino" {{ auth()->user()->genero == 'femenino' ? 'selected' : '' }}>Femenino</option>
                        <option value="masculino" {{ auth()->user()->genero == 'masculino' ? 'selected' : '' }}>Masculino</option>
                        <option value="otro" {{ auth()->user()->genero == 'otro' ? 'selected' : '' }}>Otro</option>
                    </select>
                    <span class="campo-edit" onclick="editarCampo(this)">✏️</span>
                </div>

                <button type="submit" class="btn btn-acento mt-3">Guardar</button>
            </form>
        </div>

        
        <div id="seccion-paciente" class="pt-card p-4" style="display:none;">
            <h5 style="font-weight:700; margin-bottom:18px;">Mis pacientes</h5>

            @forelse($pacientes ?? [] as $paciente)
                <div class="d-flex align-items-center gap-3 mb-3 pb-3" style="border-bottom:1px solid rgba(0,0,0,0.06);">
                    <div class="foto-container">
                        <img src="{{ $paciente->foto ? asset('storage/'.$paciente->foto) : 'https://via.placeholder.com/70' }}" alt="Foto paciente">
                    </div>
                    <div class="flex-grow-1">
                        <div style="font-weight:700;">{{ $paciente->nombre }} {{ $paciente->apellido }}</div>
                        <div style="font-size:12px; color:#9a8fb8;">
                            {{ optional($paciente->fecha_nacimiento)->format('d/m/Y') ?? 'Sin fecha' }}
                            · {{ ucfirst($paciente->genero ?? '—') }}
                            · {{ $paciente->edad ?? '—' }} años
                        </div>
                        <div style="font-size:12px; color:#7C5CBF; margin-top:2px;">
                            Especialista: {{ $paciente->profesional->nombre ?? 'Sin asignar' }} {{ $paciente->profesional->apellido ?? '' }}
                        </div>
                    </div>
                </div>
            @empty
                <p style="color:#8b7fa8; font-size:14px;">Todavía no tienes ningún paciente registrado.</p>
            @endforelse

            <a href="{{ route('paciente.solicitudes.crear') }}" class="btn btn-acento mt-2">+ Solicitar registro de paciente</a>
        </div>

        
        <div id="seccion-solicitudes" class="pt-card p-4" style="display:none;">
            <h5 style="font-weight:700; margin-bottom:18px;">Mis solicitudes de registro</h5>

            @forelse($solicitudes ?? [] as $s)
                <div class="d-flex align-items-center gap-3 mb-3 pb-3" style="border-bottom:1px solid rgba(0,0,0,0.06);">
                    <div class="flex-grow-1">
                        <div style="font-weight:700;">{{ $s->nombre }} {{ $s->apellido }}</div>
                        <div style="font-size:12px; color:#9a8fb8;">
                            Enviada el {{ $s->created_at->format('d/m/Y') }}
                        </div>
                        @if($s->nota_revision)
                            <div style="font-size:12px; color:#6b6280; margin-top:4px;">
                                Nota del especialista: {{ $s->nota_revision }}
                            </div>
                        @endif
                    </div>
                    <span class="estado-pill estado-{{ $s->estado }}">{{ ucfirst($s->estado) }}</span>
                </div>
            @empty
                <p style="color:#8b7fa8; font-size:14px;">No has enviado ninguna solicitud todavía.</p>
            @endforelse

            <a href="{{ route('paciente.solicitudes.crear') }}" class="btn btn-acento mt-2">+ Nueva solicitud</a>
        </div>

    </div>
</div>
@endsection

@section('extra_scripts')
<script>
function mostrarTab(tab, btn) {
    document.getElementById('seccion-cuenta').style.display = tab === 'cuenta' ? 'block' : 'none';
    document.getElementById('seccion-paciente').style.display = tab === 'paciente' ? 'block' : 'none';
    document.getElementById('seccion-solicitudes').style.display = tab === 'solicitudes' ? 'block' : 'none';
    document.querySelectorAll('.perfil-tab-btn').forEach(b => b.classList.remove('activo'));
    btn.classList.add('activo');
}

function editarCampo(icon) {
    const row = icon.closest('.campo-perfil');
    const staticEl = row.querySelector('[data-static]');
    const inputEl = row.querySelector('[data-input]');
    staticEl.classList.add('d-none');
    inputEl.classList.remove('d-none');
    inputEl.focus();
}
</script>
@endsection
