@extends('layouts.paciente')

@section('title', 'Agenda — Miniminds')

@section('extra_styles')
<style>
    .agenda-item {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 16px;
        border-bottom: 1px solid rgba(0,0,0,0.06);
    }
    .agenda-item:last-child { border-bottom: none; }
    .agenda-fecha {
        background: #F0EEFF;
        color: #5c4de8;
        border-radius: 12px;
        padding: 10px 14px;
        text-align: center;
        flex-shrink: 0;
        min-width: 62px;
    }
    .agenda-fecha .dia { font-size: 20px; font-weight: 800; display: block; }
    .agenda-fecha .mes { font-size: 11px; text-transform: uppercase; }
    .agenda-info { flex: 1; }
    .agenda-info .titulo { font-weight: 700; color: #4A4063; }
    .agenda-info .sub { font-size: 13px; color: #8b7fa8; }
</style>
@endsection

@section('content')
<h2 style="font-weight:800; margin-bottom:24px;">Agenda</h2>

<div class="pt-card p-2">
    @forelse($proximasCitas ?? [] as $cita)
        <div class="agenda-item">
            <div class="agenda-fecha">
                <span class="dia">{{ $cita->fecha->format('d') }}</span>
                <span class="mes">{{ $cita->fecha->locale('es')->isoFormat('MMM') }}</span>
            </div>
            <div class="agenda-info">
                <div class="titulo">{{ $cita->paciente->nombre ?? '—' }} con {{ $cita->profesional->nombre ?? 'profesional por asignar' }}</div>
                <div class="sub">{{ \Carbon\Carbon::parse($cita->hora)->format('H:i') }} hrs · {{ ucfirst($cita->estado) }}</div>
            </div>
        </div>
    @empty
        <div style="text-align:center; color:#9a8fb8; padding:40px;">
            No tienes próximas citas en tu agenda.
        </div>
    @endforelse
</div>
@endsection
