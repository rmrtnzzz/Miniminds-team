@extends('layouts.paciente')

@section('title', 'Calendario — Miniminds')

@section('extra_styles')
<style>
    .cal-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 6px;
    }
    .cal-day-label {
        text-align: center;
        font-size: 11px;
        font-weight: 700;
        color: #9a8fb8;
        text-transform: uppercase;
        padding: 6px 0;
    }
    .cal-cell {
        background: rgba(255,255,255,0.5);
        border-radius: 10px;
        min-height: 76px;
        padding: 8px;
        font-size: 13px;
        color: #4A4063;
        position: relative;
    }
    .cal-cell.empty { background: transparent; }
    .cal-cell.today { border: 2px solid #F5A623; }
    .cal-dot {
        width: 6px; height: 6px; border-radius: 50%;
        background: #C4B5E8; display: inline-block; margin-top: 4px;
    }
</style>
@endsection

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="font-weight:800; margin:0;">Calendario</h2>
    <span style="font-weight:600; color:#6b6280;">{{ $mesNombre }} {{ $anio }}</span>
</div>

<div class="pt-card p-4">
    <div class="cal-grid mb-2">
        <div class="cal-day-label">Lun</div>
        <div class="cal-day-label">Mar</div>
        <div class="cal-day-label">Mié</div>
        <div class="cal-day-label">Jue</div>
        <div class="cal-day-label">Vie</div>
        <div class="cal-day-label">Sáb</div>
        <div class="cal-day-label">Dom</div>
    </div>
    <div class="cal-grid">
        @for($i = 0; $i < $offset; $i++)
            <div class="cal-cell empty"></div>
        @endfor

        @for($dia = 1; $dia <= $diasEnMes; $dia++)
            <div class="cal-cell {{ $dia === $diaHoy ? 'today' : '' }}">
                <div>{{ $dia }}</div>
                @if(isset($citasPorDia[$dia]))
                    <span class="cal-dot"></span>
                @endif
            </div>
        @endfor
    </div>
</div>
@endsection
