@extends('layouts.paciente')

@section('title', 'Recursos — Miniminds')

@section('extra_styles')
<style>
    .recursos-table { width: 100%; border-collapse: collapse; }
    .recursos-table th {
        text-align: left;
        font-size: 12px;
        color: #9a8fb8;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        padding: 10px 14px;
        border-bottom: 1px solid rgba(0,0,0,0.08);
    }
    .recursos-table td {
        padding: 14px;
        font-size: 14px;
        color: #4A4063;
        border-bottom: 1px solid rgba(0,0,0,0.05);
    }
    .estado-pill {
        display: inline-block;
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    .estado-completado { background: #DDF3E4; color: #1F9254; }
    .estado-pendiente { background: #FCEFD0; color: #B8860B; }
    .estado-cancelado { background: #FBDDE3; color: #C23A52; }
</style>
@endsection

@section('content')
<h2 style="font-weight:800; margin-bottom:8px;">¡Bienvenido/a, {{ auth()->user()->name ?? 'nombre' }}!</h2>

<div class="row g-3 mb-4 mt-3">
    <div class="col-md-4">
        <a href="{{ route('paciente.citas') }}" class="text-decoration-none">
            <div class="pt-card text-center py-4" style="border: 2px solid #F5C4D6;">
                <div style="font-size:14px; font-weight:700; color:#4A4063;">Mis citas</div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="#" class="text-decoration-none">
            <div class="pt-card text-center py-4" style="border: 2px solid #C4B5E8;">
                <div style="font-size:14px; font-weight:700; color:#4A4063;">Contenidos</div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="#" class="text-decoration-none">
            <div class="pt-card text-center py-4" style="border: 2px solid #A8D8C4;">
                <div style="font-size:14px; font-weight:700; color:#4A4063;">Profesionales</div>
            </div>
        </a>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-2">
    <h6 style="font-weight:700; margin:0;">Actividad reciente</h6>
    <a href="{{ route('juegos.index') }}" style="font-size:13px; color:#F5A623; text-decoration:none;">Ver todo</a>
</div>

<div class="pt-card p-3">
    <table class="recursos-table">
        <thead>
            <tr>
                <th>Paciente</th>
                <th>Profesional</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @forelse($actividad ?? [] as $item)
                <tr>
                    <td>{{ $item->paciente->nombre ?? '—' }} {{ $item->paciente->apellido ?? '' }}</td>
                    <td>{{ $item->profesional->nombre ?? 'Sin asignar' }} {{ $item->profesional->apellido ?? '' }}</td>
                    <td>{{ $item->fecha->format('d/m/Y') }}</td>
                    <td><span class="estado-pill estado-{{ $item->estado === 'completada' ? 'completado' : ($item->estado === 'cancelada' ? 'cancelado' : 'pendiente') }}">{{ ucfirst($item->estado) }}</span></td>
                    <td><i class="fas fa-ellipsis-vertical" style="color:#9a8fb8;"></i></td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" style="text-align:center; color:#9a8fb8; padding:32px;">
                        Todavía no hay actividad registrada.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-4">
    <h6 style="font-weight:700; margin-bottom:12px;">Juegos terapéuticos</h6>
    <div class="row g-3">
        <div class="col-md-4">
            <a href="{{ route('juegos.mision_control') }}" class="text-decoration-none">
                <div class="pt-card p-3 text-center">
                    <div style="font-size:32px;">🛸</div>
                    <div style="font-size:13px; font-weight:600; color:#4A4063; margin-top:6px;">Misión Control</div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="{{ route('juegos.detector_contexto') }}" class="text-decoration-none">
                <div class="pt-card p-3 text-center">
                    <div style="font-size:32px;">🔍</div>
                    <div style="font-size:13px; font-weight:600; color:#4A4063; margin-top:6px;">Detector de Contexto</div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="{{ route('juegos.termometro_interior') }}" class="text-decoration-none">
                <div class="pt-card p-3 text-center">
                    <div style="font-size:32px;">🌡️</div>
                    <div style="font-size:13px; font-weight:600; color:#4A4063; margin-top:6px;">Termómetro Interior</div>
                </div>
            </a>
        </div>
    </div>
</div>
@endsection
