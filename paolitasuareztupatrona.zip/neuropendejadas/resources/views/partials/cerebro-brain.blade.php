@php
    // $height: alto del bloque. $showHeader: si muestra el título interno.
    $height = $height ?? '620px';
    $showHeader = $showHeader ?? true;
    $uid = 'cb-' . uniqid();
@endphp

<div id="{{ $uid }}" class="cerebro-widget" style="--cb-h: {{ $height }};">

    @if($showHeader)
    <div class="cb-header">
        <div>
            <h1>🧠 Mi Cerebro 3D</h1>
            <p>Arrastra para rotar · Rueda para zoom · Toca una zona para descubrirla</p>
        </div>
    </div>
    @endif

    <div class="cb-body">
        <div class="cb-canvas-wrap">
            <div class="cb-hover-tag"></div>
            <div class="cb-hint">🖱️ Arrastra para explorar</div>
        </div>

        <div class="cb-info-panel">
            <div class="cb-idle">
                <span class="cb-big-emoji">🧠</span>
                Toca una parte del cerebro (o un botón de abajo) para descubrir qué hace.
            </div>
            <div class="cb-info-content">
                <div class="cb-info-close">✕</div>
                <span class="cb-info-badge"></span>
                <h3 class="cb-info-title"></h3>
                <p class="cb-info-text"></p>
            </div>
        </div>
    </div>

    <div class="cb-fact-pills">
        <div class="cb-fact-pill" data-key="frontal">🧠 Frontal</div>
        <div class="cb-fact-pill" data-key="parietal">📍 Parietal</div>
        <div class="cb-fact-pill" data-key="temporal">👂 Temporal</div>
        <div class="cb-fact-pill" data-key="occipital">👁️ Occipital</div>
        <div class="cb-fact-pill" data-key="cerebelo">⚖️ Cerebelo</div>
        <div class="cb-fact-pill" data-key="emociones">💜 Emociones</div>
        <div class="cb-fact-pill" data-key="neurona">⚡ Neuronas</div>
    </div>

</div>

<style>
.cerebro-widget{
    position:relative;width:100%;height:var(--cb-h);
    background:linear-gradient(160deg,#0d0020 0%,#1a0035 50%,#0a0018 100%);
    overflow:hidden;display:flex;flex-direction:column;
    font-family:'Segoe UI',sans-serif;border-radius:18px;
}
.cerebro-widget .cb-header{
    position:relative;z-index:20;padding:20px 28px 0;
    display:flex;align-items:center;justify-content:space-between;
}
.cerebro-widget .cb-header h1{
    font-size:22px;font-weight:900;margin:0;
    background:linear-gradient(135deg,#c4b5fd,#f0abfc);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.cerebro-widget .cb-header p{color:rgba(255,255,255,.45);font-size:12px;margin:2px 0 0}
.cerebro-widget .cb-body{flex:1;display:flex;min-height:0;position:relative}
.cerebro-widget .cb-canvas-wrap{flex:1;position:relative;min-width:0;cursor:grab}
.cerebro-widget .cb-canvas-wrap:active{cursor:grabbing}
.cerebro-widget .cb-canvas-wrap canvas{display:block;width:100%!important;height:100%!important}
.cerebro-widget .cb-hover-tag{
    position:absolute;pointer-events:none;z-index:15;
    background:rgba(196,181,253,.15);border:1px solid rgba(196,181,253,.4);
    color:#e9d5ff;font-size:11px;font-weight:700;padding:4px 10px;
    border-radius:20px;backdrop-filter:blur(6px);opacity:0;
    transition:opacity .15s;transform:translate(-50%,-140%);white-space:nowrap;
}
.cerebro-widget .cb-hover-tag.show{opacity:1}
.cerebro-widget .cb-hint{
    position:absolute;bottom:14px;left:50%;transform:translateX(-50%);
    color:rgba(255,255,255,.35);font-size:11px;z-index:10;
    display:flex;align-items:center;gap:6px;
}
.cerebro-widget .cb-info-panel{
    width:320px;flex-shrink:0;position:relative;z-index:20;
    background:rgba(13,0,32,.55);border-left:1px solid rgba(196,181,253,.18);
    backdrop-filter:blur(20px);padding:24px 22px;
    display:flex;flex-direction:column;overflow-y:auto;
}
.cerebro-widget .cb-idle{margin:auto 0;text-align:center;color:rgba(255,255,255,.4);font-size:13px;line-height:1.7}
.cerebro-widget .cb-big-emoji{font-size:40px;display:block;margin-bottom:10px;opacity:.8}
.cerebro-widget .cb-info-content{display:none}
.cerebro-widget .cb-info-content.show{display:block;animation:cbFadeSlide .35s ease}
@keyframes cbFadeSlide{from{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}
.cerebro-widget .cb-info-badge{
    display:inline-block;font-size:11px;font-weight:800;letter-spacing:.03em;
    color:#0d0020;background:linear-gradient(135deg,#c4b5fd,#f0abfc);
    padding:4px 12px;border-radius:20px;margin-bottom:14px;
}
.cerebro-widget .cb-info-title{color:#fff;font-size:19px;font-weight:900;margin:0 0 12px;line-height:1.3}
.cerebro-widget .cb-info-text{color:#e9d5ff;font-size:14px;line-height:1.75;margin:0}
.cerebro-widget .cb-info-close{
    align-self:flex-end;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
    color:#c4b5fd;width:26px;height:26px;border-radius:50%;cursor:pointer;
    display:flex;align-items:center;justify-content:center;font-size:13px;margin-bottom:6px;
}
.cerebro-widget .cb-fact-pills{
    position:absolute;bottom:0;left:0;right:320px;z-index:20;
    display:flex;gap:8px;flex-wrap:wrap;justify-content:center;
    padding:14px 20px 16px;
    background:linear-gradient(to top,rgba(13,0,32,.9) 40%,transparent);
}
.cerebro-widget .cb-fact-pill{
    background:rgba(196,181,253,.08);border:1px solid rgba(196,181,253,.22);
    border-radius:50px;padding:6px 14px;font-size:11.5px;color:#c4b5fd;
    cursor:pointer;transition:all .2s;font-weight:600;white-space:nowrap;
}
.cerebro-widget .cb-fact-pill:hover,.cerebro-widget .cb-fact-pill.active{
    background:rgba(196,181,253,.25);border-color:#c4b5fd;color:#fff;
    transform:translateY(-2px);
}
@media (max-width:900px){
    .cerebro-widget .cb-body{flex-direction:column}
    .cerebro-widget .cb-info-panel{
        width:100%;order:2;max-height:38vh;border-left:none;
        border-top:1px solid rgba(196,181,253,.18);
    }
    .cerebro-widget .cb-canvas-wrap{order:1;min-height:42vh}
    .cerebro-widget .cb-fact-pills{right:0}
}
</style>

@once
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
@endonce

<script>
(function(){
    const root = document.getElementById('{{ $uid }}');
    if (!root || typeof THREE === 'undefined') return;

    const FACTS = {
        frontal:{ emoji:'🧠', badge:'Lóbulo Frontal', title:'El centro de decisiones',
            text:'Controla la planificación, la toma de decisiones y el control de impulsos. Cuando te cuesta concentrarte, este lóbulo está trabajando muy duro. ¡Ejercitarlo con juegos y lectura lo hace más fuerte!', color:0xf472b6 },
        parietal:{ emoji:'📍', badge:'Lóbulo Parietal', title:'El mapa del cuerpo',
            text:'Procesa las sensaciones táctiles y nos ayuda a entender el espacio. Cuando unes un rompecabezas o sientes la textura de algo, este lóbulo está activo.', color:0x60a5fa },
        temporal:{ emoji:'👂', badge:'Lóbulo Temporal', title:'El archivo de recuerdos',
            text:'Procesa el sonido y guarda los recuerdos importantes. La música que te gusta, las voces de las personas que amas — todo pasa por aquí.', color:0xfb923c },
        occipital:{ emoji:'👁️', badge:'Lóbulo Occipital', title:'La pantalla del cerebro',
            text:'Procesa todo lo que ves: colores, formas y movimiento. Es como la pantalla de una computadora pero millones de veces más poderosa.', color:0x34d399 },
        cerebelo:{ emoji:'⚖️', badge:'Cerebelo', title:'El maestro del equilibrio',
            text:'Coordina el movimiento y el equilibrio. Cuando aprendes a andar en bicicleta, a bailar o a escribir, el cerebelo memoriza esos movimientos para siempre.', color:0xfacc15 },
        emociones:{ emoji:'💜', badge:'Sistema Límbico', title:'La casa de las emociones',
            text:'Aquí viven el miedo, la alegría, la tristeza y el amor. Cuando sientes mariposas en el estómago o quieres llorar sin razón, tu sistema límbico está hablando. ¡Escucharlo es muy importante!', color:0xe879f9 },
        neurona:{ emoji:'⚡', badge:'Neuronas', title:'Los mensajeros del cerebro',
            text:'Tu cerebro tiene 86,000 millones de neuronas. Cada vez que aprendes algo nuevo, se forma una conexión entre ellas. ¡Estudiar y jugar literalmente construye tu cerebro!', color:0xc4b5fd },
    };

    const canvasWrap = root.querySelector('.cb-canvas-wrap');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, canvasWrap.clientWidth / canvasWrap.clientHeight, 0.1, 100);
    camera.position.set(0, 0.6, 8.5);

    const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(canvasWrap.clientWidth, canvasWrap.clientHeight);
    canvasWrap.appendChild(renderer.domElement);

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 1.1;
    controls.minDistance = 5;
    controls.maxDistance = 14;
    controls.enablePan = false;
    renderer.domElement.addEventListener('pointerdown', () => controls.autoRotate = false);

    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const keyLight = new THREE.DirectionalLight(0xffffff, 0.9);
    keyLight.position.set(4, 5, 6);
    scene.add(keyLight);
    const rimLight = new THREE.PointLight(0xc4b5fd, 1.2, 20);
    rimLight.position.set(-5, 2, -4);
    scene.add(rimLight);

    const brainGroup = new THREE.Group();
    scene.add(brainGroup);

    function createBrainFolderGeometry(scaleVec, isLeft) {
        const geo = new THREE.SphereGeometry(1, 48, 48);
        const pos = geo.attributes.position;
        for (let i = 0; i < pos.count; i++) {
            let x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
            if ((isLeft && x > 0) || (!isLeft && x < 0)) x *= 0.3;
            const freq = 6.0;
            const fold = Math.sin(x * freq) * Math.cos(y * freq) * Math.sin(z * freq);
            const detail = Math.sin(x * 12.0 + y * 12.0) * 0.03;
            const displacement = 1.0 + fold * 0.12 + detail;
            pos.setXYZ(i, x * displacement * scaleVec[0], y * displacement * scaleVec[1], z * displacement * scaleVec[2]);
        }
        geo.computeVertexNormals();
        return geo;
    }

    const REGION_DEF = {
        frontal:  { pos:[0.95, 0.45, 0],    scale:[1.1, 0.9, 1.15],  mirror:true },
        parietal: { pos:[0.75, 1.05, -0.6], scale:[0.9, 0.7, 0.9],   mirror:true },
        temporal: { pos:[1.1, -0.25, -0.1], scale:[0.75, 0.55, 0.9], mirror:true },
        occipital:{ pos:[0.7, 0.35, -1.55], scale:[0.8, 0.75, 0.85], mirror:true },
        cerebelo: { pos:[0.65, -0.9, -1.2], scale:[0.65, 0.5, 0.65], mirror:true },
        emociones:{ pos:[0.2, -0.1, -0.3],  scale:[0.45, 0.45, 0.55],mirror:true },
    };

    const regionMeshes = {};

    function makeRegionMesh(key, def, isLeft) {
        const geo = createBrainFolderGeometry(def.scale, isLeft);
        const mat = new THREE.MeshPhongMaterial({
            color: FACTS[key].color, transparent: true, opacity: 0.65,
            emissive: FACTS[key].color, emissiveIntensity: 0.15, shininess: 40
        });
        const mesh = new THREE.Mesh(geo, mat);
        const posX = isLeft ? -def.pos[0] : def.pos[0];
        mesh.position.set(posX, def.pos[1], def.pos[2]);
        mesh.userData.key = key;
        brainGroup.add(mesh);
        return mesh;
    }

    Object.entries(REGION_DEF).forEach(([key, def]) => {
        const meshes = [makeRegionMesh(key, def, false)];
        if (def.mirror) meshes.push(makeRegionMesh(key, def, true));
        regionMeshes[key] = meshes;
    });

    const particleCount = 260;
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
        const v = new THREE.Vector3(
            (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 2
        ).normalize().multiplyScalar(1.5 + Math.random() * 0.7);
        positions[i*3] = v.x * 1.1; positions[i*3+1] = v.y * 0.9; positions[i*3+2] = v.z * 1.2;
    }
    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({ color:0xc4b5fd, size:0.045, transparent:true, opacity:0.25 });
    const particles = new THREE.Points(particleGeo, particleMat);
    brainGroup.add(particles);

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const hoverTag = root.querySelector('.cb-hover-tag');
    let hovered = null;

    function allMeshes() { return Object.values(regionMeshes).flat(); }

    function setPointer(e) {
        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        return rect;
    }

    renderer.domElement.addEventListener('pointermove', (e) => {
        const rect = setPointer(e);
        raycaster.setFromCamera(pointer, camera);
        const hit = raycaster.intersectObjects(allMeshes())[0];
        if (hit) {
            renderer.domElement.style.cursor = 'pointer';
            const key = hit.object.userData.key;
            hoverTag.textContent = FACTS[key].emoji + ' ' + FACTS[key].badge;
            hoverTag.style.left = (e.clientX - rect.left) + 'px';
            hoverTag.style.top = (e.clientY - rect.top) + 'px';
            hoverTag.classList.add('show');
            hovered = key;
        } else {
            renderer.domElement.style.cursor = 'grab';
            hoverTag.classList.remove('show');
            hovered = null;
        }
    });

    renderer.domElement.addEventListener('click', () => { if (hovered) selectRegion(hovered); });

    let activeKey = null;
    let pulseT = 0;

    const infoIdle = root.querySelector('.cb-idle');
    const infoContent = root.querySelector('.cb-info-content');
    const infoBadge = root.querySelector('.cb-info-badge');
    const infoTitle = root.querySelector('.cb-info-title');
    const infoText = root.querySelector('.cb-info-text');

    function selectRegion(key) {
        activeKey = key;
        pulseT = 0;
        controls.autoRotate = false;

        root.querySelectorAll('.cb-fact-pill').forEach(p => p.classList.toggle('active', p.dataset.key === key));

        allMeshes().forEach(m => {
            const isActive = m.userData.key === key;
            m.material.opacity = isActive ? 0.9 : 0.12;
            m.material.emissiveIntensity = isActive ? 0.7 : 0.05;
        });
        particleMat.opacity = key === 'neurona' ? 0.9 : 0.15;
        particleMat.size = key === 'neurona' ? 0.07 : 0.045;

        const f = FACTS[key];
        infoIdle.style.display = 'none';
        infoContent.classList.remove('show'); void infoContent.offsetWidth; infoContent.classList.add('show');
        infoBadge.textContent = f.emoji + ' ' + f.badge;
        infoTitle.textContent = f.title;
        infoText.textContent = f.text;
    }

    function closeFact() {
        activeKey = null;
        root.querySelectorAll('.cb-fact-pill').forEach(p => p.classList.remove('active'));
        allMeshes().forEach(m => { m.material.opacity = 0.65; m.material.emissiveIntensity = 0.15; });
        particleMat.opacity = 0.25; particleMat.size = 0.045;
        infoContent.classList.remove('show');
        infoIdle.style.display = 'block';
        controls.autoRotate = true;
    }

    root.querySelector('.cb-info-close').addEventListener('click', closeFact);
    root.querySelectorAll('.cb-fact-pill').forEach(pill => {
        pill.addEventListener('click', () => selectRegion(pill.dataset.key));
    });

    function animate() {
        requestAnimationFrame(animate);
        pulseT += 0.05;
        if (activeKey) {
            const pulse = 0.6 + Math.sin(pulseT * 3) * 0.2;
            regionMeshes[activeKey].forEach(m => m.material.emissiveIntensity = pulse);
        }
        if (activeKey === 'neurona' || !activeKey) {
            particles.rotation.y += 0.0015;
        }
        controls.update();
        renderer.render(scene, camera);
    }
    animate();

    window.addEventListener('resize', () => {
        camera.aspect = canvasWrap.clientWidth / canvasWrap.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(canvasWrap.clientWidth, canvasWrap.clientHeight);
    });
})();
</script>
