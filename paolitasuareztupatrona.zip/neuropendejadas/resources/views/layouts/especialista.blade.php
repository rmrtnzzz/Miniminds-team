<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Miniminds — Panel de consulta')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #B8E0D8 0%, #C8E8DC 50%, #D5E8F0 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            color: #2E5C50;
            margin: 0;
        }

        .pt-topbar {
            display: flex; align-items: center; justify-content: space-between;
            padding: 14px 28px; background: rgba(255,255,255,0.4); backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .pt-topbar .brand { font-weight: 800; font-size: 19px; color: #2E5C50; text-decoration: none; }
        .pt-topbar .badge-rol {
            font-size: 11px; font-weight: 700; background: #2E9E7A; color: #fff;
            padding: 2px 10px; border-radius: 10px; margin-left: 8px; vertical-align: middle;
        }
        .pt-topbar .icons { display: flex; align-items: center; gap: 18px; font-size: 16px; color: #3d7268; }
        .pt-topbar .icons a { color: #3d7268; text-decoration: none; position: relative; }
        .pt-topbar .icons img.avatar { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; border: 2px solid #fff; }

        .notif-dot {
            position: absolute; top: -4px; right: -6px; background: #E0576B; color: #fff;
            font-size: 10px; font-weight: 700; border-radius: 50%; width: 16px; height: 16px;
            display: flex; align-items: center; justify-content: center;
        }
        .notif-dropdown {
            display: none; position: absolute; right: 0; top: 34px; width: 320px;
            background: #fff; border-radius: 14px; box-shadow: 0 8px 30px rgba(0,0,0,.15);
            z-index: 200; max-height: 360px; overflow-y: auto;
        }
        .notif-dropdown.open { display: block; }
        .notif-item { display: block; padding: 12px 16px; border-bottom: 1px solid #f0f0f0; text-decoration: none; color: #2E5C50; }
        .notif-item.leida { opacity: 0.55; }
        .notif-item:hover { background: #f7fdfb; }
        .notif-item .titulo { font-weight: 700; font-size: 13px; }
        .notif-item .msg { font-size: 12px; color: #6b6280; }
        .notif-empty { padding: 18px; text-align: center; color: #9a8fb8; font-size: 13px; }

        .pt-shell { display: flex; min-height: calc(100vh - 60px); }

        .pt-sidebar {
            width: 220px; flex-shrink: 0; background: rgba(255,255,255,0.3); backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255,255,255,0.4); padding: 22px 0; display: flex; flex-direction: column; gap: 4px;
        }
        .pt-sidebar a {
            display: flex; align-items: center; gap: 12px; padding: 12px 24px; color: #3d7268;
            text-decoration: none; font-weight: 500; font-size: 14px; border-left: 3px solid transparent;
            transition: background 0.15s, color 0.15s;
        }
        .pt-sidebar a i { width: 18px; text-align: center; }
        .pt-sidebar a:hover { background: rgba(255,255,255,0.4); color: #2E5C50; }
        .pt-sidebar a.active { background: rgba(255,255,255,0.6); color: #2E5C50; border-left-color: #2E9E7A; font-weight: 700; }
        .pt-sidebar .badge-pill {
            background: #E0576B; color: #fff; font-size: 10px; font-weight: 700;
            border-radius: 10px; padding: 1px 7px; margin-left: auto;
        }

        .pt-main { flex: 1; padding: 32px 36px; }

        .pt-card { background: rgba(255,255,255,0.7); backdrop-filter: blur(10px); border: none; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }

        .btn-acento { background-color: #2E9E7A; color: white; border: none; border-radius: 20px; padding: 8px 22px; font-weight: 600; }
        .btn-acento:hover { background-color: #24805f; color: white; }

        @media (max-width: 768px) { .pt-sidebar { display: none; } }
    </style>
    @yield('extra_styles')
</head>
<body>

    <div class="pt-topbar">
        <a class="brand" href="{{ route('especialista.inicio') }}">Miniminds! <span class="badge-rol">Especialista</span></a>
        <div class="icons">
            <div style="position:relative">
                <a href="#" onclick="event.preventDefault(); document.getElementById('notif-dropdown').classList.toggle('open')">
                    <i class="fas fa-bell"></i>
                    @if(auth()->check() && auth()->user()->unreadNotifications->count())
                        <span class="notif-dot">{{ auth()->user()->unreadNotifications->count() }}</span>
                    @endif
                </a>
                <div class="notif-dropdown" id="notif-dropdown">
                    @if(auth()->check())
                        @forelse(auth()->user()->notifications()->latest()->limit(10)->get() as $n)
                            <a href="{{ route('especialista.notificaciones.leer', $n->id) }}" class="notif-item {{ $n->read_at ? 'leida' : '' }}">
                                <div class="titulo">{{ $n->data['titulo'] ?? 'Notificación' }}</div>
                                <div class="msg">{{ $n->data['mensaje'] ?? '' }}</div>
                            </a>
                        @empty
                            <div class="notif-empty">No tienes notificaciones.</div>
                        @endforelse
                    @endif
                </div>
            </div>
            <a href="{{ route('especialista.perfil') }}">
                @if(auth()->check() && auth()->user()->foto)
                    <img class="avatar" src="{{ asset('storage/' . auth()->user()->foto) }}" alt="Foto de perfil">
                @else
                    <i class="fas fa-user-circle fa-lg"></i>
                @endif
            </a>
            <form method="POST" action="{{ route('logout') }}" style="margin:0">
                @csrf
                <button type="submit" style="background:none;border:none;color:#3d7268;font-size:16px" title="Salir"><i class="fas fa-right-from-bracket"></i></button>
            </form>
        </div>
    </div>

    <div class="pt-shell">
        <div class="pt-sidebar">
            <a href="{{ route('especialista.inicio') }}" class="{{ request()->routeIs('especialista.inicio') ? 'active' : '' }}">
                <i class="fas fa-house"></i> Inicio
            </a>
            <a href="{{ route('especialista.solicitudes.index') }}" class="{{ request()->routeIs('especialista.solicitudes.*') ? 'active' : '' }}">
                <i class="fas fa-inbox"></i> Solicitudes
                @php 
                    $pendientesCount = \App\Models\SolicitudPaciente::where('estado', 'pendiente')->count(); 
                @endphp
                @if($pendientesCount)
                    <span class="badge-pill">{{ $pendientesCount }}</span>
                @endif
            </a>
            <a href="{{ route('especialista.pacientes.index') }}" class="{{ request()->routeIs('especialista.pacientes.*') ? 'active' : '' }}">
                <i class="fas fa-user-injured"></i> Mis pacientes
            </a>
            <a href="{{ route('especialista.citas.index') }}" class="{{ request()->routeIs('especialista.citas.*') ? 'active' : '' }}">
                <i class="fas fa-calendar-check"></i> Agenda / Citas
            </a>
            <a href="{{ route('experiencias.mias') }}" class="{{ request()->routeIs('experiencias.mias') ? 'active' : '' }}">
                <i class="fas fa-comments"></i> Mis publicaciones
            </a>
            <a href="{{ route('experiencias.create') }}" class="{{ request()->routeIs('experiencias.create') ? 'active' : '' }}">
                <i class="fas fa-pen"></i> Publicar
            </a>
            <div class="pt-sidebar-section" style="margin-top:18px;padding:0 24px 6px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#6ba895">Cuenta</div>
            <a href="{{ route('especialista.perfil') }}" class="{{ request()->routeIs('especialista.perfil') ? 'active' : '' }}">
                <i class="fas fa-id-badge"></i> Mi perfil
            </a>
        </div>

        <div class="pt-main">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
            @endif
            @yield('content')
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    @yield('extra_scripts')
</body>
</html>