@extends('layouts.app')

@section('content')
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('css/chat.css') }}">

<div class="mm-chat">

    
    <aside class="mm-chat__sidebar">
        <div class="mm-chat__brand">
            <span class="mm-chat__brand-dot"></span>
            Miniminds
        </div>

        <p class="mm-chat__sidebar-label">Elige a tu compañero</p>

        <div class="mm-pets" id="mmPets">
            <button class="mm-pet mm-pet--nilo is-active" data-pet="nilo">
                <span class="mm-pet__avatar">🦭</span>
                <span class="mm-pet__info">
                    <span class="mm-pet__name">Nilo</span>
                    <span class="mm-pet__role">Te escucha con calma</span>
                </span>
            </button>

            <button class="mm-pet mm-pet--kairo" data-pet="kairo">
                <span class="mm-pet__avatar">🦇</span>
                <span class="mm-pet__info">
                    <span class="mm-pet__name">Kairo</span>
                    <span class="mm-pet__role">Aventuras y energía</span>
                </span>
            </button>

            <button class="mm-pet mm-pet--pipo" data-pet="pipo">
                <span class="mm-pet__avatar">🐦</span>
                <span class="mm-pet__info">
                    <span class="mm-pet__name">Pipo</span>
                    <span class="mm-pet__role">Ideas y estrategias</span>
                </span>
            </button>

            <button class="mm-pet mm-pet--luma" data-pet="luma">
                <span class="mm-pet__avatar">⭐</span>
                <span class="mm-pet__info">
                    <span class="mm-pet__name">Luma</span>
                    <span class="mm-pet__role">Brilla contigo</span>
                </span>
            </button>
        </div>

        <div class="mm-chat__sidebar-footer">
            <p>¿Necesitas ayuda urgente?</p>
            <a href="{{ url('/contacto') }}" class="mm-chat__help-link">Habla con un profesional →</a>
        </div>
    </aside>

    
    <main class="mm-chat__main">

        <header class="mm-chat__header">
            <div class="mm-chat__header-pet">
                <span class="mm-chat__header-avatar" id="mmHeaderAvatar">🦭</span>
                <div>
                    <h1 class="mm-chat__header-name" id="mmHeaderName">Nilo</h1>
                    <p class="mm-chat__header-status">
                        <span class="mm-chat__status-dot"></span>
                        En línea
                    </p>
                </div>
            </div>
        </header>

        <section class="mm-chat__messages" id="mmMessages">
            <div class="mm-msg mm-msg--bot">
                <span class="mm-msg__avatar">🦭</span>
                <div class="mm-msg__bubble">
                    ¡Hola! Soy Nilo 🌊 Estoy aquí para escucharte con calma.
                    ¿Cómo te sientes hoy?
                </div>
            </div>
        </section>

        <div class="mm-chat__typing" id="mmTyping" hidden>
            <span class="mm-msg__avatar">🦭</span>
            <div class="mm-typing-bubble">
                <span></span><span></span><span></span>
            </div>
        </div>

        <form class="mm-chat__composer" id="mmComposer" autocomplete="off">
            <input
                type="text"
                id="mmInput"
                class="mm-chat__input"
                placeholder="Escribe tu mensaje..."
                maxlength="500"
            />
            <button type="submit" class="mm-chat__send" aria-label="Enviar mensaje">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M2.5 10L17.5 2.5L12.5 17.5L9.5 11L2.5 10Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>
                </svg>
            </button>
        </form>
    </main>
</div>

<script>
(function () {
    const API_URL = "{{ url('/chat/enviar') }}";

    const PETS = {
        nilo:  { emoji: "🦭", name: "Nilo",  greeting: "¡Hola! Soy Nilo 🌊 Estoy aquí para escucharte con calma. ¿Cómo te sientes hoy?" },
        kairo: { emoji: "🦇", name: "Kairo", greeting: "¡Ey! Soy Kairo ⚡ ¿List@ para una aventura? Cuéntame qué tienes en mente." },
        pipo:  { emoji: "🐦", name: "Pipo",  greeting: "¡Hola! Soy Pipo 🐦 Me encanta ayudar a encontrar ideas. ¿En qué te ayudo hoy?" },
        luma:  { emoji: "⭐", name: "Luma",  greeting: "¡Hola! Soy Luma ✨ Brillemos juntos. ¿Qué quieres platicar?" }
    };

    let mascotaActual = "nilo";
    const sessionId = "web_" + Math.random().toString(36).slice(2, 10);

    const elPets = document.querySelectorAll(".mm-pet");
    const elMessages = document.getElementById("mmMessages");
    const elForm = document.getElementById("mmComposer");
    const elInput = document.getElementById("mmInput");
    const elTyping = document.getElementById("mmTyping");
    const elHeaderAvatar = document.getElementById("mmHeaderAvatar");
    const elHeaderName = document.getElementById("mmHeaderName");

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    function addMessage(text, sender, emoji) {
        const wrap = document.createElement("div");
        wrap.className = "mm-msg mm-msg--" + sender;

        if (sender === "bot") {
            wrap.innerHTML = `
                <span class="mm-msg__avatar">${emoji}</span>
                <div class="mm-msg__bubble">${escapeHtml(text)}</div>
            `;
        } else {
            wrap.innerHTML = `<div class="mm-msg__bubble">${escapeHtml(text)}</div>`;
        }

        elMessages.appendChild(wrap);
        elMessages.scrollTop = elMessages.scrollHeight;
    }

    function setMascota(key) {
        mascotaActual = key;
        const pet = PETS[key];

        elPets.forEach(btn => btn.classList.toggle("is-active", btn.dataset.pet === key));
        elHeaderAvatar.textContent = pet.emoji;
        elHeaderName.textContent = pet.name;
        elTyping.querySelector(".mm-msg__avatar").textContent = pet.emoji;
    }

    elPets.forEach(btn => {
        btn.addEventListener("click", () => {
            const key = btn.dataset.pet;
            if (key === mascotaActual) return;
            setMascota(key);
            addMessage(PETS[key].greeting, "bot", PETS[key].emoji);
        });
    });

    elForm.addEventListener("submit", async function (e) {
        e.preventDefault();
        const mensaje = elInput.value.trim();
        if (!mensaje) return;

        addMessage(mensaje, "user");
        elInput.value = "";
        elTyping.hidden = false;
        elMessages.scrollTop = elMessages.scrollHeight;

        try {
            const res = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]')?.content || ""
                },
                body: JSON.stringify({
                    mensaje: mensaje,
                    rol: "{{ auth()->check() ? (auth()->user()->role ?? 'paciente') : 'paciente' }}",
                    session_id: sessionId,
                    mascota: mascotaActual
                })
            });

            const data = await res.json();
            elTyping.hidden = true;

            const mascotaRespuesta = data.mascota || mascotaActual;
            if (mascotaRespuesta !== mascotaActual && PETS[mascotaRespuesta]) {
                setMascota(mascotaRespuesta);
            }

            addMessage(
                data.respuesta || "Lo siento, no pude procesar eso. ¿Puedes intentar de nuevo?",
                "bot",
                PETS[mascotaRespuesta]?.emoji || PETS[mascotaActual].emoji
            );

        } catch (err) {
            elTyping.hidden = true;
            addMessage("Hubo un problema de conexión. Intenta de nuevo en un momento 💜", "bot", PETS[mascotaActual].emoji);
        }
    });
})();
</script>
@endsection
